"""Gateway skeleton tests."""
