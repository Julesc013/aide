"""Gateway skeleton tests."""
