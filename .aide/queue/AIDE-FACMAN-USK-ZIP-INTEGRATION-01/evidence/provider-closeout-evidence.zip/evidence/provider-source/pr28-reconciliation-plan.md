# PR28 bounded ZIP streaming reconciliation plan

Observed 2026-09-06T14:37:53.945998+00:00.

Current user authority and root dispatch authorize source implementation, testing, normal integration preparation, and later reviewed task commit/non-force push. No PR28 merge is authorized in this unit.

Exact starting identities: primary clean dev 8a16fbd0c84ccb697830d464c6531b58568816d2; existing remote task/usk-stored-zip-streaming-01@79245461c547ee2a2389a0104959cafab051b45a; local task branch b64566dd9b7905880ae1d5a64a76a1ec17de8ad9. Fast-forward that existing local task branch to its remote head, then merge exact dev 8a16fbd0c84ccb697830d464c6531b58568816d2 with --no-commit --no-ff. Preserve all published ancestry and defer every new commit/push until root independently reviews the final source manifest/patch.

Use the existing primary checkout temporarily, preserving both owned evidence worktrees and avoiding a third. Keep all build outputs and evidence in existing marker-owned task root C:\Users\Jules\AppData\Local\FacMan\Development\repositories\universal-setup-db9c210f4a17\tasks\usk-s27; perform no cleanup. The pre-existing secondary_worktree_count_exceeds_1 hygiene violation is recorded and no new worktree is admitted.

Review the complete original ZIP64/stored/Deflate source and lifecycle integration against original stacked base18cb4b76 and head79245461, then reconcile inherited durable retain-only ownership behavior. Bound edits to original PR28 production/package/lifecycle/streaming documentation and direct tests, plus tightly justified shared streaming/transaction regressions if a material interaction demands them. Preserve pinned zlib upstream source unless evidence requires a separately reviewed dependency change; verify its recorded provenance and hashes.

Validate native archive, streaming, transaction, interruption, lifecycle and public lifecycle behavior with meaningful corruption, ownership, cancellation and restart refusal cases; run Python/schema tests, strict checks, and diff checks. Record exact source tree/patch hashes, commands/results and source-review findings. ZIP source qualification does not imply entry restart/generation/lease automation. Fresh hosted candidate CI is mandatory after a later reviewed non-force push; old head checks are historical only.

Root owns provider canonical promotion and AIDE queue updates. Do not alter PR28 remotely, protected branches, other repositories, product/user state, or AIDE records in this preparation phase. Return primary to clean dev after the eventual approved task push.
