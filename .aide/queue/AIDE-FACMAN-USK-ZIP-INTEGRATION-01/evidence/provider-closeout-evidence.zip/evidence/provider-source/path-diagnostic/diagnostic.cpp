// SPDX-FileCopyrightText: 2026 Jules C
// SPDX-License-Identifier: MIT

#include "usk/usk_api.h"
#include "usk_json.h"
#include "usk_live_evidence.h"
#include "usk_sha256.h"
#include "usk_transaction_session.h"

#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <set>
#include <Windows.h>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
using usk::json::Value;

namespace {

void append16(std::vector<unsigned char>& output, std::uint16_t value)
{
    output.push_back(static_cast<unsigned char>(value & 0xffu));
    output.push_back(static_cast<unsigned char>((value >> 8) & 0xffu));
}

void append32(std::vector<unsigned char>& output, std::uint32_t value)
{
    append16(output, static_cast<std::uint16_t>(value & 0xffffu));
    append16(output, static_cast<std::uint16_t>((value >> 16) & 0xffffu));
}

std::uint32_t crc32(const std::string& data)
{
    std::uint32_t crc = 0xffffffffu;
    for (unsigned char value : data) {
        crc ^= value;
        for (int bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
        }
    }
    return ~crc;
}

std::string bytes_from_hex(const std::string& value)
{
    if (value.size() % 2u != 0u) throw std::runtime_error("invalid fixture hex");
    std::string result;
    result.reserve(value.size() / 2u);
    for (std::size_t index = 0; index < value.size(); index += 2u) {
        result.push_back(static_cast<char>(
            std::stoul(value.substr(index, 2u), nullptr, 16)));
    }
    return result;
}

void write_zip(const fs::path& path, bool deflated = false)
{
    struct Entry {
        std::string name;
        std::string data;
        std::string archive_data;
        std::uint16_t method;
        std::uint32_t offset;
    };
    std::vector<Entry> entries = {
        {"product/bin/probe.txt", "synthetic-version-1\n",
         deflated ? bytes_from_hex("2baecc2bc9482dc94cd62d4b2d2acecccfd335e40200") : "synthetic-version-1\n",
         static_cast<std::uint16_t>(deflated ? 8 : 0), 0},
        {"product/data/config.ini", "enabled=true\n",
         deflated ? bytes_from_hex("4bcd4b4cca494db12d292a4de50200") : "enabled=true\n",
         static_cast<std::uint16_t>(deflated ? 8 : 0), 0}};
    std::vector<unsigned char> bytes;
    for (Entry& entry : entries) {
        entry.offset = static_cast<std::uint32_t>(bytes.size());
        append32(bytes, 0x04034b50u); append16(bytes, 20); append16(bytes, 0); append16(bytes, entry.method);
        append16(bytes, 0); append16(bytes, 0); append32(bytes, crc32(entry.data));
        append32(bytes, static_cast<std::uint32_t>(entry.archive_data.size()));
        append32(bytes, static_cast<std::uint32_t>(entry.data.size()));
        append16(bytes, static_cast<std::uint16_t>(entry.name.size())); append16(bytes, 0);
        bytes.insert(bytes.end(), entry.name.begin(), entry.name.end());
        bytes.insert(bytes.end(), entry.archive_data.begin(), entry.archive_data.end());
    }
    const std::uint32_t central_offset = static_cast<std::uint32_t>(bytes.size());
    for (const Entry& entry : entries) {
        append32(bytes, 0x02014b50u); append16(bytes, 0x0314u); append16(bytes, 20);
        append16(bytes, 0); append16(bytes, entry.method); append16(bytes, 0); append16(bytes, 0);
        append32(bytes, crc32(entry.data)); append32(bytes, static_cast<std::uint32_t>(entry.archive_data.size()));
        append32(bytes, static_cast<std::uint32_t>(entry.data.size()));
        append16(bytes, static_cast<std::uint16_t>(entry.name.size())); append16(bytes, 0);
        append16(bytes, 0); append16(bytes, 0); append16(bytes, 0); append32(bytes, (0100644u << 16));
        append32(bytes, entry.offset); bytes.insert(bytes.end(), entry.name.begin(), entry.name.end());
    }
    const std::uint32_t central_size = static_cast<std::uint32_t>(bytes.size()) - central_offset;
    append32(bytes, 0x06054b50u); append16(bytes, 0); append16(bytes, 0);
    append16(bytes, static_cast<std::uint16_t>(entries.size()));
    append16(bytes, static_cast<std::uint16_t>(entries.size()));
    append32(bytes, central_size); append32(bytes, central_offset); append16(bytes, 0);
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
}

std::string execute(usk_context* context, const char* command, const Value& payload, int dry_run, int& status)
{
    const std::string json = usk::json::canonical(payload);
    usk_command_request_v1 request{};
    usk_command_response_v1 response{};
    request.struct_size = sizeof(request);
    request.command_name = {command, static_cast<usk_size>(std::char_traits<char>::length(command))};
    request.json_payload = {json.data(), static_cast<usk_size>(json.size())};
    request.dry_run = dry_run;
    response.struct_size = sizeof(response);
    status = usk_command_execute_v1(context, &request, &response);
    return response.json_payload.data == nullptr ? std::string() :
        std::string(response.json_payload.data, response.json_payload.size);
}

Value plan_request(const fs::path& archive, const fs::path& target, const std::string& source_hash)
{
    return Value(Value::Object{
        {"archive", Value(Value::Object{
            {"budgets", Value(Value::Object{{"max_depth", Value(std::uint64_t{32})},
                {"max_elapsed_ms", Value(std::uint64_t{30000})}, {"max_entries", Value(std::uint64_t{100})},
                {"max_entry_bytes", Value(std::uint64_t{1048576})}, {"max_ratio", Value(std::uint64_t{100})},
                {"max_uncompressed_bytes", Value(std::uint64_t{10485760})}})},
            {"expected_sha256", Value(source_hash)}, {"format", Value("zip")},
            {"path", Value(archive.u8string())}, {"strip_prefix", Value("product")}})},
        {"created_at", Value("2026-07-14T01:00:00Z")}, {"install_id", Value("synthetic.install.1")},
        {"recipe", Value(Value::Object{
            {"components", Value(Value::Array{Value("base")})},
            {"entrypoints", Value(Value::Array{Value(Value::Object{
                {"entrypoint_id", Value("probe")}, {"kind", Value("tool")},
                {"relative_path", Value("bin/probe.txt")}})})},
            {"product_id", Value("synthetic.product")}, {"product_version", Value("1.0.0")},
            {"provider_revision", Value("test.provider.1")}, {"recipe_digest", Value(std::string(64, 'a'))}})},
        {"request_id", Value("plan.install.1")}, {"schema", Value("usk.install_local_plan_request.v1")},
        {"target", Value(Value::Object{{"class", Value("operator_acceptance")},
            {"root", Value(target.generic_u8string())}})}});
}

Value apply_request(
    const char* schema,
    const Value& plan,
    const std::string& plan_id,
    const std::string& plan_digest,
    const std::string& transaction_id,
    const std::string& applied_at)
{
    return Value(Value::Object{{"applied_at", Value(applied_at)}, {"confirmation", Value("APPLY")},
        {"plan_request", plan}, {"reviewed_plan_digest", Value(plan_digest)},
        {"reviewed_plan_id", Value(plan_id)}, {"schema", Value(schema)},
        {"transaction_id", Value(transaction_id)}});
}

void write_text(const fs::path& path, const std::string& text)
{
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output << text;
}

std::string read_text(const fs::path& path)
{
    std::ifstream input(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}

bool retained_roots_match(const Value& payload, const std::set<std::string>& expected)
{
    const auto& actions = payload.at("available_actions").as_array();
    if (actions.size() != 1u || actions.front().as_string() != "retain_for_operator") return false;
    std::set<std::string> actual;
    for (const auto& effect : payload.at("effects").as_array()) {
        if (effect.at("kind").as_string() != "retain_path" ||
            effect.at("relative_path").as_string() != "." ||
            !actual.insert(effect.at("root_class").as_string()).second) return false;
    }
    return actual == expected;
}

int retained_stream_recovery_proof(usk_context* context, const fs::path& root, const fs::path& setup_root)
{
    const std::string plan_digest(64, '8');
    const usk::transaction::TransactionSpec spec{
        "tx.recovery.retained", "plan.recovery.retained", plan_digest, "install_local",
        setup_root / "staging", root / "retained-target", setup_root / "state", setup_root / "audit"};
    const std::string content = "identical retained payload";
    usk::base::Sha256 digest;
    digest.update(reinterpret_cast<const unsigned char*>(content.data()), content.size());
    fs::path staging;
    fs::path journal;
    {
        usk::transaction::TransactionSession interrupted(spec);
        staging = interrupted.staging_root();
        journal = interrupted.journal_path();
        bool supplied = false;
        interrupted.stage_file_stream("payload.txt", content.size(), digest.finish(), 64u * 1024u,
            [&](unsigned char* output, std::size_t capacity) -> std::size_t {
                if (supplied) return 0;
                if (capacity < content.size()) throw std::runtime_error("test buffer is too small");
                for (std::size_t index = 0; index < content.size(); ++index) output[index] = content[index];
                supplied = true;
                return content.size();
            });
        interrupted.mark_staged();
    }
    // A different object with identical bytes must never inherit deletion authority.
    const fs::path original = root / "original-retained-stream.txt";
    fs::rename(staging / "payload.txt", original);
    write_text(staging / "payload.txt", content);
    const std::string original_journal = read_text(journal);
    const Value inspection(Value::Object{
        {"install_id", Value("synthetic.interrupted.retained")}, {"operation", Value("install_local")},
        {"plan_digest", Value(plan_digest)}, {"plan_id", Value(spec.plan_id)},
        {"request_id", Value("recovery.inspect.retained")},
        {"schema", Value("usk.recovery_inspect_request.v1")},
        {"target_root", Value(spec.target_root.generic_u8string())},
        {"transaction_id", Value(spec.transaction_id)}});
    int status = USK_STATUS_ERROR;
    std::string response = execute(context, "recovery.inspect", inspection, 1, status);
    if (status != USK_STATUS_OK ||
        !retained_roots_match(usk::json::parse(response).at("payload"), {"staging"})) return 180;
    const Value plan(Value::Object{{"created_at", Value("2026-09-07T00:00:00Z")},
        {"inspection", inspection}, {"recovery_plan_id", Value("recovery.plan.retained")},
        {"schema", Value("usk.recovery_plan_request.v1")}});
    response = execute(context, "recovery.plan", plan, 1, status);
    if (status != USK_STATUS_OK ||
        !retained_roots_match(usk::json::parse(response).at("payload"), {"staging"})) return 181;
    const std::string reviewed = usk::json::parse(response).at("payload").at("plan_digest").as_string();
    const Value apply(Value::Object{
        {"applied_at", Value("2026-09-07T00:00:01Z")}, {"confirmation", Value("APPLY")},
        {"plan_request", plan}, {"reviewed_plan_digest", Value(reviewed)},
        {"reviewed_plan_id", Value("recovery.plan.retained")},
        {"schema", Value("usk.recovery_apply_request.v1")}, {"selected_action", Value("rollback")}});
    response = execute(context, "recovery.apply", apply, 0, status);
    if (status != USK_STATUS_ERROR || response.find("stale_plan") == std::string::npos ||
        read_text(staging / "payload.txt") != content || read_text(original) != content ||
        read_text(journal) != original_journal || fs::exists(spec.target_root)) return 182;
    fs::create_directory(spec.target_root);
    write_text(spec.target_root / "foreign.txt", "foreign target");
    response = execute(context, "recovery.inspect", inspection, 1, status);
    if (status != USK_STATUS_OK || !retained_roots_match(
            usk::json::parse(response).at("payload"), {"staging", "owned_target"}) ||
        read_text(spec.target_root / "foreign.txt") != "foreign target" ||
        read_text(staging / "payload.txt") != content || read_text(journal) != original_journal) return 183;
    return 0;
}

} // namespace

int main()
{
    const auto nonce = std::chrono::steady_clock::now().time_since_epoch().count();
    const fs::path root = fs::temp_directory_path() / ("usk-public-lifecycle-" + std::to_string(nonce));
    const fs::path archive = root / fs::u8path("synthetic-\xc3\xa9.zip");
    const fs::path setup_root = root / "setup-owned";
    const fs::path target = root / "managed-product";
    std::error_code error;
    fs::create_directories(root, error);
    if (error) return 1;
    write_zip(archive);

    usk_context* unavailable = nullptr;
    if (usk_context_create_v1(nullptr, &unavailable) != USK_STATUS_OK) return 2;
    int status = 0;
    const Value planned = plan_request(archive, target, usk::base::sha256_hex_file(archive));
    std::string response = execute(unavailable, "install_local.plan", planned, 1, status);
    if (status != USK_STATUS_ERROR || response.find("live_target_acceptance_required") == std::string::npos) return 3;
    usk_context_destroy_v1(unavailable);

    const std::string setup = setup_root.string();
    const std::string acceptance = root.string();
    usk_config_v1 config{};
    config.struct_size = sizeof(config);
    config.state_root = setup.c_str();
    config.authorized_acceptance_root = acceptance.c_str();
    config.target_policy_activation = "operator_acceptance_candidate";
    usk_context* context = nullptr;
    if (usk_context_create_v1(&config, &context) != USK_STATUS_OK) return 4;

    {
        const fs::path deflate_archive = root / "synthetic-deflate.zip";
        const fs::path deflate_setup_root = root / "setup-deflate";
        const fs::path deflate_target = root / "managed-deflate";
        write_zip(deflate_archive, true);
        const std::string deflate_setup = deflate_setup_root.string();
        usk_config_v1 deflate_config{};
        deflate_config.struct_size = sizeof(deflate_config);
        deflate_config.state_root = deflate_setup.c_str();
        deflate_config.authorized_acceptance_root = acceptance.c_str();
        deflate_config.target_policy_activation = "operator_acceptance_candidate";
        usk_context* deflate_context = nullptr;
        if (usk_context_create_v1(&deflate_config, &deflate_context) != USK_STATUS_OK) {
            return 60;
        }
        const Value deflate_plan_request = plan_request(
            deflate_archive,
            deflate_target,
            usk::base::sha256_hex_file(deflate_archive));
        response = execute(
            deflate_context, "install_local.plan", deflate_plan_request, 1, status);
        if (status != USK_STATUS_OK || fs::exists(deflate_target)) return 61;
        const std::string deflate_plan_digest =
            usk::json::parse(response).at("payload").at("plan_digest").as_string();
        const Value deflate_apply = apply_request(
            "usk.install_local_apply_request.v1",
            deflate_plan_request,
            "plan.install.1",
            deflate_plan_digest,
            "tx.deflate.install",
            "2026-07-14T01:00:01Z");
        response = execute(
            deflate_context, "install_local.apply", deflate_apply, 0, status);
        if (status != USK_STATUS_OK ||
            read_text(deflate_target / "bin/probe.txt") != "synthetic-version-1\n" ||
            read_text(deflate_target / "data/config.ini") != "enabled=true\n") {
            std::cerr << "deflate apply response: " << response << '\n';
            const fs::path first_audit = deflate_setup_root / "audit/chains/audit.synthetic.install.1/00000000000000000000.event.json";
            HANDLE probe = CreateFileW(first_audit.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
            std::cerr << "first audit path characters=" << first_audit.native().size() << "; OPEN_EXISTING error=" << GetLastError() << '\n';
            if (probe != INVALID_HANDLE_VALUE) CloseHandle(probe);
            return 62;
        }

        write_text(deflate_target / "bin/probe.txt", "corrupted\n");
        const Value deflate_repair_plan(Value::Object{
            {"archive", Value(Value::Object{
                {"expected_sha256", Value(usk::base::sha256_hex_file(deflate_archive))},
                {"format", Value("zip")}, {"path", Value(deflate_archive.u8string())},
                {"strip_prefix", Value("product")}})},
            {"install_id", Value("synthetic.install.1")},
            {"created_at", Value("2026-07-14T01:00:02Z")},
            {"plan_id", Value("plan.deflate.repair")},
            {"request_id", Value("repair.deflate.request")},
            {"schema", Value("usk.repair_plan_request.v1")}});
        response = execute(
            deflate_context, "repair.plan", deflate_repair_plan, 1, status);
        if (status != USK_STATUS_OK) {
            std::cerr << "deflate repair plan: " << response << '\n';
            return 63;
        }
        const std::string deflate_repair_digest =
            usk::json::parse(response).at("payload").at("plan_digest").as_string();
        const Value deflate_repair_apply = apply_request(
            "usk.repair_apply_request.v1",
            deflate_repair_plan,
            "plan.deflate.repair",
            deflate_repair_digest,
            "tx.deflate.repair",
            "2026-07-14T01:00:03Z");
        response = execute(
            deflate_context, "repair.apply", deflate_repair_apply, 0, status);
        if (status != USK_STATUS_OK ||
            read_text(deflate_target / "bin/probe.txt") != "synthetic-version-1\n") {
            return 64;
        }
        usk_context_destroy_v1(deflate_context);
    }

    const fs::path replaced_archive = root / "source-replacement.zip";
    const fs::path replaced_target = root / "source-replacement-target";
    write_zip(replaced_archive);
    const Value replacement_request = plan_request(
        replaced_archive, replaced_target, usk::base::sha256_hex_file(replaced_archive));
    response = execute(context, "install_local.plan", replacement_request, 1, status);
    if (status != USK_STATUS_OK || fs::exists(replaced_target)) return 32;
    const std::string replacement_digest =
        usk::json::parse(response).at("payload").at("plan_digest").as_string();
    {
        std::ofstream changed(replaced_archive, std::ios::binary | std::ios::app);
        changed << "changed-after-plan";
    }
    Value replacement_apply(Value::Object{
        {"applied_at", Value("2026-07-14T01:00:10Z")},
        {"confirmation", Value("APPLY")},
        {"plan_request", replacement_request},
        {"reviewed_plan_digest", Value(replacement_digest)},
        {"reviewed_plan_id", Value("plan.install.1")},
        {"schema", Value("usk.install_local_apply_request.v1")},
        {"transaction_id", Value("tx.source-replacement")}});
    response = execute(context, "install_local.apply", replacement_apply, 0, status);
    if (status != USK_STATUS_ERROR || fs::exists(replaced_target) ||
        fs::exists(setup_root)) return 33;

    const fs::path ancestor = root / "reviewed-ancestor";
    const fs::path ancestor_target = ancestor / "managed-product";
    fs::create_directory(ancestor);
    const Value ancestor_request = plan_request(
        archive, ancestor_target, usk::base::sha256_hex_file(archive));
    response = execute(context, "install_local.plan", ancestor_request, 1, status);
    if (status != USK_STATUS_OK || fs::exists(ancestor_target)) return 34;
    const std::string ancestor_digest =
        usk::json::parse(response).at("payload").at("plan_digest").as_string();
    fs::rename(ancestor, root / "reviewed-ancestor-displaced");
    fs::create_directory(ancestor);
    write_text(ancestor / "replacement-sentinel.txt", "retain");
    Value ancestor_apply(Value::Object{
        {"applied_at", Value("2026-07-14T01:00:20Z")},
        {"confirmation", Value("APPLY")},
        {"plan_request", ancestor_request},
        {"reviewed_plan_digest", Value(ancestor_digest)},
        {"reviewed_plan_id", Value("plan.install.1")},
        {"schema", Value("usk.install_local_apply_request.v1")},
        {"transaction_id", Value("tx.ancestor-replacement")}});
    response = execute(context, "install_local.apply", ancestor_apply, 0, status);
    if (status != USK_STATUS_ERROR || fs::exists(ancestor_target) ||
        read_text(ancestor / "replacement-sentinel.txt") != "retain" ||
        fs::exists(setup_root)) {
        std::cerr << "ancestor replacement stage: status=" << status
                  << " response=" << response
                  << " target=" << fs::exists(ancestor_target)
                  << " setup=" << fs::exists(setup_root) << '\n';
        return 35;
    }

    response = execute(context, "install_local.plan", planned, 1, status);
    if (status != USK_STATUS_OK || fs::exists(setup_root) || fs::exists(target)) return 5;
    const Value plan_response = usk::json::parse(response);
    const std::string plan_digest = plan_response.at("payload").at("plan_digest").as_string();
    if (plan_digest.size() != 64 ||
        plan_response.at("payload").at("totals").at("file_count").as_unsigned() != 2) return 6;
    const Value& planned_source = plan_response.at("payload").at("source");
    const Value& planned_target = plan_response.at("payload").at("target");
    if (planned_source.at("path").as_string() != archive.u8string() ||
        planned_source.at("path_identity_digest").as_string().size() != 64 ||
        planned_target.at("identity_digest").as_string().size() != 64 ||
        planned_target.at("path_identity_digest").as_string().size() != 64 ||
        !planned_target.at("filesystem").at("capabilities").at("local").as_boolean()) return 31;

    Value stale(Value::Object{{"applied_at", Value("2026-07-14T01:01:00Z")},
        {"confirmation", Value("APPLY")}, {"plan_request", planned},
        {"reviewed_plan_digest", Value(std::string(64, '0'))}, {"reviewed_plan_id", Value("plan.install.1")},
        {"schema", Value("usk.install_local_apply_request.v1")}, {"transaction_id", Value("tx.install.1")}});
    response = execute(context, "install_local.apply", stale, 0, status);
    if (status != USK_STATUS_ERROR || response.find("stale_plan") == std::string::npos ||
        fs::exists(setup_root) || fs::exists(target)) return 7;

    stale.as_object()["reviewed_plan_digest"] = Value(plan_digest);
    response = execute(context, "install_local.apply", stale, 0, status);
    if (status != USK_STATUS_OK || !fs::is_regular_file(target / "bin/probe.txt") ||
        !fs::is_regular_file(target / "data/config.ini") || !fs::is_directory(setup_root / "state")) return 8;

    response = execute(context, "install_local.apply", stale, 0, status);
    if (status != USK_STATUS_ERROR ||
        (response.find("target_not_empty") == std::string::npos &&
         response.find("stale_plan") == std::string::npos) ||
        read_text(target / "bin/probe.txt") != "synthetic-version-1\n" ||
        read_text(target / "data/config.ini") != "enabled=true\n") return 36;

    const Value plan_payload = plan_response.at("payload");
    Value evidence(Value::Object{
        {"archive", Value(Value::Object{
            {"filesystem_identity_digest", plan_payload.at("source").at("filesystem_identity_digest")},
            {"path_identity_digest", planned_source.at("path_identity_digest")},
            {"sha256", Value(usk::base::sha256_hex_file(archive))},
            {"size_bytes", plan_payload.at("source").at("size_bytes")},
            {"source_id", plan_payload.at("source").at("source_id")}})},
        {"automated_findings", Value(Value::Array{Value(Value::Object{
            {"classification", Value("passed_check")}, {"code", Value("install_closure_verified")},
            {"details_digest", Value(std::string(64, '4'))}, {"severity", Value("info")}})})},
        {"captured_at", Value("2026-07-14T01:01:30Z")},
        {"contract_versions", Value(Value::Array{
            Value(Value::Object{{"contract_id", Value("install_plan")},
                                {"schema_version", Value("usk.install_plan.v1")}}),
            Value(Value::Object{{"contract_id", Value("installed_state")},
                                {"schema_version", Value("usk.installed_state.v1")}})})},
        {"install_id", Value("synthetic.install.1")}, {"packet_id", Value("evidence.install.public.1")},
        {"plan", Value(Value::Object{{"expected_byte_count", plan_payload.at("totals").at("uncompressed_bytes")},
            {"expected_file_count", plan_payload.at("totals").at("file_count")},
            {"operation", Value("install_local")}, {"plan_digest", Value(plan_digest)},
            {"plan_id", Value("plan.install.1")}})},
        {"recipe_id", Value("recipe.synthetic.1")}, {"request_id", Value("evidence.capture.1")},
        {"schema", Value("usk.live_target_evidence_capture_request.v1")},
        {"snapshots", Value(Value::Object{{"post_target_digest", Value(
            usk::evidence::snapshot_target(target).snapshot_digest)},
            {"pre_target_digest", plan_payload.at("target").at("pre_snapshot_digest")}})},
        {"source_revisions", Value(Value::Array{
            Value(Value::Object{{"repository_id", Value("universal_setup")},
                                {"revision", Value(std::string(40, 'a'))}}),
            Value(Value::Object{{"repository_id", Value("product_consumer")},
                                {"revision", Value(std::string(40, 'b'))}})})},
        {"target", Value(Value::Object{
            {"class", Value("operator_acceptance")},
            {"filesystem", Value(Value::Object{
                {"capabilities", Value(Value::Object{{"local", Value(true)},
                    {"no_mount_redirection", Value(true)}, {"no_replace_commit", Value(true)},
                    {"stable_ancestors", Value(true)}})},
                {"identity_digest", planned_target.at("filesystem").at("identity_digest")},
                {"kind", planned_target.at("filesystem").at("kind")}})},
            {"identity_digest", planned_target.at("identity_digest")},
            {"path_identity_digest", planned_target.at("path_identity_digest")},
            {"persistent_effects", Value(Value::Array{Value("create owned target"),
                Value("write setup state"), Value("append audit chain")})}})},
        {"transaction", Value(Value::Object{{"staging_parent", Value((setup_root / "staging").generic_u8string())},
            {"target_root", Value(target.generic_u8string())}, {"transaction_id", Value("tx.install.1")}})}});
    response = execute(context, "live_evidence.capture", evidence, 0, status);
    if (status != USK_STATUS_OK || response.find("\"status\":\"pending\"") == std::string::npos ||
        !fs::is_regular_file(setup_root / "evidence/packets/evidence.install.public.1.json")) return 28;
    Value stale_evidence = evidence;
    stale_evidence.as_object()["packet_id"] = Value("evidence.install.public.stale");
    stale_evidence.as_object()["archive"].as_object()["sha256"] = Value(std::string(64, '0'));
    response = execute(context, "live_evidence.capture", stale_evidence, 0, status);
    if (status != USK_STATUS_ERROR || response.find("source_changed") == std::string::npos ||
        fs::exists(setup_root / "evidence/packets/evidence.install.public.stale.json")) return 29;
    Value stale_snapshot = evidence;
    stale_snapshot.as_object()["packet_id"] = Value("evidence.install.public.snapshot-drift");
    stale_snapshot.as_object()["snapshots"].as_object()["post_target_digest"] =
        Value(std::string(64, '0'));
    response = execute(context, "live_evidence.capture", stale_snapshot, 0, status);
    if (status != USK_STATUS_ERROR || response.find("target_changed") == std::string::npos ||
        fs::exists(setup_root / "evidence/packets/evidence.install.public.snapshot-drift.json")) return 30;

    const Value inspect(Value::Object{{"install_id", Value("synthetic.install.1")},
        {"request_id", Value("inspect.1")}, {"schema", Value("usk.installed_inspect_request.v1")}});
    response = execute(context, "installed.inspect", inspect, 1, status);
    if (status != USK_STATUS_OK || response.find("\"lifecycle_status\":\"installed\"") == std::string::npos) return 9;

    const Value verify(Value::Object{{"install_id", Value("synthetic.install.1")},
        {"report_id", Value("verify.public.1")}, {"request_id", Value("verify.request.1")},
        {"schema", Value("usk.installed_verify_request.v1")}, {"verified_at", Value("2026-07-14T01:02:00Z")}});
    response = execute(context, "installed.verify", verify, 1, status);
    if (status != USK_STATUS_OK || response.find("\"status\":\"pass\"") == std::string::npos) return 10;

    write_text(target / "bin/probe.txt", "damaged\n");
    const Value repair_plan(Value::Object{
        {"archive", Value(Value::Object{{"expected_sha256", Value(usk::base::sha256_hex_file(archive))},
            {"format", Value("zip")}, {"path", Value(archive.u8string())},
            {"strip_prefix", Value("product")}})},
        {"created_at", Value("2026-07-14T01:03:00Z")}, {"install_id", Value("synthetic.install.1")},
        {"plan_id", Value("plan.repair.1")}, {"request_id", Value("repair.request.1")},
        {"schema", Value("usk.repair_plan_request.v1")}});
    response = execute(context, "repair.plan", repair_plan, 1, status);
    if (status != USK_STATUS_OK) return 12;
    const std::string repair_digest = usk::json::parse(response).at("payload").at("plan_digest").as_string();
    const fs::path capacity_noise = root / "unrelated-capacity-noise.bin";
    {
        std::ofstream output(capacity_noise, std::ios::binary | std::ios::trunc);
        const std::vector<char> noise(4u * 1024u * 1024u, 'n');
        output.write(noise.data(), static_cast<std::streamsize>(noise.size()));
    }
    const Value repair_apply = apply_request("usk.repair_apply_request.v1", repair_plan,
        "plan.repair.1", repair_digest, "tx.repair.1", "2026-07-14T01:04:00Z");
    response = execute(context, "repair.apply", repair_apply, 0, status);
    if (status != USK_STATUS_OK || response.find("\"status\":\"completed\"") == std::string::npos) return 13;
    fs::remove(capacity_noise, error);
    if (error) return 27;
    {
        std::ifstream input(target / "bin/probe.txt", std::ios::binary);
        std::string restored((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
        if (restored != "synthetic-version-1\n") return 14;
    }

    const fs::path moved = root / "moved-product";
    const Value move_plan(Value::Object{{"created_at", Value("2026-07-14T01:05:00Z")},
        {"install_id", Value("synthetic.install.1")},
        {"new_target", Value(Value::Object{{"class", Value("operator_acceptance")},
            {"root", Value(moved.generic_u8string())}})},
        {"plan_id", Value("plan.move.1")}, {"request_id", Value("move.request.1")},
        {"schema", Value("usk.move_plan_request.v1")}});
    response = execute(context, "move.plan", move_plan, 1, status);
    if (status != USK_STATUS_OK || fs::exists(moved)) return 15;
    const std::string move_digest = usk::json::parse(response).at("payload").at("plan_digest").as_string();
    const Value move_apply = apply_request("usk.move_apply_request.v1", move_plan,
        "plan.move.1", move_digest, "tx.move.1", "2026-07-14T01:06:00Z");
    response = execute(context, "move.apply", move_apply, 0, status);
    if (status != USK_STATUS_OK || !fs::is_regular_file(moved / "bin/probe.txt") ||
        !fs::is_directory(target) || response.find("new_committed_old_retained") == std::string::npos) return 16;

    write_text(moved / "operator-note.txt", "foreign content\n");
    const Value uninstall_review(Value::Object{{"created_at", Value("2026-07-14T01:07:00Z")},
        {"install_id", Value("synthetic.install.1")}, {"plan_id", Value("plan.uninstall.review")},
        {"request_id", Value("uninstall.request.review")},
        {"schema", Value("usk.uninstall_plan_request.v1")}});
    response = execute(context, "uninstall.plan", uninstall_review, 1, status);
    if (status != USK_STATUS_OK || response.find("operator-note.txt") == std::string::npos) return 17;
    const std::string review_digest = usk::json::parse(response).at("payload").at("plan_digest").as_string();
    const Value uninstall_refused = apply_request("usk.uninstall_apply_request.v1", uninstall_review,
        "plan.uninstall.review", review_digest, "tx.uninstall.review", "2026-07-14T01:08:00Z");
    response = execute(context, "uninstall.apply", uninstall_refused, 0, status);
    if (status != USK_STATUS_ERROR || response.find("foreign_content_review_required") == std::string::npos ||
        !fs::is_regular_file(moved / "bin/probe.txt")) return 18;

    fs::remove(moved / "operator-note.txt", error);
    if (error) return 19;
    const Value uninstall_clean(Value::Object{{"created_at", Value("2026-07-14T01:09:00Z")},
        {"install_id", Value("synthetic.install.1")}, {"plan_id", Value("plan.uninstall.clean")},
        {"request_id", Value("uninstall.request.clean")},
        {"schema", Value("usk.uninstall_plan_request.v1")}});
    response = execute(context, "uninstall.plan", uninstall_clean, 1, status);
    if (status != USK_STATUS_OK) return 20;
    const std::string clean_digest = usk::json::parse(response).at("payload").at("plan_digest").as_string();
    const Value uninstall_apply = apply_request("usk.uninstall_apply_request.v1", uninstall_clean,
        "plan.uninstall.clean", clean_digest, "tx.uninstall.clean", "2026-07-14T01:10:00Z");
    response = execute(context, "uninstall.apply", uninstall_apply, 0, status);
    if (status != USK_STATUS_OK || fs::exists(moved) ||
        response.find("\"status\":\"completed\"") == std::string::npos) return 21;

    Value recovery_inspect(Value::Object{
        {"install_id", Value("synthetic.install.1")}, {"operation", Value("uninstall")},
        {"plan_digest", Value(clean_digest)}, {"plan_id", Value("plan.uninstall.clean")},
        {"request_id", Value("recovery.inspect.clean")},
        {"schema", Value("usk.recovery_inspect_request.v1")},
        {"target_root", Value((root / ".usk-uninstall-tx.uninstall.clean").generic_u8string())},
        {"transaction_id", Value("tx.uninstall.clean")}});
    Value wrong_recovery = recovery_inspect;
    wrong_recovery.as_object()["plan_digest"] = Value(std::string(64, '0'));
    response = execute(context, "recovery.inspect", wrong_recovery, 1, status);
    if (status != USK_STATUS_ERROR || response.find("lifecycle_refused") == std::string::npos) return 23;
    response = execute(context, "recovery.inspect", recovery_inspect, 1, status);
    if (status != USK_STATUS_OK || response.find("\"observed_state\":\"completed\"") == std::string::npos ||
        response.find("\"status\":\"inspection_only\"") == std::string::npos) return 24;
    const Value recovery_plan(Value::Object{{"created_at", Value("2026-07-14T01:11:00Z")},
        {"inspection", recovery_inspect}, {"recovery_plan_id", Value("recovery.plan.clean")},
        {"schema", Value("usk.recovery_plan_request.v1")}});
    response = execute(context, "recovery.plan", recovery_plan, 1, status);
    if (status != USK_STATUS_OK || response.find("\"schema\":\"usk.recovery_plan.v1\"") == std::string::npos ||
        usk::json::parse(response).at("payload").at("plan_digest").as_string().size() != 64) return 25;

    const std::string rollback_digest(64, '7');
    const usk::transaction::TransactionSpec rollback_spec{
        "tx.recovery.rollback", "plan.recovery.rollback", rollback_digest, "install_local",
        setup_root / "staging", root / "interrupted-target", setup_root / "state", setup_root / "audit"};
    {
        usk::transaction::TransactionSession interrupted(rollback_spec);
        interrupted.stage_file("payload.txt", {'r', 'o', 'l', 'l', 'b', 'a', 'c', 'k'});
        interrupted.mark_staged();
    }
    const Value rollback_inspect(Value::Object{
        {"install_id", Value("synthetic.interrupted.1")}, {"operation", Value("install_local")},
        {"plan_digest", Value(rollback_digest)}, {"plan_id", Value("plan.recovery.rollback")},
        {"request_id", Value("recovery.inspect.rollback")},
        {"schema", Value("usk.recovery_inspect_request.v1")},
        {"target_root", Value((root / "interrupted-target").generic_u8string())},
        {"transaction_id", Value("tx.recovery.rollback")}});
    const Value rollback_plan(Value::Object{{"created_at", Value("2026-07-14T01:12:00Z")},
        {"inspection", rollback_inspect}, {"recovery_plan_id", Value("recovery.plan.rollback")},
        {"schema", Value("usk.recovery_plan_request.v1")}});
    response = execute(context, "recovery.plan", rollback_plan, 1, status);
    if (status != USK_STATUS_OK || response.find("\"available_actions\":[\"rollback\"]") == std::string::npos) return 32;
    const std::string reviewed_recovery_digest =
        usk::json::parse(response).at("payload").at("plan_digest").as_string();
    const Value rollback_apply(Value::Object{
        {"applied_at", Value("2026-07-14T01:13:00Z")}, {"confirmation", Value("APPLY")},
        {"plan_request", rollback_plan}, {"reviewed_plan_digest", Value(reviewed_recovery_digest)},
        {"reviewed_plan_id", Value("recovery.plan.rollback")}, {"schema", Value("usk.recovery_apply_request.v1")},
        {"selected_action", Value("rollback")}});
    response = execute(context, "recovery.apply", rollback_apply, 0, status);
    if (status != USK_STATUS_OK || response.find("\"status\":\"rolled_back\"") == std::string::npos ||
        fs::exists(setup_root / "staging/.usk-stage-tx.recovery.rollback") ||
        fs::exists(root / "interrupted-target")) return 33;

    if (const int retained = retained_stream_recovery_proof(context, root, setup_root)) return retained;
    usk_context_destroy_v1(context);
    fs::remove_all(root, error);
    return error ? 26 : 0;
}
