# Path-admission design notes from the reviewed ZIP source

Source inspected: c7db3eeb04a1408d4abb6ee11204ca5e6c3bc40d, tree2e3d57c6d3050b19d22ca97b00bd9787f7d6a900. No implementation yet; normal PR28 promotion is in progress.

## Chosen bounded direction

Implement explicit conservative native Windows path admission, not partial extended-path support. Public32768-character schema limits are syntax/input budgets and must be documented as distinct from supported native effect capacity. Count native UTF-16 code units on Windows, not UTF-8 bytes or Unicode scalar values; validate file and directory capacities separately and include all ancestor directories/components. Retain public UNC/device namespace refusal and existing object-ownership/reparse/no-replace behavior.

Primary references: [Microsoft maximum path documentation](https://learn.microsoft.com/en-us/windows/win32/fileio/maximum-file-path-limitation) describes MAX_PATH and directory suffix room, and requires both application manifest and host configuration for ordinary-path opt-in. [CreateDirectory documentation](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-createdirectory) describes directory/component constraints. A library must not infer its host process manifest or change machine settings. A conservative explicit support bound is acceptable if documented and tested at its precise admitted/refused boundary.

Prefer reusable pure admission in the existing base path module, with a typed refusal surfaced publicly, plus complete lifecycle operation-path preflight. Low-level record creation/read/move guards are useful defense in depth but cannot replace public/lifecycle checks before setup/audit/transaction effects.

## Concrete effect inventory

- Public initialize_setup_root currently creates setup root/marker and standard state,staging,audit directories before lifecycle apply. Validate known setup layout before that call.
- Install audit chain is audit/chains/audit.<install_id>; event names are20decimal digits plus .event.json (31characters). This complete path is known at plan time and caused the reproduced262-character failure.
- Transaction staging is staging/.usk-stage-<transaction_id>; journal is state/transactions/<transaction_id>.journal.json; atomic journal updates derive an additional .tmp.<sequence> suffix. Reserve the full uint64 decimal width for that temporary suffix.
- Installed immutable snapshots are state/installed/<install_id>.<transaction_id>.json; ownership records are state/ownership/ownership.<install_id>.<transaction_id>.json. Validate complete derived filenames, and existing identifier limits, before exposing a target.
- Install entry files/directories need capacity under both staging and final target. The transaction ID is selected at apply, so plan validates known paths and apply validates exact transaction-derived paths before any initialization/effect; do not reserve arbitrary128-character IDs in every plan and thereby reject ordinary supported roots.
- Repair uses target-parent/.usk-repair-<transaction_id>, with payload/<relative> and backup/<relative> paths in that bundle and payload/<relative> in staging. Revalidate before transaction construction.
- Move uses new-root.parent/.usk-stage-<transaction_id>, the complete old/new closure and new immutable records; uninstall uses target-parent/.usk-uninstall-<transaction_id> and operation.marker plus new installed snapshot/audit paths. Revalidate before transaction construction or deletes.
- Recovery finalization may write ownership,installed state,journal temporaries and audit completion. It needs the same exact operation admission; retain-only rollback remains refused.
- Live evidence capture/verdict writes setup/evidence/packets/<packet_id>.json. Preflight complete requested IDs before setup-root or evidence-directory creation.

Do not expand the path task into rewriting legacy pathname-delete ownership behavior. Existing non-streaming remove_exact_file/empty-directory cleanup remain separately identified object-bound cleanup debt.

## Meaningful test requirements

1. Pure native-path boundary tests for file/directory limits, ancestors, components and UTF-16 surrogate pairs; compare equal native lengths represented by different UTF-8 byte lengths.
2. Reproduce the same long owned fixture prefix and262-character audit path; public plan/apply must return the documented stable admission refusal before setup marker,state,audit chain,journal,staging or target changes. Preserve a pre-existing foreign sentinel and exact before/after directory evidence.
3. A plan with ordinary roots and a later chosen long transaction ID must be revalidated before initialization/effects, including journal temporary names, installed snapshots and ownership filenames.
4. Explicit longest-admitted shorter paths must complete the intended operation; tests must distinguish directory and file budgets. Existing Unicode archive source paths exercise actual UTF-8/native round-trip; do not infer full lifecycle Unicode-persistence qualification from a pure capacity test.
5. Repair/move/uninstall/recovery must preserve existing source/foreign objects when derived paths are refused. Keep prior retention and source-identity regressions intact.
6. Update platform/schema descriptions and diagnostics; run focused native/Python/schema/strict checks, independent exact-source review, clean-source static/shared/combined SDK gates, then all required fresh hosted checks. Preserve original long-path/MSVC path failures as historical evidence, not successful qualification.
