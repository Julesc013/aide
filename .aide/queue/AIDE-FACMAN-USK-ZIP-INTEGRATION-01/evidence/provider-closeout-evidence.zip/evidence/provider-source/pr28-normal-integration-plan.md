# PR28 exact normal integration and canonical promotion

Root dispatch and current explicit user authorization permit the following normal checked merge chain after independent review `9cdeb498faddae6da583b44e9d6e2879e365ea8b9b6b3d2fa98332dae4b2409f`. The source tree is fixed at `2e3d57c6d3050b19d22ca97b00bd9787f7d6a900`; any changed source requires renewed review.

1. Verify PR28 head `c7db3eeb04a1408d4abb6ee11204ca5e6c3bc40d` into dev `0edbbd478f2f322c76954a169f8afc809cf2d051`, all twelve successful exact-head fresh push/PR checks, normal mergeability, and the reviewed source tree. Merge normally with exact-head protection and record the resulting dev commit/tree. The source-identical checkpoint `8a0504c2f59e4cf76b49790761b18e3f75b20554` passed all three clean-source SDK phases; original nested-path failures remain recorded.
2. Open resulting dev to current main `2f213e202dea18dfee024c5c60b761f6afe305e7`, after verifying main ancestry and unchanged reviewed candidate tree. Require both complete fresh/current six-job push and PR workflows before exact-head normal promotion. Record exact commits and source tree.
3. Open resulting canonical main back into dev. Require zero file changes, the same source tree, and twelve successful current/fresh checks before exact-head normal ancestry synchronization. Record the final heads and tree equality.
4. Fast-forward local main/dev only after remote completion and return primary clean dev. Preserve reviewed task ancestry, source manifests, diagnostics and both existing evidence worktrees. No force/reset/rebase, direct protected write, self-approval, settings change or protection bypass. No provider consumer pin change and no AIDE writes.

PR27 canonical promotion/sync is already complete in PR32/PR33. This chain keeps the one-completed-unpromoted-unit invariant. USK native branch policy passes; prior external helper/policy receipts remain attached. Current explicit user/root normal-merge authority governs this session despite the older default self-merge restriction.

After the source checkpoint is integrated/promoted, proceed to the separate `USK-WINDOWS-PATH-ADMISSION-01` external follow-on plan with exact fresh-dev branch/hygiene checks. Windows deep-path support is not inferred from this ZIP qualification.
