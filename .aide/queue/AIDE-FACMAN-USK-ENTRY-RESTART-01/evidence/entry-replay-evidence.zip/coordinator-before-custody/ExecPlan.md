# Complete restartable provider entry journals

The running bounded slice is USK-ENTRY-STREAM-JOURNAL-AND-RESTART-01 on task/usk-entry-stream-journal-and-restart-01, starting at provider dev 5e4c660890201accb30a14ed31b97d329a3be3cd (tree 3faabe599f2ebe5f2a6f87287693f411fe1d6594). Current explicit user authority and root dispatch cover source implementation, validation and reviewed normal integration. Queue completion remains pending.

1. Record current source, native branch policy, pure AIDE detection/plan and measured owned development roots. Preserve both evidence worktrees; no new worktree or cleanup.
2. Prove the missing durable pending-entry record and acceptance of same-byte substituted completed staging in targeted native regressions.
3. Persist entry identity and intent/writing/complete observations, capturing output identity from its original creation handle. Add explicit source replay into a fresh transaction with exact prior snapshot, source, plan and root binding, durable lineage before new effects, and retained old staging.
4. Refuse replay after any prior committing transition. Exercise process exits, same-byte replacement, changed inputs, concurrent no-replace losers, bounded memory and successful separate visible-target finalization. Run direct schema/Python/native and strict checks.
5. Freeze exact source, patch, artifacts and receipts for independent review; remediate findings before checkpoint. Run clean-source static/shared/combined SDK gates before non-force push, then fresh hosted checks and exact-head normal task/dev/main/ancestry integration.
6. Update this coordinator only to its demonstrated acceptance. Preserve separate generation/lease/stale-owner reconciliation and provider-package qualification tasks. No FacMan pin adoption, automatic recovery, byte-offset Deflate restart or retained-child cleanup claim.

New external source evidence is retained in the existing marker-owned provider task root, tasks/usk-s27/evidence, under entry-restart-* names. Before queue closeout, compact exact bytes and member hashes into navigable task-owned custody. AIDE index and staging remain with the integration worker.

The directory-replay slice is one checkpoint within this task. Keep task status
running and result PENDING until the next bounded slice implements stored and
Deflate ZIP entry replay from byte zero with exact archive/source/entry identity
and crash custody. Do not move that remaining dispatch work into generation
leases. The separate [commit-authority obligation](evidence/commit-authority-follow-on.md)
remains a prerequisite for full provider adoption and Beta qualification.

The directory checkpoint completed its reviewed source/SDK/PR39/PR40/PR41 chain at dev d835167a5febf17c33aaa133bfeb284ce3b10df7. The active next slice is task/usk-zip-entry-replay-01 from that exact dev. Its explicit optional public replay request binds original transaction, full snapshot and audit head; each replay creates a fresh no-replace audit chain linked to the captured old context and retains the old chain unchanged. Original setup creation is reconciled only through versioned source-digested journal context and exact recorded native root identities, while preserving policy/source/target comparisons. Freeze independent source/evidence review before checkpoint and repeat all clean-source and hosted gates. Keep this coordinator running/PENDING until ZIP replay acceptance is demonstrated.
