from pathlib import Path
import ctypes,ctypes.wintypes as w,json,time,hashlib,platform
root=Path(r'C:\Users\Jules\AppData\Local\FacMan\Development\repositories\universal-setup-db9c210f4a17\tasks\usk-s27'); e=root/'evidence'; base=root/'t'/('cc-'+str(time.time_ns()))
assert (root/'.facman-development-root.v1.json').is_file() and not base.exists() and base.resolve().parent==(root/'t').resolve()
base.mkdir(); source=base/'s'; sub=source/'d'; sub.mkdir(parents=True); (sub/'f').write_bytes(b'owned')
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateFileW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,ctypes.c_void_p,w.DWORD,w.DWORD,w.HANDLE]; k.CreateFileW.restype=w.HANDLE
k.CloseHandle.argtypes=[w.HANDLE]; k.CloseHandle.restype=w.BOOL
k.SetFileInformationByHandle.argtypes=[w.HANDLE,ctypes.c_int,ctypes.c_void_p,w.DWORD]; k.SetFileInformationByHandle.restype=w.BOOL
handles=[]; results=[]
def acquire(path,access,share,flags):
 h=k.CreateFileW(str(path),access,share,None,3,flags,None)
 if h==ctypes.c_void_p(-1).value: raise ctypes.WinError(ctypes.get_last_error())
 handles.append(h); results.append({'operation':'CreateFileW','path':str(path),'desired_access':hex(access),'share_mode':hex(share),'flags':hex(flags),'creation_disposition':3,'success':True}); return h
def rename(handle,target,label):
 text=str(target)
 class RenameInfo(ctypes.Structure): _fields_=[('ReplaceIfExists',w.BOOLEAN),('RootDirectory',w.HANDLE),('FileNameLength',w.DWORD),('FileName',w.WCHAR*(len(text)+1))]
 info=RenameInfo(); info.ReplaceIfExists=False; info.RootDirectory=None; info.FileNameLength=len(text.encode('utf-16-le')); info.FileName=text
 ctypes.set_last_error(0); ok=k.SetFileInformationByHandle(handle,3,ctypes.byref(info),ctypes.sizeof(info)); result={'operation':label,'success':bool(ok),'winerror':ctypes.get_last_error(),'file_information_class':3,'replace_if_exists':False,'root_directory':None,'file_name_length':info.FileNameLength,'structure_bytes':ctypes.sizeof(info)}; results.append(result); return result
try:
 rh=acquire(source,0x10000|0x80,1|2,0x02000000|0x00200000)
 dh=acquire(sub,0x80000000,1,0x02000000|0x00200000)
 fh=acquire(sub/'f',0x80000000,1,0x00200000)
 for old,new in [(sub/'f',base/'foreign-file'),(sub,base/'foreign-dir'),(source,base/'foreign-root')]:
  try: old.rename(new); result={'operation':'pathname rename','source':str(old),'success':True}
  except OSError as ex: result={'operation':'pathname rename','source':str(old),'success':False,'winerror':ex.winerror}
  results.append(result)
 try:
  with (sub/'added').open('xb') as output: output.write(b'foreign descendant')
  results.append({'operation':'add child while all handles held','success':True})
 except OSError as ex: results.append({'operation':'add child while all handles held','success':False,'winerror':ex.winerror})
 held=rename(rh,base/'target','root handle rename with descendants held')
 for h in [fh,dh]:
  assert k.CloseHandle(h); handles.remove(h)
 control=rename(rh,base/'target','same root handle rename after descendants close')
finally:
 for h in reversed(handles): k.CloseHandle(h)
receipt={'schema':'usk.synthetic-native-commit-probe.v1','source_file':Path(__file__).name,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'platform':platform.platform(),'root':str(base),'results':results,'snapshot':[str(p.relative_to(base)) for p in base.rglob('*')],'source_mutation':False,'cleanup':False}
p=e/'child-commit-native-control-result.json'; assert not p.exists(); p.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n'); print(json.dumps(receipt))
assert not held['success'] and control['success']
