An interrupted stored or Deflate ZIP install can now be explicitly replayed from byte zero into a fresh transaction. The original reviewed plan, exact journal snapshot, archive object/entry identity and audit context are revalidated before effects. Durable lineage precedes a new exclusive audit chain; old staging, journals and audit bytes remain retained and unchanged. Any uncertain ancestor commit refuses replay, including when the target is now absent.

Public C ABI 1.0 and ordinary request shapes remain unchanged. Recovery inspection observes at most 32 audit events and preserves inspection with a null audit digest beyond that cap; replay admission independently retains its one-event precommit bound. See [the bounded ZIP replay contract](docs/architecture/zip_entry_replay.md).

Validation: independent source review passed for tree `ec2255adf6d095951ca8b6fee01d5300c9b8e6bc`; all 20 native runtime/ABI suites, 56 Python tests and strict checks pass. Regressions preserve 50 process-exit boundaries, identical-byte source/root substitutions, replay lineage, competing commits and the valid 32/33-event audit boundary. Clean-source static/shared/combined SDK gates also pass on this clean checkpoint. Fresh exact-head hosted checks remain required before merge.

Durable evidence: `external:usk-s27/evidence/zip-entry-replay-audit-cap-candidate-review.json` (SHA256 `bdbee21b00c7b6dda0887eedde3cf08a7c59eb0ef7776b978e3d0b43f78f4b71`), independent review `zip-entry-root-independent-review.json` (SHA256 `0e41cfc549e06ae4b3ccccf7f29ba35cede4bfcf0fcecd74d75b3459fc16c953`), and `zip-entry-replay-clean-sdk-receipt.json`. Earlier failures and original reviewed source/binaries remain preserved with byte custody. AIDE coordinator: `AIDE-FACMAN-USK-ENTRY-RESTART-01`.

Staged-child authority through the actual commit boundary, generation/stale-owner leases, retained cleanup and consumer adoption remain open prerequisites for full provider qualification. This explicit replay change does not claim automatic retry or Beta readiness.

Work-Item: USK-ENTRY-STREAM-JOURNAL-AND-RESTART-01
