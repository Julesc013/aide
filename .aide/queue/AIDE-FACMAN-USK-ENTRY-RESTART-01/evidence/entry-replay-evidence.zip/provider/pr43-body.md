Promote the reviewed explicit ZIP entry replay implementation from dev to main. PR42 passed all twelve fresh hosted checks; its merge preserves reviewed source tree `ec2255adf6d095951ca8b6fee01d5300c9b8e6bc` and clean-source static/shared/combined SDK qualification.

This promotion requires fresh exact-head hosted checks again. Replay retains original staging/audit state and rejects uncertain ancestor commits; the separate staged-child commit authority, generation/lease, cleanup and consumer adoption obligations remain open.

Evidence: `external:usk-s27/evidence/pr42-merge-receipt.json`, `zip-entry-replay-clean-sdk-receipt.json`, `zip-entry-root-independent-review.json`, and `pr43-exact-promotion-plan.json`.

Work-Item: USK-ENTRY-STREAM-JOURNAL-AND-RESTART-01
