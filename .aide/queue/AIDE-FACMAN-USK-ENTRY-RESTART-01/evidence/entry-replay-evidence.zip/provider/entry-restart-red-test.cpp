// SPDX-FileCopyrightText: 2026 Jules C
// SPDX-License-Identifier: MIT

#include "usk_json.h"
#include "usk_sha256.h"
#include "usk_transaction_session.h"

#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
namespace tx = usk::transaction;
namespace {
struct Fixture {
    fs::path root;
    Fixture() : root(fs::temp_directory_path() / ("usk-er-" + std::to_string(
        std::chrono::steady_clock::now().time_since_epoch().count())))
    {
        for (const auto* name : {"stage", "target", "state/transactions", "audit"}) {
            fs::create_directories(root / name);
        }
    }
    ~Fixture() { std::error_code ignored; fs::remove_all(root, ignored); }
    tx::TransactionSpec spec() const {
        return {"tx", "plan", std::string(64, 'a'), "install_local", root / "stage",
                root / "target/new", root / "state", root / "audit"};
    }
};
std::string read(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}
std::string digest(const std::string& bytes) {
    usk::base::Sha256 hash;
    hash.update(reinterpret_cast<const unsigned char*>(bytes.data()), bytes.size());
    return hash.finish();
}
void stage(tx::TransactionSession& session, const std::string& bytes) {
    std::size_t offset = 0;
    session.stage_file_stream("child/payload.bin", bytes.size(), digest(bytes), 4096,
        [&](unsigned char* data, std::size_t capacity) {
            const auto count = std::min(capacity, bytes.size() - offset);
            std::copy_n(bytes.data() + offset, count, data);
            offset += count;
            return count;
        });
}
int pending_entry() {
    Fixture fixture;
    tx::TransactionSession session(fixture.spec(), [](const std::string&, const std::string& point) {
        if (point == "before_stream_read") throw std::runtime_error("interrupted");
    });
    try { stage(session, "payload"); } catch (const std::runtime_error&) {}
    const auto journal = usk::json::parse(read(session.journal_path()));
    const auto& metadata = journal.at("recovery_metadata");
    if (metadata.as_object().count("stream_entries") == 0) return 201;
    const auto& entry = metadata.at("stream_entries").as_array().at(0);
    if (entry.at("relative_path").as_string() != "child/payload.bin" ||
        entry.at("phase").as_string() != "writing" ||
        entry.at("expected_size").as_unsigned() != 7 ||
        entry.at("sha256").as_string() != digest("payload")) return 202;
    return 0;
}
int substituted_completion() {
    Fixture fixture;
    tx::TransactionSession session(fixture.spec());
    stage(session, "payload");
    const auto path = session.staging_root() / "child/payload.bin";
    fs::rename(path, fixture.root / "original.bin");
    { std::ofstream output(path, std::ios::binary); output << "payload"; }
    session.mark_staged();
    bool refused = false;
    try { session.mark_verified(); } catch (const std::runtime_error&) { refused = true; }
    if (!refused) return 203;
    if (read(path) != "payload" || read(fixture.root / "original.bin") != "payload") return 204;
    return 0;
}
}
int main(int argc, char**) {
    try {
        const int result = argc > 1 ? substituted_completion() : pending_entry();
        if (result) std::cerr << "entry restart regression failed: " << result << '\n';
        return result;
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 250; }
}
