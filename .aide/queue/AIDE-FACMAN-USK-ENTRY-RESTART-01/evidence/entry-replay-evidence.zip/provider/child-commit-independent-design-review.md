# Independent staged-child commit authority design review

The proposed refusal-capable admission is appropriate. No stronger successful
commit protocol is qualified by current ordinary same-user filesystem access.
Keep legacy observation behavior explicit; never silently use it when a caller
requires child-bound commit authority.

Current source captures streamed file identity during creation, closes the
writer, checks a newly opened file in mark_verified, then releases that reader.
commit_effect checks roots and performs a pathname no-replace rename. It does
not retain original child objects or exclude newly added descendants. Original
nested-directory creation custody is also absent. Numeric journal IDs plus
matching bytes cannot recreate lost ownership; a restarted process must not
inherit a live capability from such observations.

The source-sealed Windows control probe strengthens the diagnosis: root rename
fails with held descendants and succeeds using the same root handle/structure
after only descendant handles close. Renaming existing objects fails while the
handles are held, but adding a new descendant succeeds. Thus the tested scheme
neither closes the namespace nor permits publication. The documented descendant
handle restriction is consistent with this observed result; POSIX rename flags
do not provide a documented escape from it. [Microsoft rename rules](https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information)

Linux rename preserves existing open file descriptions while changing directory
names. A directory FD secures a parent reference, not every child name.
Noncooperating same-UID actors can therefore bypass an advisory lease and replace
names. Making owner-controlled files read-only does not create a distinct
authority boundary because the owner can change their permissions.
[Linux rename](https://man7.org/linux/man-pages/man2/rename.2.html),
[open directory FDs](https://man7.org/linux/man-pages/man2/open.2.html),
[chmod ownership rules](https://man7.org/linux/man-pages/man2/chmod.2.html).
This is source/API reasoning; I ran no new Linux/macOS probe.

## Concrete success/refusal protocol

1. Add an explicit versioned requested guarantee to the native transaction and
   public plan/apply contract; bind it in plan/journal identity. Omitted requests
   preserve legacy behavior and never report the stronger guarantee.
2. A public required-guarantee request preflights before the transaction factory.
   Unsupported hosts return typed unavailable with no new staging or audit
   effects. Native commit must independently require an internal, unforgeable
   prepared authority object; a caller flag or previous capability query is
   insufficient. Existing staged attempts that cannot acquire it retain every
   object and return refused/unavailable before publication.
3. Exact admission covers original root, nested directory and file objects,
   complete entry set, no new descendants, destination parent, source lineage,
   hardlinks/reparse points, count/depth/handle/time budgets and no-replace
   semantics. Partial acquisition closes only acquired handles.
4. A future successful adapter requires an independently enforced protected
   namespace from original creation through publication, including the source
   and destination parent bindings. One coherent design is a separately
   authenticated OS broker principal with exclusive mutation authority; a
   caller-provided path, mode, ACL assertion or same-user lock is insufficient.
   The broker serializes its own writers and preserves a protected generation
   and commit record. This is a conditional design, not a claim that the broker
   or its OS boundary exists today.
5. Under that already enforced boundary, Windows can release descendant
   handles without admitting another writer, then use the retained root handle
   and a tested target-directory handle for no-replace rename. Linux uses
   retained parent directory FDs and renameat2(RENAME_NOREPLACE) while the
   protected namespace prevents last-component substitution. macOS needs its
   own equivalent native proof. Closing children first without independent
   protection is expressly invalid.
6. Persist commit intent before the primitive; success requires the exact
   adapter guarantee and truthful durability. Any lost authority, unsupported
   filesystem, conflicting destination or uncertain result retains all state.
   Historical committing/committed uncertainty still blocks replay; no final
   hash/lstat observation resolves publication history or restores a lost lease.

## Next bounded source scope

Introduce a small runtime/setup/transaction/usk_commit_authority.h/.cpp
requirement, capability and typed-refusal boundary; wire the existing
usk_transaction_session.h/.cpp and public install_local planning/apply request
schemas/dispatch so required mode cannot fall back. Add only the matching
journal/plan identity fields and validators, focused native/public tests,
CMake registration and transaction-model documentation. Initially report
strong success unavailable on all unqualified adapters. Closure observations
must not be labelled qualified authority. Original creation-handle custody
and a protected broker publication backend require their own admitted source
checkpoint and OS qualification; do not install accounts, services, ACLs,
drivers or mount machinery in this first slice.

Required tests distinguish known absence before effects from staged retained
refusal; exercise bypassing capability preflight, same-byte replacement with
the original retained elsewhere, added descendants, directory/parent swaps,
hardlinks, budget exhaustion, no-replace losers, dropped capability across
restart and process death at journal/publication boundaries. An actual effect
hook after the last observation must defeat an endpoint-only implementation.
For eventual successful adapters, require adversarial concurrent native
execution and exact supported filesystem/OS evidence.

Open OS questions: native Windows target RootDirectory access/share matrix and
same-volume no-replace success under a demonstrated protected namespace; source
and destination ancestor continuity; pre-existing writer/mapping exclusion;
durability and lost-result recovery; Linux/macOS ordinary-writer negative
probes and protected-boundary positive probes. The current controlled Windows
probe answers the naive-handle question, not these stronger adapter questions.
