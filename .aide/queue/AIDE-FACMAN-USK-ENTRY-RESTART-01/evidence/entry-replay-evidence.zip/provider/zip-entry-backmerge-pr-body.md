Synchronize the checked ZIP replay promotion back into dev so subsequent work starts from the canonical main ancestry. The merge preserves the exact reviewed source tree from PR #42 and promotion #43.

Validation: PR #43 passed fresh Linux/macOS/Windows/Win32, sanitizer, and fuzz checks. This backmerge requires its own fresh checks. No provider consumer pin, successful staged-child commit authority, signing, or release claim is added.

Work-Item: AIDE-FACMAN-USK-ENTRY-RESTART-01
