Synchronize the normal promotion merge from main back into dev after PR #40. The exact source tree remains `1eece0a67aba061e03aa59162dc57bffabec6793`; this PR changes ancestry only.

Directory replay was independently reviewed, passed all three clean-source SDK gates, and passed all twelve fresh checks on PRs #39 and #40. Require fresh checks on this exact ancestry head before normal merge.

The entry-restart coordinator remains running for stored/Deflate ZIP replay. Post-verification child identity through the commit boundary remains a separate provider qualification prerequisite.

Work-Item: USK-ENTRY-STREAM-JOURNAL-AND-RESTART-01
Evidence-Ref: https://github.com/Julesc013/universal-setup/pull/39
Evidence-Ref: https://github.com/Julesc013/universal-setup/pull/40
