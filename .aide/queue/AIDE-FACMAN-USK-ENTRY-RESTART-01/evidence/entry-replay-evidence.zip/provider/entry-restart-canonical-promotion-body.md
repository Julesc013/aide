Promote the independently reviewed explicit directory-entry replay checkpoint integrated by [PR39](https://github.com/Julesc013/universal-setup/pull/39). Source tree `1eece0a67aba061e03aa59162dc57bffabec6793` preserves the verified implementation and retention boundaries. Task head `26ce3b91597ce89270c59dcfe5739f754ec0da13` passed 55 Python, strict, 19 native/ABI tests, independent exact-source assurance and all three clean-source SDK gates; PR39 then passed all twelve fresh hosted checks.

This promotion adds no source changes beyond that accepted dev tree. Require the promotion head's complete fresh Checks before normal merge. ZIP stored/Deflate replay remains the next entry-restart slice; generation/commit authority and full provider/consumer qualification remain outstanding. AIDE coordinator stays running/PENDING.

Work-Item: USK-ENTRY-STREAM-JOURNAL-AND-RESTART-01
Evidence: `external:usk-s27/evidence/pr39-merge-receipt.json` and `entry-restart-canonical-promotion-plan.md`.
