# Recovery audit observation correction

ROOT independently verified the prior 27-file frozen candidate and reran all 20 native suites, 56 Python tests and strict checks. The review found one P2: the new optional audit-head observation used an unbounded chain read in public recovery inspection.

This exact three-file delta limits that observation to 32 events with the existing bounded reader and 1 MiB per-record limit. Missing, invalid and over-cap observations retain the existing null digest; journal inspection stays available. Replay admission still requires one exact precommit audit event for each of at most 64 retained ancestors. Historical unrelated audit callers are unchanged.

The public audit-bound regression constructs a valid chain at 32 events, checks the exact exposed head, then extends it to 33 and independently validates all 33. The public inspection must then succeed with a null audit digest, an unchanged journal snapshot hash and unchanged complete fixture bytes. It failed with exit 145 before the production change, then passed. All 20 native suites, all 56 Python tests and strict checks passed afterward.

Original packet, patch and 53 artifacts are unchanged. All original 27 raw source files and 20 executable bytes are preserved in zip-entry-replay-before-audit-cap.zip with an explicit member hash map. The new packet and complete patch replace no historical evidence. Source is frozen again for ROOT review; no commit or push is authorized by this receipt itself. Clean-source SDK and hosted checks remain required. Existing child-commit authority, generation/lease, retained-cleanup and adoption limitations remain open.
