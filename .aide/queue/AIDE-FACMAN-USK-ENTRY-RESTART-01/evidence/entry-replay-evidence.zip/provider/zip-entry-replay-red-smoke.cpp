// SPDX-FileCopyrightText: 2026 Jules C
// SPDX-License-Identifier: MIT

#include "usk_archive_payload.h"
#include "usk_audit_repository.h"
#include "usk_json.h"
#include "usk_lifecycle.h"
#include "usk_sha256.h"
#include "usk_transaction_session.h"

#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
using usk::json::Value;
namespace {
void append16(std::vector<unsigned char>& output, std::uint16_t value)
{
    output.push_back(static_cast<unsigned char>(value & 0xffu));
    output.push_back(static_cast<unsigned char>((value >> 8) & 0xffu));
}

void append32(std::vector<unsigned char>& output, std::uint32_t value)
{
    append16(output, static_cast<std::uint16_t>(value & 0xffffu));
    append16(output, static_cast<std::uint16_t>((value >> 16) & 0xffffu));
}

std::uint32_t crc32(const std::string& data)
{
    std::uint32_t crc = 0xffffffffu;
    for (unsigned char value : data) {
        crc ^= value;
        for (int bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
        }
    }
    return ~crc;
}

std::string bytes_from_hex(const std::string& value)
{
    if (value.size() % 2u != 0u) throw std::runtime_error("invalid fixture hex");
    std::string result;
    result.reserve(value.size() / 2u);
    for (std::size_t index = 0; index < value.size(); index += 2u) {
        result.push_back(static_cast<char>(
            std::stoul(value.substr(index, 2u), nullptr, 16)));
    }
    return result;
}

void write_zip(const fs::path& path, bool deflated = false)
{
    struct Entry {
        std::string name;
        std::string data;
        std::string archive_data;
        std::uint16_t method;
        std::uint32_t offset;
    };
    std::vector<Entry> entries = {
        {"product/bin/probe.txt", "synthetic-version-1\n",
         deflated ? bytes_from_hex("2baecc2bc9482dc94cd62d4b2d2acecccfd335e40200") : "synthetic-version-1\n",
         static_cast<std::uint16_t>(deflated ? 8 : 0), 0},
        {"product/data/config.ini", "enabled=true\n",
         deflated ? bytes_from_hex("4bcd4b4cca494db12d292a4de50200") : "enabled=true\n",
         static_cast<std::uint16_t>(deflated ? 8 : 0), 0}};
    std::vector<unsigned char> bytes;
    for (Entry& entry : entries) {
        entry.offset = static_cast<std::uint32_t>(bytes.size());
        append32(bytes, 0x04034b50u); append16(bytes, 20); append16(bytes, 0); append16(bytes, entry.method);
        append16(bytes, 0); append16(bytes, 0); append32(bytes, crc32(entry.data));
        append32(bytes, static_cast<std::uint32_t>(entry.archive_data.size()));
        append32(bytes, static_cast<std::uint32_t>(entry.data.size()));
        append16(bytes, static_cast<std::uint16_t>(entry.name.size())); append16(bytes, 0);
        bytes.insert(bytes.end(), entry.name.begin(), entry.name.end());
        bytes.insert(bytes.end(), entry.archive_data.begin(), entry.archive_data.end());
    }
    const std::uint32_t central_offset = static_cast<std::uint32_t>(bytes.size());
    for (const Entry& entry : entries) {
        append32(bytes, 0x02014b50u); append16(bytes, 0x0314u); append16(bytes, 20);
        append16(bytes, 0); append16(bytes, entry.method); append16(bytes, 0); append16(bytes, 0);
        append32(bytes, crc32(entry.data)); append32(bytes, static_cast<std::uint32_t>(entry.archive_data.size()));
        append32(bytes, static_cast<std::uint32_t>(entry.data.size()));
        append16(bytes, static_cast<std::uint16_t>(entry.name.size())); append16(bytes, 0);
        append16(bytes, 0); append16(bytes, 0); append16(bytes, 0); append32(bytes, (0100644u << 16));
        append32(bytes, entry.offset); bytes.insert(bytes.end(), entry.name.begin(), entry.name.end());
    }
    const std::uint32_t central_size = static_cast<std::uint32_t>(bytes.size()) - central_offset;
    append32(bytes, 0x06054b50u); append16(bytes, 0); append16(bytes, 0);
    append16(bytes, static_cast<std::uint16_t>(entries.size()));
    append16(bytes, static_cast<std::uint16_t>(entries.size()));
    append32(bytes, central_size); append32(bytes, central_offset); append16(bytes, 0);
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
}


std::string read(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}
struct Fixture {
    fs::path root = fs::temp_directory_path() /
        ("usk-zr-" + std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    usk::lifecycle::LifecycleRoots roots{root / "u/staging", root / "u/state", root / "u/audit"};
    Fixture() {
        fs::create_directories(roots.staging_parent);
        fs::create_directories(roots.state_root);
        fs::create_directories(roots.audit_root);
        usk::state::StateRepository::initialize_layout(roots.state_root);
        fs::create_directory(roots.state_root / "transactions");
        usk::audit::AuditRepository::initialize_layout(roots.audit_root);
    }
    ~Fixture() { std::error_code ignored; fs::remove_all(root, ignored); }
};
usk::lifecycle::InstallPlan plan(Fixture& fixture, bool deflate) {
    const fs::path archive = fixture.root / "source.zip";
    if (!fs::exists(archive)) write_zip(archive, deflate);
    const Value request(Value::Object{
        {"schema", Value("usk.archive_inspect_request.v1")},
        {"archive_path", Value(archive.u8string())},
        {"archive_format", Value("zip")},
        {"budgets", Value(Value::Object{
        {"max_entries", Value(std::uint64_t{100})},
        {"max_uncompressed_bytes", Value(std::uint64_t{10485760})},
        {"max_entry_bytes", Value(std::uint64_t{1048576})},
        {"max_ratio", Value(std::uint64_t{100})},
        {"max_depth", Value(std::uint64_t{32})},
        {"max_elapsed_ms", Value(std::uint64_t{30000})}})}});
    auto archive_payload = usk::archive::inspect_streaming_payload(usk::json::canonical(request), "product");
    usk::lifecycle::RecipeBinding recipe{"product", "1", std::string(64, 'a'),
        archive_payload.source_sha256, std::string(64, 'b'), "provider", {"base"},
        {{"probe", "bin/probe.txt", "tool"}}};
    std::vector<usk::lifecycle::PayloadFile> files;
    for (auto& entry : archive_payload.files) {
        files.push_back({entry.relative_path, {}, entry.sha256, entry.size_bytes,
                         std::move(entry.reader), archive_payload.payload_buffer_bytes});
    }
    return usk::lifecycle::plan_install("plan", "i", "2026-09-07T00:00:00Z",
        fixture.root / "target", fixture.roots, std::move(recipe), std::move(files));
}
int pending_source_binding() {
    for (bool deflate : {false, true}) {
        Fixture fixture;
        const auto planned = plan(fixture, deflate);
        bool interrupted = false;
        try {
            (void)usk::lifecycle::apply_install(planned, planned.plan_digest, "old",
                "2026-09-07T00:00:01Z", [&](const std::string&, const std::string& point) {
                    if (point == "transaction.staging.before_stream_read") {
                        interrupted = true;
                        throw std::runtime_error("entry interruption");
                    }
                });
        } catch (const std::runtime_error&) {}
        if (!interrupted) return 200;
        const auto journal = usk::json::parse(read(fixture.roots.state_root / "transactions/old.journal.json"));
        if (journal.at("recovery_metadata").at("stream_journal").at("source_digest").type() !=
                Value::Type::string) return 201;
    }
    return 0;
}
} // namespace
int main() {
    try { return pending_source_binding(); }
    catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 250; }
}
