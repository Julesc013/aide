# AIDE Dev/Main Plan

- schema_version: aide.dev-main-plan.v0
- generated_by: aide-lite
- repo_id: julesc013/aide
- non_mutating: true
- live_mutation_performed: false

## Branch Roles

- current_branch: task/aide-cw-integration-broker-01
- current_commit: 24ed66153f7e5d2008b7178b89c1b03025791152
- current_branch_role: task
- canonical_branch: main
- integration_branch: dev
- dev_is_canonical_truth: false

## Topology

- local_main_exists: true
- remote_origin_main_exists: true
- local_dev_exists: true
- remote_origin_dev_exists: true
- current_branch_tracks_remote: false
- upstream: not detected
- working_tree_clean: false

## Helper Dry-Runs

- plan: blocked
- sync: blocked
- land: blocked
- promote: blocked
- prune: ready_dry_run

## Future Explicit Operator Plan

These commands were not run by Q30:

- none

## Recommended Next Action

verify dev is integration and use Q29 helper dry-runs before any future land/promote operation

## Warnings

- dirty_tree_detected
- upstream_unavailable: fatal: no upstream configured for branch 'task/aide-cw-integration-broker-01'

## Q30 Boundary

Q30 does not create, push, merge, promote, prune, delete, fetch, tag, release, or
mutate live AIDE branches. `main` remains canonical truth and `dev` is planned
as shareable integration truth only.
