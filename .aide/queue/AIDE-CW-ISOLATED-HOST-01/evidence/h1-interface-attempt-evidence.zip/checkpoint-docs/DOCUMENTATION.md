# AIDE Documentation Index

## Purpose

`DOCUMENTATION.md` is the root guide and index for repository documentation. It defines how documentation should be organized, how authoritative documents relate to each other, and how documentation is kept aligned with reality.

## Documentation Families

- Governance docs define repository law, naming law, support policy, capability doctrine, release policy, and long-term architectural intent.
- Legal docs at the repository root define the Apache-2.0 license posture, NOTICE, generated-output boundary, contribution licensing, and trademark/project-identity boundary.
- Root control-plane docs define current state, contributor guidance, roadmap posture, maintenance posture, planning history, implementation logs, and documentation indexing.
- Self-hosting docs under `.aide/` define the Profile/Contract v0, filesystem queue, repo profile, autonomy policy, bypass policy, review-gate policy, and self-hosting declarations for future agent work.
- Harness docs under `core/harness/` and `docs/reference/harness-v0.md` define the Q04 executable command boundary for local structural validation and reports.
- Generated artifact docs under `docs/reference/generated-artifacts-v0.md` and `.aide/generated/manifest.yaml` define Q05 managed output boundaries, provenance markers, preview targets, and drift checks.
- Compatibility docs under `core/compat/`, `.aide/compat/**`, and `docs/reference/compatibility-baseline.md` define Q06 known version ids, no-op migration posture, replay metadata, upgrade gates, and deprecation records.
- Dominium Bridge docs under `bridges/dominium/**` and `docs/reference/dominium-bridge.md` define Q07 AIDE-side bridge metadata, XStack boundary, overlays, generated-target expectations, and compatibility pinning.
- Self-hosting automation docs under `docs/reference/self-hosting-automation.md`, `core/harness/**`, and `.aide/runs/**` define Q08 report-first checks and non-canonical report outputs.
- Token-survival, context, verifier, evidence-review, token-ledger, golden-task, outcome-controller, router, cache/local-state, Gateway skeleton, and provider-adapter docs under `.aide/policies/token-budget.yaml`, `.aide/policies/token-ledger.yaml`, `.aide/policies/verification.yaml`, `.aide/policies/evals.yaml`, `.aide/policies/controller.yaml`, `.aide/policies/routing.yaml`, `.aide/policies/cache.yaml`, `.aide/policies/local-state.yaml`, `.aide/policies/gateway.yaml`, `.aide/policies/provider-adapters.yaml`, `.aide/cache/**`, `.aide.local.example/**`, `.aide/gateway/**`, `.aide/providers/**`, `.aide/models/**`, `.aide/routing/**`, `.aide/prompts/**`, `.aide/memory/**`, `.aide/context/**`, `.aide/reports/**`, `.aide/verification/**`, `.aide/evals/**`, `.aide/controller/**`, `.aide/scripts/aide_lite.py`, `core/gateway/**`, `core/providers/**`, `docs/reference/token-survival-core.md`, `docs/reference/aide-lite.md`, `docs/reference/context-compiler-v0.md`, `docs/reference/verifier-v0.md`, `docs/reference/evidence-review-workflow.md`, `docs/reference/token-ledger.md`, `docs/reference/golden-tasks-v0.md`, `docs/reference/outcome-controller-v0.md`, `docs/reference/router-profile-v0.md`, `docs/reference/cache-local-state-boundary.md`, `docs/reference/gateway-skeleton.md`, and `docs/reference/provider-adapter-v0.md` define Q09 compact packets, Q10 deterministic AIDE Lite behavior, Q11 repo-map/test-map/context-packet behavior, Q12 mechanical verifier behavior, Q13 compact review-packet behavior, Q14 estimated token accounting, Q15 deterministic local golden tasks, Q16 advisory outcome recommendations, Q17 advisory route decisions, Q18 cache/local-state boundaries, Q19 local/report-only Gateway status behavior, and Q20 offline provider-adapter metadata.
- Checkpoint and repair docs under `.aide/queue/QCHECK-token-survival-foundation-audit/**`, `.aide/queue/QFIX-01-foundation-review-reconciliation/**`, and `.aide/queue/QFIX-02-aide-lite-test-discovery-runner/**` record the post-Q09-Q20 audit, reconciliation baseline, and AIDE Lite validation runner repair. QFIX-02 makes `py -3 .aide/scripts/aide_lite.py test` canonical while preserving exact tokenizer, provider billing, live Gateway/provider, and arbitrary coding-quality evidence as future work.
- Cross-repo pack docs under `.aide/policies/export-import.yaml`, `.aide/export/aide-lite-pack-v0/**`, `.aide/import/**`, `.aide/queue/Q21-cross-repo-pack-export-import-v0/**`, `.aide/queue/Q25-importer-scope-and-state-truth-repair/**`, `.aide/queue/Q26-eureka-pilot-review-and-handover/**`, `.aide/queue/Q31-export-pack-sync-git-commit-workflow/**`, and `docs/reference/cross-repo-pack-export-import.md` define portable AIDE Lite Pack export/import behavior, Q25 checksum/provenance and safe importer repair, Q26 Eureka pilot handover evidence, Q31 portable commit/task/Git governance export, fixture validation, target-specific profile and memory templates, and the boundary that excludes source repo identity, queue history, generated context, reports, latest status artifacts, local state, secrets, raw prompts, and raw responses.
- Existing-tool adapter compiler docs under `.aide/policies/adapters.yaml`, `.aide/adapters/**`, `.aide/generated/adapters/**`, `.aide/queue/Q24-existing-tool-adapter-compiler-v0/**`, and `docs/reference/existing-tool-adapter-compiler-v0.md` define Q24 compact generated or preview guidance for Codex/AGENTS, Claude Code, Aider, Cline, Continue, Cursor, and Windsurf without tool runtime calls, provider/model calls, network calls, or destructive overwrites.
- Interop export preview docs under `.aide/interop/exports/**`, `.aide/reports/interop-exports/**`, and `.aide/queue/AIDE-BUILD-INTEROP-EXPORTS-01/**` define static, deterministic preview artifacts for AGENTS, Claude, Copilot, Aider, MCP manifest, and A2A agent-card consumers without live MCP/A2A servers, Host Contract, Dominium Bridge conformance, Workbench, runtime, worker dispatch, provider/model/network calls, PatchTransaction apply, branch/worktree automation, release, promotion, or target-repository mutation.
- Commit discipline, WorkUnit recovery, and release draft docs under `.aide/policies/commit-messages.yaml`, `.aide/policies/changelog.yaml`, `.aide/policies/task-resumption.yaml`, `.aide/policies/work-units.yaml`, `.aide/policies/recovery.yaml`, `.aide/hooks/commit-msg`, `.aide/git/commit-template.md`, `.aide/changelog/**`, `.aide/queue/Q27-commit-discipline-workunit-recovery-v0/**`, `.aide/queue/Q34-changelog-release-notes-generator-v0/**`, `docs/reference/commit-discipline.md`, `docs/reference/workunit-idempotency.md`, and `docs/reference/changelog-preview.md` define Q27 structured commits, Q34 preview-only changelog/release-note drafts, replay-safe tasks, no-op detection, and repo-state-first recovery.
- Git workflow docs under `.aide/policies/git-workflow.yaml`, `.aide/policies/branch-roles.yaml`, `.aide/policies/promotion-rules.yaml`, `.aide/policies/sync-policy.yaml`, `.aide/policies/prune-policy.yaml`, `.aide/git/**`, `.aide/queue/Q28-git-workflow-policy-v0/**`, `.aide/queue/Q30-aide-dev-main-policy-sync/**`, `docs/reference/git-workflow-policy.md`, `docs/reference/branch-roles.md`, `docs/reference/promotion-policy.md`, and `docs/reference/aide-dev-main-workflow.md` define Q28 branch roles, `main`/`dev` semantics, report-only workflow detection, promotion gates, sync rules, prune guards, and Q30 AIDE-specific dev/main posture.
- Git helper docs under `.aide/git/helper-policy.yaml`, `.aide/git/helper-commands.md`, `.aide/git/latest-helper-plan.*`, `.aide/queue/Q29-merge-land-promote-helper-v0/**`, and `docs/reference/git-helper-workflow.md` define Q29 dry-run-first sync/land/promote/prune helper behavior, fixture-only mutation tests, live-repo no-mutation boundaries, and prune containment guards.
- GitHub advisory docs under `.aide/policies/github-protection.yaml`, `.aide/policies/ci-gates.yaml`, `.aide/policies/branch-protection.yaml`, `.aide/github/**`, `.aide/queue/Q35-github-protection-ci-advisory-v0/**`, and `docs/reference/github-protection-ci-advisory.md` define Q35 report-only GitHub branch-protection and CI gate advisory behavior without GitHub API calls, workflow creation, branch mutation, tags, releases, providers, models, or network calls.
- Intent compiler docs under `.aide/policies/intent.yaml`, `.aide/policies/workunit-sizing.yaml`, `.aide/policies/task-classes.yaml`, `.aide/policies/risk-classes.yaml`, `.aide/policies/prompt-normalization.yaml`, `.aide/intake/**`, `.aide/queue/Q36-intent-compiler-prompt-normalization-v0/**`, and `docs/reference/intent-compiler.md` define Q36 deterministic prompt normalization, task/risk/size classification, WorkUnit draft generation, and the no-raw-prompt-execution boundary.
- Long-turn operating protocol docs under `.aide/queue/AI-LONG-TURN-OPERATING-PROTOCOL-00/**` and `docs/planning/ai_long_turn_protocol/**` define docs-only templates for queue-governed long turns, validation ladders, stop conditions, manual evidence gates, queue handoffs, final reports, and failure recovery without authorizing runtime, branch, publication, target-repo, provider/model, Gateway, network, or external discovery work.
- Tentative product-vision planning docs under `docs/planning/product-vision/**`, `.aide/reports/tentative-product-vision-roadmap/**`, and `.aide/queue/AIDE-DOCS-TENTATIVE-PRODUCT-VISION-ROADMAP-01/**` record advisory synthesis for AIDE as universal development control plane, compatibility kernel, governance fabric, and living project twin while preserving the registered-process provider repair check as the next executable gate. These docs are not capability acceptance, runtime authority, queue-order authority, or implementation authorization.
- Project Intelligence planning docs under `docs/planning/project-intelligence-spine.md` and `.aide/queue/AIDE-PLAN-PROJECT-INTELLIGENCE-SPINE-01/**` record tentative guidance for extending Structure Intelligence into ProjectGraph, semantic records, health observers, ContextPack selection, Workbench views, safe refactoring recipes, and scale modes while preserving `.aide/queue/` as execution truth. These docs do not authorize implementation, file moves, deletes, root creation, reference rewrites, install or update apply, target mutation, release work, branch/worktree automation, network calls, provider/model calls, or public roadmap promotion.
- Repo intelligence docs under `.aide/policies/repo-intelligence.yaml`, `.aide/policies/file-classification.yaml`, `.aide/policies/ownership-map.yaml`, `.aide/policies/dependency-map.yaml`, `.aide/policies/test-map.yaml`, `.aide/policies/doc-link-map.yaml`, `.aide/repo/**`, `.aide/queue/Q37-repo-intelligence-index-v0/**`, and `docs/reference/repo-intelligence-index.md` define Q37 deterministic file inventory, ownership, dependency, test, documentation-link, generated-output, and orphan-candidate indexing without file moves, deletion, refactor, provider/model/network calls, or target-repo mutation.
- File quality docs under `.aide/policies/file-quality.yaml`, `.aide/policies/docs-consistency.yaml`, `.aide/policies/module-quality.yaml`, `.aide/policies/reuse-modularity.yaml`, `.aide/quality/**`, `.aide/reports/file-quality-*`, `.aide/queue/Q38-file-quality-ledger-v0/**`, and `docs/reference/file-quality-ledger.md` define Q38 deterministic advisory quality measurement without file moves, deletion, refactor, automatic fixes, provider/model/network calls, or target-repo mutation.
- Root recycling docs under `.aide/policies/root-recycling.yaml`, `.aide/policies/root-inventory.yaml`, `.aide/policies/root-fates.yaml`, `.aide/policies/root-exceptions.yaml`, `.aide/policies/root-risk.yaml`, `.aide/refactors/root-*.schema.json`, `.aide/roots/**`, `.aide/queue/Q40-root-recycling-framework-v0/**`, and `docs/reference/root-recycling-framework.md` define Q40 deterministic root inventory, root classification, file fate candidates, root risks, exceptions, and no-apply root plans without root moves, file deletion, reference rewrites, tool absorption, provider/model/network calls, or target-repo mutation.
- Tool absorption docs under `.aide/policies/tool-absorption.yaml`, `.aide/policies/tool-inventory.yaml`, `.aide/policies/tool-fates.yaml`, `.aide/policies/tool-wrapping.yaml`, `.aide/policies/tool-risk.yaml`, `.aide/policies/tool-capabilities.yaml`, `.aide/tools/**`, `.aide/queue/Q41-existing-tool-absorption-v0/**`, and `docs/reference/tool-absorption.md` define Q41 deterministic existing-tool discovery, capability classification, preservation fates, risk summaries, adapter maps, and no-execution wrap plans without unknown tool execution, deletion, rename, migration, active wrapping, provider/model/network calls, or target-repo mutation.
- Move/salvage/path-alias docs under `.aide/policies/move-map.yaml`, `.aide/policies/salvage-map.yaml`, `.aide/policies/path-aliases.yaml`, `.aide/policies/reference-rewrite.yaml`, `.aide/policies/migration-ledger.yaml`, `.aide/refactors/*map*`, `.aide/refactors/path-alias*`, `.aide/refactors/reference-rewrite*`, `.aide/queue/Q42-move-map-salvage-map-path-alias-v0/**`, and `docs/reference/move-salvage-path-aliases.md` define Q42 deterministic candidate move maps, salvage maps, path alias plans, reference rewrite plans, migration ledger drafts, and map validation without file moves, deletion, reference rewrites, alias/shim application, provider/model/network calls, or target-repo mutation.
- Structure audit planning docs under `.aide/queue/AIDE-STRUCTURE-00-current-truth-and-root-authority-audit/**`, `.aide/reports/structure-current-state.*`, `.aide/roots/latest-root-authority-candidates.*`, and `docs/planning/repository-structure/**` record check-only current-truth, generated-status, documentation-drift, and root-authority-candidate evidence before any future move maps, file moves, deletions, reference rewrites, root creation, provider/model/network calls, branch mutation, target-repo mutation, or release work.
- Root authority docs under `.aide/policies/root-authority.yaml`, `governance/root-authority.md`, `docs/reference/repository-layout.md`, `.aide/reports/root-authority-contracts.*`, and `.aide/queue/AIDE-STRUCTURE-01-root-authority-contracts/**` define the current review-gated Track B root authority contract, closed root model, overlap report, candidate target structure, migration rules, validation plan, and follow-up prompts without authorizing file moves, deletions, reference rewrites, aliases, shims, new top-level roots, generated-output source-truth promotion, branch mutation, target-repo mutation, provider/model/network calls, release work, or Track A protocol implementation.
- Repo layout inventory docs under `.aide/reports/repo-layout/**`, `.aide/queue/AIDE-BUILD-REPO-LAYOUT-INVENTORY-01/**`, and `docs/planning/repository-structure/repo-layout-inventory.md` record report-only Track B inventory facts for `.aide`, `core`, `.aide/reports`, duplicate names, flat report path assumptions, recommendations, and migration risks without authorizing file moves, deletes, renames, reference rewrites, report restructuring, generated OKF edits, generated-output source-truth promotion, branch mutation, target-repo mutation, provider/model/network calls, release work, or Track A protocol implementation.
- AIDE self-management docs under `.aide/policies/self-management.yaml`, `.aide/reports/self-management/**`, `.aide/queue/AIDE-BUILD-SELF-MANAGEMENT-CHARTER-01/**`, and `docs/reference/aide-self-management.md` define the review-gated doctrine that AIDE must manage AIDE as a repo using protocol, evidence, OKF, queue, generated-output, migration-safety, and reviewed-transaction discipline without implementing schemas, commands, generated-output ledgers, OKF regeneration, docs truth repair, queue acceptance, filesystem migration, runtime/provider behavior, branch mutation, target mutation, provider/model/network calls, or release work.
- Install planning docs under `.aide/policies/install*.yaml`, `.aide/install/**`, `.aide/queue/Q43-install-plan-model-v0/**`, and `docs/reference/aide-install-model.md` define Q43 deterministic install observation, candidate install plans, dry-run reports, ownership ledgers, conflict reports, preservation reports, and verification plans without install apply, overwrite, migration apply, file moves/deletes, reference rewrites, provider/model/network calls, or target-repo mutation.
- Repair/doctor docs under `.aide/policies/repair*.yaml`, `.aide/policies/doctor.yaml`, `.aide/repair/**`, `.aide/queue/Q44-repair-doctor-model-v0/**`, and `docs/reference/aide-repair-model.md` define Q44 deterministic repair observation, diagnosis, candidate repair plans, dry-run reports, doctor repair reports, repair classes, and verification plans without repair apply, overwrite, deletion, migration apply, file moves, reference rewrites, provider/model/network calls, or target-repo mutation.
- Upgrade docs under `.aide/policies/upgrade*.yaml`, `.aide/upgrade/**`, `.aide/queue/Q45-upgrade-model-v0/**`, and `docs/reference/aide-upgrade-model.md` define Q45 deterministic current-install observation, source-pack observation, compatibility comparison, candidate upgrade plans, dry-run reports, conflict reports, migration reports, and verification plans without upgrade apply, overwrite, deletion, migration apply, install/repair apply, file moves, reference rewrites, provider/model/network calls, or target-repo mutation.
- Rollback/uninstall docs under `.aide/policies/rollback*.yaml`, `.aide/policies/uninstall*.yaml`, `.aide/rollback/**`, `.aide/uninstall/**`, `.aide/queue/Q46-rollback-uninstall-model-v0/**`, and `docs/reference/aide-rollback-uninstall.md` define Q46 deterministic rollback and uninstall observation, candidate plans, dry-run reports, ownership-evidence gates, preservation boundaries, and verification plans without rollback apply, uninstall apply, deletion, overwrite, managed-section removal, file moves, reference rewrites, provider/model/network calls, or target-repo mutation.
- Release bundle and draft docs under `.aide/policies/release*.yaml`, `.aide/policies/github-release-draft.yaml`, `.aide/release/**`, `.aide/queue/Q47-aide-lite-release-bundle-v0/**`, `.aide/queue/Q48-github-release-draft-v0/**`, `docs/reference/aide-lite-release-bundle.md`, and `docs/reference/github-release-draft.md` define Q47 deterministic local bundle generation and Q48 deterministic local GitHub release draft generation without Git tags, GitHub Releases, uploads, GitHub API calls, branch mutation, active CI installation, target installs, provider/model/network calls, or publication.
- Task OS docs under `.aide/policies/task-lifecycle.yaml`, `.aide/policies/blockers.yaml`, `.aide/policies/repair-loop.yaml`, `.aide/policies/waves.yaml`, `.aide/policies/checkpoints.yaml`, `.aide/policies/dev-main-promotion.yaml`, `.aide/policies/capability-reality.yaml`, `.aide/tasks/**`, `.aide/ledgers/**`, `.aide/examples/task-os/**`, `.aide/queue/X-OS-00-aide-task-os-schemas-policies/**`, `.aide/queue/X-OS-01-aide-task-os-report-only-commands/**`, `docs/reference/task-os-v0.md`, `docs/reference/task-os-report-only-commands.md`, `docs/reference/workunit-lifecycle.md`, `docs/reference/blocker-and-repair-model.md`, and `docs/reference/checkpoint-and-promotion-model.md` define X-OS-00 WorkUnit lifecycle, blocker, repair, wave, checkpoint, branch provenance, and capability reality contracts plus X-OS-01 local report-only `task`, `blocker`, `wave`, and `checkpoint` inspection/planning commands without worker execution, branch mutation, target mutation, provider/model/network calls, promotion, release publication, or apply behavior.
- Transaction model docs under `.aide/policies/transactional-apply.yaml`, `.aide/policies/file-operations.yaml`, `.aide/policies/transaction-safety-gates.yaml`, `.aide/apply/**`, `.aide/examples/apply/**`, `.aide/queue/AIDE-APPLY-00-transaction-model/**`, `docs/reference/transaction-model.md`, `docs/reference/transactional-apply-roadmap.md`, `docs/reference/managed-section-operations.md`, and `docs/reference/rollback-records.md` define AIDE-APPLY-00 transaction schemas, file-operation classes, safety gates, fixture-only transaction planning, fixture verification, managed-section records, and rollback records without real repository apply, target mutation, branch/worktree mutation, provider/model/network calls, release publication, or install/repair/upgrade/rollback/uninstall apply behavior.
- Protocol and knowledge-plane docs under `.aide/protocol/**`, `core/protocol/**`, `core/knowledge/**`, `.aide/knowledge/okf/**`, `.aide/reports/okf/**`, and `.aide/queue/AIDE-BUILD-OKF-KNOWLEDGE-BUNDLE-01/**` define the current review-gated ContractEnvelope, EvidencePacket, WorkUnit, WorkerRun, TestJob, ReferenceID, EventRecord, and OKF-compatible markdown projection surfaces. OKF pages explain repo truth and link protocol/evidence context, but they do not become queue truth, protocol schema truth, evidence truth, execution authority, provider/model behavior, runtime knowledge service, search/vector index, visualizer, Reconciler, CapabilityManifest, ConformanceProfile, PatchTransaction, AdapterManifest, or ContextPack v2.
- Lifecycle fixture runner docs and evidence under `core/apply/lifecycle_fixture_runner.py`, `.aide/scripts/tests/test_aide_lifecycle_fixture_runner.py`, `.aide/reports/lifecycle-fixture-runner/**`, and `.aide/queue/AIDE-BUILD-LIFECYCLE-FIXTURE-RUNNER-01/**` define the first temp-only managed-section apply slice with path-jail checks, deterministic latest-run verification, rollback-compatible report records, and explicit `fixture_temp_apply_only` capability labeling without active repo apply, target repo apply, general lifecycle apply, service behavior, provider/model calls, or release readiness claims.
- Structural skeleton docs under `core/`, `hosts/`, and `bridges/` define Q02 target homes without moving bootstrap-era implementation.
- Constitution docs under `docs/constitution/` freeze baseline repository facts for the reboot.
- Charter docs under `docs/charters/` define bounded reboot goals, public models, internal splits, and non-goals.
- Reference docs under `docs/reference/` explain cross-cutting operational topics that do not belong to a narrower source, governance, or host-lane tree.
- Roadmap docs under `docs/roadmap/` define queue-driven reboot sequencing without adding calendar promises.
- Decision records under `docs/decisions/` capture ADR-like reboot decisions and their consequences.
- Design-mining docs under `docs/design-mining/` hold candidate lesson-extraction records; they are reference inputs, not AIDE doctrine.
- Inventory docs will record exact host families, extension technologies, manifests, and version coverage claims.
- Architecture docs under `specs/` describe shared-core boundaries, host adapter design, interfaces, and cross-cutting technical decisions.
- Boot-slice docs under `specs/boot-slice/` describe the first cross-host implementation target, lane acceptance criteria, degraded or blocked handling, and rollout order.
- Shared contract docs and schemas under `shared/` describe implementation-facing data shapes and subsystem boundaries that must remain aligned with the architecture docs.
- Shared implementation docs and tests under `shared/` describe the executable bootstrap runtime, the CLI bridge, and the deterministic verification layer that now backs the first boot slice.
- Host-lane implementation docs under `hosts/` describe thin lane-local proofs, blocked records, lane-specific execution-mode choices, and Q02 README-only host-category skeletons.
- Environment docs under `environments/` describe concrete setup models, acquisition posture, bring-up playbooks, snapshots, and machine-readable environment catalogs.
- Lab docs under `labs/` describe experimental, blocked, and archival environment-oriented work that has not yet been promoted into stable control-plane records.
- Evaluation docs under `evals/` describe evaluation models, verification routines, graders, playbooks, result vocabularies, and future run or report records.
- Packaging docs under `packaging/` describe artifact classes, manifest placeholders, release channels, signing posture, packaging checklists, and future release records.
- Maintenance docs under `scripts/maintenance/` describe recurring upkeep tasks, audit checklists, and automation boundaries.
- Repo-local skill docs under `.agents/` describe narrow reusable operational guidance for recurring AIDE work.
- Fixture docs under `fixtures/` describe deterministic requests, responses, and reproducible inputs used by shared-core verification and later host-adapter evals.
- User-facing docs will describe how to use released artifacts, bounded by what is actually shipped.

## Organization Conventions

- Keep authoritative governance material under `governance/`.
- Keep root contributor, roadmap, maintenance, and changelog docs at the repository root.
- Keep the canonical self-hosting queue and policy records under `.aide/`.
- Keep generated artifact manifests and preview-only generated outputs under `.aide/generated/`; generated outputs are not canonical truth.
- Keep Q02 target Core and Bridge skeletons under `core/` and `bridges/`, while preserving bootstrap-era implementation under `shared/` and existing proof lanes under `hosts/`.
- Keep reboot baseline records under `docs/constitution/`.
- Keep reboot goal and model statements under `docs/charters/`.
- Keep reusable explanatory reference docs under `docs/reference/`.
- Keep long-turn prompt, validation, gate, handoff, and report templates under `docs/planning/ai_long_turn_protocol/` unless a later reviewed docs-normalization task consolidates them into another documentation family.
- Keep Project Intelligence spine planning under `docs/planning/project-intelligence-spine.md` until a later reviewed task promotes narrower accepted reference material.
- Keep repository structure audit notes and Track B prompt shells under `docs/planning/repository-structure/`; root authority law now lives in `governance/root-authority.md` and `.aide/policies/root-authority.yaml`.
- Keep queue-specific reboot roadmap material under `docs/roadmap/`.
- Keep reboot decision records under `docs/decisions/`.
- Keep external-system lesson candidates under `docs/design-mining/` until a later queue item researches them.
- Keep inventory and matrix material separate from architecture narratives.
- Keep durable product and contract architecture under `specs/architecture/`.
- Keep first-wave implementation targeting, rollout planning, and lane-acceptance specs under `specs/boot-slice/`.
- Keep implementation-facing shared subsystem guides and schemas under `shared/`.
- Keep lane-local host proof artifacts, wrappers, and blocked records inside the corresponding `hosts/<vendor>/<product>/<technology>/` directory.
- Keep shared runtime tests beside the shared runtime under `shared/tests/` and keep deterministic external inputs under `fixtures/`.
- Keep stable environment control-plane docs and catalogs under `environments/`.
- Keep partial or experimental bring-up work under `labs/` until it is ready for promotion.
- Keep evaluation models, machine-readable eval catalogs, and audit playbooks under `evals/`.
- Keep actual verification run records under `evals/runs/` once executable implementation work begins.
- Keep synthesized phase audits and blocker summaries under `evals/reports/`.
- Keep packaging models, machine-readable packaging catalogs, manifest placeholders, and release checklists under `packaging/`.
- Keep reusable maintenance catalogs and checklists under `scripts/maintenance/`.
- Keep narrow operational skills under `.agents/skills/`.
- Keep environment and evaluation evidence close to the systems they verify.
- Prefer small authoritative documents over large mixed-purpose documents.

## Maintenance Conventions

- Documentation must describe reality, not aspiration.
- Update authoritative docs in the same change set that changes the governed behavior or policy.
- If a claim depends on future work, mark it as planned rather than writing it as present fact.
- When a document becomes obsolete, update or supersede it explicitly rather than leaving silent contradictions.

## Current Authoritative Set

- `README.md`: public-facing project overview, positioning, maturity warning, architecture diagram, implementation-status boundary, and roadmap summary.
- `CONTRIBUTING.md`: contributor orientation and scoped-change guidance for human and agentic work.
- `LICENSE.md`: Apache License, Version 2.0 full text.
- `NOTICE.md`: AIDE copyright, attribution, and trademark notice.
- `LICENSING.md`: AIDE's plain-language Apache-2.0 licensing policy.
- `LICENSE_SUMMARY.md`: non-controlling plain-English licensing summary.
- `GENERATED_OUTPUTS.md`: permissive boundary for target-repository generated outputs and copied AIDE material.
- `TRADEMARKS.md`: AIDE name, branding, and official-project identity policy.
- `ROADMAP.md`: phase-based roadmap and milestone posture.
- `MAINTENANCE.md`: maintenance domains, sync rules, and automation boundary guidance.
- `CHANGELOG.md`: baseline for future changelog entries without backfilled bootstrap history.
- `AGENTS.md`: root operating law for human contributors and coding agents.
- `PLANS.md`: working plan index for substantial work.
- `IMPLEMENT.md`: engineering execution log.
- `DOCUMENTATION.md`: documentation guide and index.
- `.aide/profile.yaml`: canonical self-hosting repository Profile/Contract v0 and current reboot focus.
- `.aide/toolchain.lock`: minimal Contract/Profile v0 tooling lock record.
- `.aide/components/catalog.yaml`, `.aide/commands/catalog.yaml`, `.aide/tasks/catalog.yaml`, `.aide/evals/catalog.yaml`, `.aide/adapters/catalog.yaml`, and `.aide/compat/**`: Q03 self-hosting declaration catalogs.
- `.aide/queue/**`: canonical filesystem queue, Q00 task packet, and task evidence.
- `.aide/policies/**`: autonomy, bypass, review-gate, ownership, generated-artifact, compatibility, and validation-severity policy records.
- `.aide/policies/token-budget.yaml`: Q09/Q10 token budget and prompt-discipline policy for compact task and review packets.
- `.aide/prompts/compact-task.md`, `.aide/prompts/evidence-review.md`, and `.aide/prompts/codex-token-mode.md`: prompt templates for compact implementation and evidence review.
- `.aide/memory/project-state.md`, `.aide/memory/decisions.md`, and `.aide/memory/open-risks.md`: compact durable state memory for token-survival prompts.
- `.aide/context/ignore.yaml`, `.aide/context/repo-snapshot.json`, and `.aide/context/latest-task-packet.md`: context exclusions and generated no-content snapshot/task-packet outputs.
- `.aide/context/compiler.yaml`, `.aide/context/priority.yaml`, and `.aide/context/excerpt-policy.yaml`: Q11 Context Compiler policy/config records.
- `.aide/context/repo-map.json`, `.aide/context/repo-map.md`, `.aide/context/test-map.json`, `.aide/context/context-index.json`, and `.aide/context/latest-context-packet.md`: Q11 generated context artifacts with refs and metadata only.
- `.aide/verification/**` and `.aide/policies/verification.yaml`: Q12/Q13 Verifier and evidence-review policy, evidence/review packet templates, review-decision policy, diff-scope policy, file-reference policy, secret-scan policy, latest verification report, and latest review support.
- `.aide/context/latest-review-packet.md`: Q13 generated compact review packet for GPT-5.5/human review from evidence refs and verifier output.
- `.aide/policies/token-ledger.yaml`, `.aide/reports/token-ledger.jsonl`, `.aide/reports/token-baselines.yaml`, and `.aide/reports/token-savings-summary.md`: Q14 estimated token accounting policy, metadata-only ledger, named baselines, and compact savings summary.
- `.aide/policies/evals.yaml`, `.aide/evals/golden-tasks/**`, and `.aide/evals/runs/latest-golden-tasks.*`: Q15 deterministic local golden-task policy, catalog, fixtures, and latest PASS/WARN/FAIL reports.
- `.aide/policies/controller.yaml` and `.aide/controller/**`: Q16 advisory Outcome Controller policy, failure taxonomy, outcome ledger, latest outcome report, and latest recommendations.
- `.aide/policies/cache.yaml`, `.aide/policies/local-state.yaml`, `.aide/cache/**`, and `.aide.local.example/**`: Q18 cache/local-state policy, deterministic cache-key reports, and safe example runtime-state layout.
- `.aide/policies/gateway.yaml`, `.aide/gateway/**`, and `core/gateway/**`: Q19 local/report-only Gateway policy, architecture, status artifacts, and stdlib skeleton endpoint helpers.
- `.aide/policies/provider-adapters.yaml`, `.aide/providers/**`, and `core/providers/**`: Q20 offline provider-adapter policy, provider catalog, capability matrix, adapter contract, status artifacts, and stdlib metadata helpers.
- `.aide/policies/adapters.yaml`, `.aide/adapters/**`, and `.aide/generated/adapters/**`: Q24 existing-tool adapter compiler policy, templates, target definitions, generated previews, manifest, and drift report.
- `.aide/scripts/aide_lite.py`: X-OS-01-extended standard-library token-survival/context/verifier/review/ledger/eval/outcome/router/cache/gateway/provider/export/import/adapter/commit/changelog/github/task/git/intent/repo/quality/refactor/roots/tools/install/repair/upgrade/rollback/uninstall/release helper for doctor, validate, estimate, snapshot, index, context, map, pack, verify, review-pack, ledger scan/add/report/compare, eval list/run/report, outcome add/report, optimize suggest, route list/validate/explain, cache init/status/key/report, gateway status/endpoints/smoke/serve, provider list/status/validate/contract/probe, export-pack, import-pack safe/full modes, pack-status, adapter list/render/preview/validate/drift/generate, commit check/template/status/install-hook, changelog preview/validate/status, github advisory/status/protection/ci/validate, task inspect/status/classify/repair-plan/requeue-plan/resume-plan/noop-check/dependencies/recover/evidence/current, blocker status/classify, wave status/plan, checkpoint status/plan, git detect/doctor/status/workflow/roles/policy/plan/sync/land/promote/prune, intent compile/validate/examples/status, repo inventory/classify/validate/status/explain-file/docs/tests/deps, quality ledger/validate/status/explain-file/docs/tests/modules/reuse, refactor status/plan/validate/dry-run/schemas/ledger/map/move-map/salvage-map/aliases/rewrite-plan/validate-map/map-status, roots inventory/classify/plan/validate/status/explain-root/explain-file, tools inventory/classify/wrap-plan/validate/status/explain-tool/capabilities, install observe/plan/dry-run/validate/status/explain/ownership/conflicts, repair observe/diagnose/plan/dry-run/validate/status/explain/classes/doctor, upgrade observe-current/observe-source/compare/plan/dry-run/validate/status/explain/compatibility/conflicts/migrations, rollback observe/plan/dry-run/validate/status/explain/classes, uninstall observe/plan/dry-run/validate/status/explain/classes, release bundle/validate/status/assets/manifest/checksums/provenance/clean dry-run/draft/draft-validate/draft-status/upload-plan/checklist/publication-boundary, AIDE dev/main plan reporting, portable governance export/import checks, Task OS validation registration, adapt, test, and selftest.
- `.aide/queue/QCHECK-token-survival-foundation-audit/**`: checkpoint audit showing Q09-Q20 were present and mostly executable, with PASS_WITH_WARNINGS and repair recommendations.
- `.aide/queue/QFIX-01-foundation-review-reconciliation/**`: reconciliation repair accepted with notes by QFIX-03 that accepts Q09-Q20 with notes, fixes Q18 status drift, refreshes profile/self-check truth, and identifies QFIX-02 as next.
- `.aide/queue/QFIX-02-aide-lite-test-discovery-runner/**`: validation runner repair accepted with notes by QFIX-03 that diagnoses the hidden-path unittest failure, establishes `py -3 .aide/scripts/aide_lite.py test`, and points Q21 cross-repo export/import next.
- `docs/reference/aide-lite-test-runner.md`: QFIX-02 canonical AIDE Lite test runner contract and non-canonical old command explanation.
- `.aide/policies/export-import.yaml`, `.aide/export/aide-lite-pack-v0/**`, `.aide/import/**`, `.aide/queue/Q21-cross-repo-pack-export-import-v0/**`, `.aide/queue/Q25-importer-scope-and-state-truth-repair/**`, `.aide/queue/Q26-eureka-pilot-review-and-handover/**`, and `.aide/queue/Q31-export-pack-sync-git-commit-workflow/**`: Q21 portable AIDE Lite Pack policy, generated pack, target import templates, Q25 pack integrity/import scope repair evidence, Q26 Eureka pilot handover evidence, Q31 governance export sync evidence, fixture validation evidence, and review-gated queue packets.
- `docs/reference/cross-repo-pack-export-import.md`: Q21/Q25/Q31 include/exclude boundary, checksum scope, export/import commands, safe import scope, portable governance command validation, target initialization steps, and Eureka/Dominium pilot posture.
- `.aide/queue/Q24-existing-tool-adapter-compiler-v0/**`: Q24 queue packet and evidence for existing-tool adapter compiler implementation accepted with notes by QFIX-03.
- `docs/reference/existing-tool-adapter-compiler-v0.md`: Q24 adapter policy, template targets, generated preview workflow, drift behavior, export-pack inclusion, and no-runtime safety boundary guide.
- `docs/reference/commit-discipline.md`, `docs/reference/workunit-idempotency.md`, and `docs/reference/changelog-preview.md`: Q27/Q34 guides for structured commits, WorkUnit no-op/recovery behavior, and deterministic preview-only changelog/release-note drafts.
- `docs/reference/git-workflow-policy.md`, `docs/reference/branch-roles.md`, `docs/reference/promotion-policy.md`, `docs/reference/git-helper-workflow.md`, `docs/reference/aide-dev-main-workflow.md`, and `docs/reference/github-protection-ci-advisory.md`: Q28-Q35 guides for branch workflow policy, branch role classification, promotion/sync/prune gates, dry-run helper commands, fixture-only mutation tests, AIDE's own dev/main posture, GitHub/CI advisory posture, and live-repo no-mutation boundaries.
- `docs/reference/intent-compiler.md`: Q36 guide for deterministic prompt normalization, task/risk/size classes, latest intent packet usage, WorkUnit draft boundaries, and limitations.
- `docs/reference/repo-intelligence-index.md`: Q37 guide for deterministic repo inventory, ownership/dependency/test/doc maps, generated outputs, conservative orphan candidates, command workflow, and no-move/no-delete boundaries.
- `docs/reference/file-quality-ledger.md`: Q38 guide for deterministic quality ledger commands, levels, warning/candidate language, generated reports, export boundary, and no-fix/no-delete limits.
- `docs/reference/refactor-control-plane.md`: Q39 guide for deterministic dry-run refactor planning, no-apply behavior, move/salvage/path-alias schemas, migration ledgers, command workflow, export boundary, and Q40 integration.
- `docs/reference/root-recycling-framework.md`: Q40 guide for deterministic root inventory, root classification, file fates, root risks, exceptions, command workflow, export boundary, Q41 integration, and Q42 handoff.
- `docs/reference/tool-absorption.md`: Q41 guide for deterministic existing-tool inventory, capability classification, preservation fates, no-execution wrap plans, command workflow, export boundary, and Q42 handoff.
- `docs/reference/move-salvage-path-aliases.md`: Q42 guide for candidate move maps, salvage maps, path alias plans, reference rewrite plans, draft migration ledger events, validation, export boundary, and Q43 handoff.
- `docs/reference/aide-install-model.md`: Q43 guide for install observe/plan/dry-run lifecycle, target-state preservation, ownership ledgers, conflict reports, mandatory migration criteria, verification plans, export boundary, and Q44 integration.
- `docs/reference/aide-repair-model.md`: Q44 guide for repair observe/diagnose/plan/dry-run lifecycle, repair classes, hard blockers, doctor integration, verification plans, export boundary, and Q45 handoff.
- `docs/reference/aide-upgrade-model.md`: Q45 guide for upgrade observe-current/observe-source/compare/plan/dry-run lifecycle, preservation rules, compatibility levels, mandatory and optional migration gates, verification plans, export boundary, and Q46 handoff.
- `docs/reference/aide-rollback-uninstall.md`: Q46 guide for rollback/uninstall observe/plan/dry-run lifecycle, ownership evidence requirements, preservation boundaries, no blanket `.aide` deletion, verification plans, export boundary, Q47 integration, and Q48 handoff.
- `docs/reference/aide-lite-release-bundle.md`: Q47 guide for local release bundle generation, artifact layout, checksum validation, fixture extraction, install notes, publication boundary, export boundary, and Q48 handoff.
- `docs/reference/github-release-draft.md`: Q48 guide for local GitHub release draft generation, asset/checksum collection, no-upload plan, publication checklist, publication boundary, export boundary, and Q49 handoff.
- `docs/reference/task-os-v0.md`, `docs/reference/task-os-report-only-commands.md`, `docs/reference/capability-reality-ledger.md`, `docs/reference/workunit-lifecycle.md`, `docs/reference/blocker-and-repair-model.md`, and `docs/reference/checkpoint-and-promotion-model.md`: X-OS-00 through X-OS-02 guides for Task OS contracts, lifecycle states, blockers, repair planning, waves, checkpoints, branch provenance, capability reality, report-only command outputs, export boundaries, and no-apply boundaries.
- `docs/reference/transaction-model.md`, `docs/reference/transactional-apply-roadmap.md`, `docs/reference/managed-section-operations.md`, and `docs/reference/rollback-records.md`: AIDE-APPLY-00 guides for transaction records, fixture-only planning, safety gates, managed-section operation records, rollback record evidence, export boundaries, and no-real-apply boundaries.
- `.aide/scripts/tests/test_aide_lite.py`, `.aide/scripts/tests/test_verifier.py`, `.aide/scripts/tests/test_review_pack.py`, `.aide/scripts/tests/test_token_ledger.py`, `.aide/scripts/tests/test_golden_tasks.py`, `.aide/scripts/tests/test_outcome_controller.py`, `.aide/scripts/tests/test_router_profile.py`, `.aide/scripts/tests/test_cache_local_state.py`, `.aide/scripts/tests/test_gateway_commands.py`, `.aide/scripts/tests/test_provider_adapter.py`, `.aide/scripts/tests/test_export_import.py`, `.aide/scripts/tests/test_adapter_compiler.py`, `.aide/scripts/tests/test_q27_commit_recovery.py`, `.aide/scripts/tests/test_q28_git_workflow.py`, `.aide/scripts/tests/test_q29_git_helper.py`, `.aide/scripts/tests/test_q30_aide_dev_main_policy.py`, `.aide/scripts/tests/test_q31_export_pack_governance.py`, `.aide/scripts/tests/test_q34_changelog_release.py`, `.aide/scripts/tests/test_q36_intent_compiler.py`, `.aide/scripts/tests/test_q37_repo_intelligence.py`, `.aide/scripts/tests/test_q38_file_quality.py`, `.aide/scripts/tests/test_q39_refactor_control.py`, `.aide/scripts/tests/test_q40_root_recycling.py`, `.aide/scripts/tests/test_q41_tool_absorption.py`, `.aide/scripts/tests/test_q42_move_map_aliases.py`, `.aide/scripts/tests/test_q43_install_plan.py`, `.aide/scripts/tests/test_q44_repair_doctor.py`, `.aide/scripts/tests/test_q45_upgrade_model.py`, `.aide/scripts/tests/test_q46_rollback_uninstall.py`, `.aide/scripts/tests/test_q47_release_bundle.py`, `.aide/scripts/tests/test_q48_github_release_draft.py`, `.aide/scripts/tests/test_x_os_00_task_os.py`, `.aide/scripts/tests/test_x_os_01_task_os_commands.py`, `.aide/scripts/tests/test_x_os_02_capability_reality.py`, `core/gateway/tests/test_gateway_skeleton.py`, and `core/providers/tests/test_provider_contracts.py`: no-install workflow tests for AIDE Lite token, context, verifier, review-packet, token-ledger, golden-task, outcome-controller, router, cache/local-state, Gateway, provider-adapter, export/import, adapter-compiler, commit-discipline, changelog-preview, WorkUnit recovery, Git workflow behavior, Git helper fixture behavior, AIDE dev/main policy validation, Q31 portable governance fixture import behavior, Q34 changelog/release-note preview generation, Q36 intent classification/schema output, Q37 repo intelligence classification/map output, Q38 file quality warning/report output, Q39 refactor no-apply/schema behavior, Q40 root recycling no-apply behavior, Q41 tool absorption no-execution behavior, Q42 map/alias no-apply behavior, Q43 install no-apply planning behavior, Q44 repair no-apply planning behavior, Q45 upgrade no-apply planning behavior, Q46 rollback/uninstall no-apply planning behavior, Q47 local release archive/checksum validation behavior, Q48 release draft/no-publish validation behavior, X-OS-00 Task OS schema/policy no-apply validation behavior, X-OS-01 Task OS command/report no-apply validation behavior, and X-OS-02 capability reality ledger no-overclaim validation behavior.
- `core/README.md` and `core/*/README.md`: Q02 README-only AIDE Core skeleton for Contract, Harness, Runtime, Compatibility, Control, SDK, and tests.
- `core/contract/README.md` and `core/contract/shapes/**`: Q03 Profile/Contract v0 model and documented YAML shapes.
- `core/harness/README.md`, `core/harness/*.py`, and `scripts/aide`: Q04 Harness v0 command surface for local structural validation and non-mutating reports.
- `docs/reference/self-hosting-automation.md`: Q08 report-first automation policy for self-checks, evidence reports, queue-runner boundaries, and forbidden automation.
- `core/compat/README.md`, `core/compat/*.py`, and `.aide/compat/**`: Q06 Compatibility baseline helpers and records for version, migration, replay, upgrade-gate, and deprecation posture.
- `docs/reference/generated-artifacts-v0.md`: Q05 generated artifact policy, target modes, marker format, manifest rules, and stale-output checks.
- `.aide/generated/manifest.yaml`: deterministic Q05 generated artifact manifest.
- `.aide/generated/preview/CLAUDE.md`: non-canonical preview-only Claude guidance output.
- Generated sections in `AGENTS.md` and `.agents/skills/aide-queue/SKILL.md`, `.agents/skills/aide-execplan/SKILL.md`, and `.agents/skills/aide-review/SKILL.md`: managed downstream guidance summaries generated from the AIDE Profile/Contract and source-of-truth references.
- `bridges/README.md`, `bridges/dominium/**`, and `docs/reference/dominium-bridge.md`: Q07 AIDE-side Dominium Bridge baseline records.
- `docs/constitution/bootstrap-era-aide.md`: Q00 baseline freeze for bootstrap-era AIDE.
- `docs/constitution/reboot-doctrine.md`: Q01 durable doctrine for the in-place reboot, public model, Core split, and queue-driven autonomy.
- `docs/constitution/README.md`: index for constitution records and invariants.
- `docs/charters/reboot-charter.md`: Q00 charter for the in-place reboot model and non-goals.
- `docs/charters/README.md`: Q01 architecture charter index.
- `docs/charters/core-charter.md`, `docs/charters/contract-charter.md`, `docs/charters/harness-charter.md`, `docs/charters/compatibility-charter.md`, `docs/charters/hosts-charter.md`, `docs/charters/bridges-charter.md`, `docs/charters/control-charter.md`, and `docs/charters/sdk-charter.md`: Q01 focused charters for the public model and internal Core split.
- `docs/reference/repo-census.md`: Q00 top-level repository census and conceptual mapping.
- `docs/reference/self-bootstrap.md`: reference guide for the self-bootstrap queue and Q00 prompt.
- `docs/reference/README.md`: Q01 reference-family index.
- `docs/reference/documentation-migration-map.md`: Q01 map from old/current documentation areas to new documentation families.
- `docs/reference/structural-migration-map.md`: Q02 map from bootstrap-era physical locations to target skeleton conceptual homes.
- `docs/reference/profile-contract-v0.md`: Q03 human-readable reference for the `.aide/` Profile/Contract v0.
- `docs/reference/source-of-truth.md`: Q03 source-of-truth reference for contract, queue, generated outputs, caches, and evidence.
- `docs/reference/harness-v0.md`: Q04 command boundary and validation model for Harness v0.
- `docs/reference/compatibility-baseline.md`: Q06 Compatibility baseline reference for supported v0 versions, no-op migrations, replay, upgrade gates, deprecations, and Harness checks.
- `docs/reference/token-survival-core.md`: Q09/Q10 token-survival usage guide for compact packets, estimates, validation, and deferred Gateway/provider boundaries.
- `docs/reference/aide-lite.md`: Q10 AIDE Lite command, determinism, drift, and selftest guide.
- `docs/reference/context-compiler-v0.md`: Q11 Context Compiler workflow, artifact, exact-ref, and deferred-boundary guide.
- `docs/reference/verifier-v0.md`: Q12 Verifier workflow, evidence packet, task packet, diff scope, file-reference, secret-scan, and report guide.
- `docs/reference/evidence-review-workflow.md`: Q13 compact review-packet workflow and evidence-only GPT-5.5 review guide.
- `docs/reference/token-ledger.md`: Q14 estimated token ledger, baseline comparison, budget status, regression warning, and no-raw-prompt storage guide.
- `docs/reference/golden-tasks-v0.md`: Q15 deterministic golden-task quality gates and eval list/run/report workflow.
- `docs/reference/outcome-controller-v0.md`: Q16 advisory outcome-controller signal, recommendation, and safety-boundary guide.
- `docs/reference/router-profile-v0.md`: Q17 advisory routing policy, model/provider metadata, route-decision, hard-floor, and safety-boundary guide.
- `docs/reference/cache-local-state-boundary.md`: Q18 guide for `.aide.local/`, cache/local-state policies, cache keys, cache reports, and deferred live cache/Gateway work.
- `docs/reference/gateway-skeleton.md`: Q19 guide for local Gateway policy, health/status/route/summaries/version endpoints, AIDE Lite gateway commands, and provider-forwarding deferrals.
- `docs/reference/provider-adapter-v0.md`: Q20 guide for offline provider-adapter policy, provider catalog, capability metadata, AIDE Lite provider commands, credential boundary, and live-call deferrals.
- `docs/reference/terminology.md`: Q01 canonical terminology reference.
- `docs/reference/command-reference.md`: current queue-helper command reference and deferred command posture.
- `docs/reference/generated-artifacts.md`: planned generated-artifact reference home for later Q05 work.
- `docs/roadmap/reboot-roadmap.md`: queue-driven Q00 through Q08 reboot roadmap.
- `docs/roadmap/README.md`, `docs/roadmap/queue-roadmap.md`, and `docs/roadmap/staged-expansion-roadmap.md`: Q01 roadmap family index, queue view, and deferred expansion map.
- `docs/decisions/**`: Q01 ADR-like records for reboot-in-place, Core / Hosts / Bridges, Core split, Profile versus Harness, Compatibility, XStack, and host boundary decisions.
- `docs/design-mining/**`: Q01 home for future external-system lesson extraction candidates.
- `governance/vision.md`: durable project vision and non-goals.
- `governance/support-policy.md`: support tiers, states, modes, and honesty rules.
- `governance/naming-policy.md`: naming doctrine for directories, manifests, adapters, and artifacts.
- `governance/capability-levels.md`: capability levels `L0` through `L4`.
- `governance/release-policy.md`: phase gating and release law.
- `specs/README.md`: root index for architecture and product contracts.
- `specs/architecture/**`: canonical shared-core and host-adapter architecture docs plus ADRs.
- `specs/boot-slice/**`: first-wave implementation target, lane acceptance, rollout, degraded-policy, and machine-readable boot-slice planning manifests.
- `shared/README.md`: root guide for the shared implementation subtree.
- `shared/core/**`, `shared/protocol/**`, `shared/diagnostics/**`, `shared/config/**`, and `shared/cli/**`: executable shared-core bootstrap runtime for the first boot slice.
- `shared/tests/**`: standard-library tests covering the shared-core runtime and CLI smoke path.
- `hosts/README.md`, `hosts/cli/**`, `hosts/service/**`, `hosts/commander/**`, and `hosts/extensions/**`: Q02 README-only host skeletons.
- `hosts/microsoft/**`: first implemented host-lane proof set, including runnable cli-bridge shims, blocked-proof records, and lane-local boot-slice request or response examples.
- `hosts/apple/**`: Apple host-lane proof set, including a runnable companion cli-bridge shim and blocked structural XcodeKit native-proof records.
- `hosts/metrowerks/**`: CodeWarrior host-lane proof set, including a runnable archival-native cli-bridge shim, native-adjacent plug-in target metadata, and a runnable companion fallback proof.
- `shared/schemas/**`: conservative machine-readable shared contract shapes that support later implementation.
- `fixtures/boot-slice/**`: deterministic JSON boot-slice requests and expected responses used by tests and smoke verification.
- `environments/README.md`: root guide for the environment control plane.
- `environments/model.md`: canonical model for environment families, instances, media, toolchains, snapshots, bootability, blockers, and archival records.
- `environments/catalogs/**`: machine-readable environment, media, toolchain, snapshot, and bootability catalogs.
- `inventory/legal-acquisition.yaml`: stable acquisition and provenance vocabulary for environment-related assets.
- `labs/README.md`: root guide for active prototypes, blocked work, and archival lab records.
- `labs/workflow.md`: lab progression and promotion guide.
- `labs/**/register.yaml`: machine-readable prototype, blocked, and archival lab registers.
- `evals/README.md`: root guide for the evaluation and verification control plane.
- `evals/model.md`: canonical model for eval categories, verification routines, graders, result states, and evidence posture.
- `evals/catalogs/**`: machine-readable eval, verification, grader, and result-status catalogs.
- `evals/playbooks/**`: repeatable verification and eval procedures.
- `evals/runs/**`: factual records of executable verification runs once implementation exists.
- `evals/runs/microsoft-boot-slice-smoke.md`: factual record of the first Microsoft host-lane proof wave, including runnable versus blocked verification boundaries.
- `evals/runs/apple-boot-slice-smoke.md`: factual record of the Apple host-lane proof wave, including runnable companion verification and blocked XcodeKit boundaries.
- `evals/runs/codewarrior-boot-slice-smoke.md`: factual record of the CodeWarrior host-lane proof wave, including runnable archival-native versus companion fallback boundaries.
- `evals/reports/bootstrap-phase-audit.md`: factual post-P13 audit of completed phases, current implementation reality, and next likely work areas.
- `evals/reports/open-blockers-summary.md`: concise blocker rollup across host, environment, packaging, and verification domains.
- `packaging/README.md`: root guide for the packaging and release control plane.
- `packaging/model.md`: canonical packaging model for artifact classes, manifest placeholders, release channels, and signing posture.
- `packaging/catalogs/**`: machine-readable artifact-class, channel, signing-posture, and package-definition catalogs.
- `packaging/checklists/**`: repeatable packaging and release audit procedures.
- `scripts/README.md`: root guide for repeatable repository operations and lightweight automation support.
- `scripts/aide`: Q04 Harness v0 repo-root command entrypoint.
- `scripts/aide-queue-next`, `scripts/aide-queue-status`, and `scripts/aide-queue-run`: conservative read-only queue helpers; Q08 keeps `aide-queue-run` report-first and non-invoking.
- `scripts/maintenance/**`: maintenance task catalog, automation boundary, and reusable audit or synchronization checklists.
- `.agents/README.md`: repo-local agent workflow guide.
- `.agents/skills/**`: narrow repo-local skills for recurring inventory, eval, host, maintenance, docs, roadmap, and audit work.

## Current Status

The repository is still pre-product, but it now has governance, Apache-2.0 permissive licensing docs, inventory, matrices, host-atlas research, shared-core architecture, a defined boot-slice rollout, an executable shared-core bootstrap runtime with deterministic fixtures and tests, the first Microsoft, Apple, and CodeWarrior host-lane proof waves, environment or lab control-plane records, evaluation and packaging control-plane records, contributor and roadmap guidance, maintenance control-plane assets, post-bootstrap audit reports, and a self-hosting filesystem queue.

The current AIDE-local control plane includes Q00-Q48 foundation work, X-OS Task OS report-only records, AIDE-APPLY transaction/lifecycle fixture planning slices, and review-gated protocol or report slices for ContractEnvelope, EvidencePacket, WorkUnit, WorkerRun, TestJob, ReferenceID, EventRecord, OKF, Reconciler, CapabilityManifest, ConformanceProfile, ConformanceResult, PatchTransaction, AdapterManifest, and ContextPack v2. These surfaces are implemented for review or accepted with warnings according to their queue evidence; they are not public release or production-runtime claims.

Read-only post-pilot evidence from sibling Eureka and Dominium repos shows target import pilots completed with large estimated task-packet reductions, but target sync still needs to run in the target repositories. Broader host-adapter coverage, adapter-output target-tool usage proof, actual archival environment bring-up, deeper executable eval coverage, public release publication, GitHub Release creation, release tag creation, artifact upload, full Runtime, live provider adapters, live Gateway/provider routing, live cache behavior, mutating compatibility migrations, target sync from the canonical pack, live dev branch creation or promotion, GitHub protection/CI enforcement, real autonomous worker invocation, semantic model-based intent classification, active tool wrapper execution, apply-capable Task OS behavior, apply-capable root recycling, real repository transaction apply, rollback execution, Host Contract, CapabilityInvocation, DevelopmentTransaction, PreviewSession, Dominium Bridge conformance, Workbench, Commander, and apply-capable install/repair/upgrade/rollback/uninstall behavior remain future phases.

The intent-to-transaction planning reports under `.aide/reports/intent-to-transaction-roadmap/**` record the current candidate sequence for Host Contract, CapabilityInvocation, DevelopmentTransaction, PreviewSession, Dominium Bridge conformance, Workbench, and validation-slice work. They are planning evidence only; `.aide/queue/index.yaml` remains execution truth.

## Protocol Slice Note: TestJob

- `.aide/protocol/aide-test-job.schema.json`, `core/protocol/test_job.py`, `.aide/reports/test-job/**`, and `.aide/queue/AIDE-BUILD-TESTJOB-SCHEMA-01/**` record the metadata-only TestJob protocol slice.
- The slice supports schema/helper/projection/validation behavior and thin `test-job status/project/validate` dispatch only.
- Test Broker runtime, async execution, scheduler, leases, worker execution, providers, Service, Commander, Gateway, network, GitHub mutation, target apply, release, and promotion remain deferred.

## Knowledge Plane Note: OKF

- `.aide/knowledge/okf/**`, `.aide/reports/okf/**`, `core/knowledge/okf_bundle.py`, and `.aide/queue/AIDE-BUILD-OKF-KNOWLEDGE-BUNDLE-01/**` record the first deterministic OKF-compatible AIDE knowledge bundle projection.
- The bundle explains current repo truth through markdown pages with structural frontmatter, concept indexes, link indexes, current-state pages, protocol pages, capability pages, decision pages, and risk pages.
- OKF remains projection-only: it does not replace queue truth, protocol schema truth, evidence truth, ReferenceID/EventRecord authority, runtime knowledge services, provider/model calls, network enrichment, search/vector indexes, visualizer behavior, Reconciler, CapabilityManifest, ConformanceProfile, PatchTransaction, AdapterManifest, ContextPack v2, scheduler, Service, Commander, release, promotion, or target mutation.

## Continuous worker pilot (2026-09-06)

[Continuous worker pilot](docs/reference/continuous-worker-pilot.md) documents the implemented local prototype, commands, ownership/evidence contracts and remaining live qualification. The authoritative bounded work item is .aide/queue/AIDE-BUILD-CONTINUOUS-WORKER-PILOT-01; the disabled activation example is not policy.

## Programme and portable-export repair

AIDE-EXECUTE-FACMAN-BETA1-PROGRAMME-01 records current execution authority, exact branch plans and durable validation. FacMan retains its own canonical plan and target-local queues. Portable source-only tests require explicit admission: the existing three AIDE Lite modules are retained; full runtime and continuous-worker tests remain source-only, including nested paths. Live activation is still disabled pending real host/broker/two-task qualification.

- The local broker core and frozen-candidate contract are documented in `docs/reference/integration-broker-core.md`; full protected transport and isolated-host qualification remain separate queue work.

- `docs/reference/integration-broker-core.md` describes candidate v2, bounded preparation recovery, coordinator-v1 and external authority issuance boundaries; foundation history remains in checkpoint 7e4de0c9.

### AIDE-CW-INTEGRATION-BROKER-01 qualified transport continuation

Reviewed local v1 checkpoint f06bcd75aafeab175202a89ea1d69c815b7bd911 binds
frozen delta/preparation recovery/coordinator v1. Continue exact-generation
effect validation, external delegated authority and bounded branch/PR/check
observation transport under the task ExecPlan. Real host/store and atomic
target merge qualification remain open; AIDE has no current hosted workflows
or branch rules. No operational activation or settings mutation is claimed.

### Broker delegated-core current evidence

The broker task evidence now binds the complete 27-file current source, separate
independent effect/capsule and issuer/PR reviews, historical full-suite results
and focused remediation tests. qualified-core-custody.json distinguishes raw
archived bytes from readable Git text projections; neither constitutes live
host or provider qualification.

### Staged broker continuation

The integration broker reference now documents one-stage reconciliation, deterministic literal commit objects, independent stage intents, observation-only query and the absent qualified provider adapter.

### Registered bridge contract and evidence

The integration broker reference documents the fixed JSON request/response
protocol, protected registration and qualifier requirements, finite retained IO
ledger and named Job recovery. AIDE-CW-INTEGRATION-BROKER-01 keeps exact local
source/test receipts distinct from pending provider, host/store and atomic
server qualification. Historical test and review bytes remain preserved in
task custody archives.

### Provider facts and executable qualification plan

The broker reference now documents finite raw REST reads, actual Actions
run/attempt provenance, immutable merged parents, expired-authority observation
and explicit target-policy absence. The new target WorkUnit contains cited
GitHub contract research and local graph experiments; the existing host ExecPlan
contains concrete Windows isolation/denial probes. Neither planning admission
nor offline parser/graph tests install settings or qualify an operational host.

## Integration broker HTTPS observation boundary

The integration-broker-core reference now specifies the fixed-origin TLS reader,
protected host/credential lease interface, finite DNS/socket/header/body budgets,
strict supported response subset and local denial tests. It distinguishes the
implemented HTTPS mechanism from absent operational host credentials, restricted
principal, target rules and server qualification. The synthetic fixture route
cannot be selected through production configuration or worker input.

## H1 native host mechanism and proof boundary

The H1 native mechanism has one passing exact local probe after three retained
FAIL attempts. Zero-capability AppContainer token/owned Job, scratch write,
protected read/write/DACL/controller refusals, stable package non-exemption and
the same-address network diagnostic/control conjunction passed. Raw 10060 still
means timeout; diagnostic 2 means missing internetClient. Source27, existing
actual Job10 and ordinary native3 tests pass and were independently replayed.
The fourth child exited0/exited/quiescent. All four packets retain exact bytes.
The host WorkUnit remains running/PENDING: private Python/Git/Codex, isolated
fault/recovery cells, model channel, credential host and activation remain open.

The broker reference and H1 ExecPlan document mechanism, four-attempt history
and acceptance gaps. Task evidence/validation.md and custody maps navigate raw
source, binaries, reviews and actual receipts. Text checkout projections do not
replace archived raw hashes. Consumed effects cannot replay.
