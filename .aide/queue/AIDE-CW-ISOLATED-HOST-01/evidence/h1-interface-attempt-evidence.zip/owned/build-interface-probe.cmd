@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvars64.bat" > "C:\Users\Jules\AppData\Local\Temp\aide-h1-source-4m92pvi5\interface-compiler-env.txt" 2>&1
if errorlevel 1 exit /b 1
"C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe" /nologo /W4 /WX /std:c17 /utf-8 /MT /O2 "D:\Projects\AIDE\aide\.aide\scripts\tests\test_continuous_worker_windows_security_probe.c" /Fe:"C:\Users\Jules\AppData\Local\Temp\aide-h1-source-4m92pvi5\security-probe-interface.exe" /Fo:"C:\Users\Jules\AppData\Local\Temp\aide-h1-source-4m92pvi5\security-probe-interface.obj" ws2_32.lib iphlpapi.lib /link /INCREMENTAL:NO > "C:\Users\Jules\AppData\Local\Temp\aide-h1-source-4m92pvi5\interface-compile.txt" 2>&1
exit /b %errorlevel%
