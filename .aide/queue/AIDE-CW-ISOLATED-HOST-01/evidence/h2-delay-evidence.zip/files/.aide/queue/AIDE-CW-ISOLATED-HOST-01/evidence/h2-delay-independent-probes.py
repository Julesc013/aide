import hashlib,json,pathlib,struct,sys,time
R=pathlib.Path(r"D:\Projects\AIDE\aide");E=R/".aide/queue/AIDE-CW-ISOLATED-HOST-01/evidence"
sys.path[:0]=[str(R),str(R/".aide/scripts/tests")]
from core.runtime.continuous_worker import windows_pe as pe,windows_python_contract as contract
from core.runtime.continuous_worker.state import Refused
from test_continuous_worker_windows_pe import fixture,put,write,HEADERS,RAW,RVA,SECTION,OPTIONAL
sha=lambda b:hashlib.sha256(b).hexdigest()
mraw=(E/"h2-delay-source-manifest.json").read_bytes();m=json.loads(mraw)
expected={**m["files"],**m["dependent_inputs"]}
def unchanged():assert {p:sha((R/p).read_bytes()) for p in expected}==expected
unchanged()
def counted(symbols,descriptors=1):
 data=fixture(imports=(),delayed=())
 raw_size=0x80000;data.extend(b"\0"*(HEADERS+raw_size-len(data)))
 write(data,SECTION+8,"<IIII",raw_size,RVA,raw_size,HEADERS)
 write(data,OPTIONAL+56,"<I",0x82000)
 write(data,OPTIONAL+112+13*8,"<II",0x1200,(descriptors+1)*32)
 put(data,0x3000,struct.pack("<Q",(1<<63)|7)*symbols+b"\0"*8)
 for i in range(descriptors):
  name=("test"+str(i)+".dll").encode()+b"\0";name_rva=0x2400+64*i
  put(data,name_rva,name);put(data,0x1200+32*i,struct.pack("<8I",1,name_rva,0,0x24000,0x3000,0,0,0))
 return bytes(data)
results=[]
for label,count,descriptors,accept in (("one_at_limit",16384,1,True),("one_above_limit",16385,1,False),("two_at_aggregate_limit",8192,2,True),("three_above_aggregate_limit",8192,3,False)):
 data=counted(count,descriptors);start=time.monotonic();error=None
 try:
  info=pe.read_pe(data);success=True;assert len(info.delay_imports)==descriptors
 except Refused as e:success=False;error=str(e)
 assert success==accept,(label,error)
 results.append({"case":label,"symbols_per_descriptor":count,"descriptors":descriptors,"accepted":success,"error":error,"fixture_sha256":sha(data),"fixture_bytes":len(data),"seconds":time.monotonic()-start})
# Independently replay the exact eight already admitted read-only byte-stream inputs.
observed_raw=(E/"h2-delay-system-readonly-final.json").read_bytes()
assert sha(observed_raw)==m["read_only_system_receipt"]["sha256"]
observed=json.loads(observed_raw);assert len(observed["rows"])==8
previous=json.loads((E/"h2-python-system-pe-readonly-inspection.json").read_bytes())
previous_map={r["name"]:(r["path"],r["bytes"],r["sha256"]) for r in previous["rows"]}
replayed=[];union=set()
for row in observed["rows"]:
 assert (row["path"],row["bytes"],row["sha256"])==previous_map[row["name"]]
 with pathlib.Path(row["path"]).open("rb") as stream:data=stream.read(pe.MAX_PE_BYTES+1)
 assert len(data)==row["bytes"] and sha(data)==row["sha256"]
 result=pe.read_pe(data);assert list(result.dependencies)==row["dependencies"]
 assert result.sha256==row["metadata"]["sha256"] and result.machine==row["metadata"]["machine"] and result.is_dll==row["metadata"]["is_dll"]
 assert list(result.imports)==row["metadata"]["imports"] and list(result.delay_imports)==row["metadata"]["delay_imports"]
 assert [{"module":f.module,"symbol":f.symbol} for f in result.forwarders]==row["metadata"]["forwarders"]
 union.update(result.dependencies);replayed.append({"name":row["name"],"bytes":len(data),"sha256":sha(data),"metadata_matches":True,"dependency_count":len(result.dependencies)})
apis=sorted(n for n in union if n.startswith(("api-","ext-")));physical=sorted(union-set(apis))
assert apis==observed["api_names"] and physical==observed["physical_names"]
assert len(apis)==180 and len(physical)==15 and contract.MAX_API_SETS==observed["current_contract_api_cap"]==128
sdk=json.loads((E/"h2-python-delay-sdk-addendum.json").read_bytes())
for path,digest in sdk["files"].items():assert sha(pathlib.Path(path).read_bytes())==digest
unchanged()
receipt={"schema":"aide.h2.delay.independent-boundary-probes.v1","source_manifest_sha256":sha(mraw),"source_aggregate_sha256":m["aggregate_sha256"],"exact_symbol_boundary_cases":results,"read_only_byte_stream_replay":replayed,"dependency_union":{"all":len(union),"api_sets":len(apis),"physical":len(physical),"unchanged_admitted_api_cap":contract.MAX_API_SETS},"sdk_files":sdk["files"],"source_unchanged":True,"effects":"Pure synthetic metadata plus read-only capture of exactly eight previously admitted public Windows DLL streams; no DLL loading/mapping/execution, image/filesystem copy, grants, profile or isolated launch. Bytes alone do not prove native ownership/API mappings.","script_sha256":sha(pathlib.Path(__file__).read_bytes())}
with (E/"h2-delay-independent-probes.json").open("x",encoding="utf-8") as f:json.dump(receipt,f,indent=2);f.write("\n")
print(json.dumps({"boundary_cases":results,"system_rows":len(replayed),"union":len(union),"api":len(apis),"receipt_sha256":sha((E/"h2-delay-independent-probes.json").read_bytes())}))
