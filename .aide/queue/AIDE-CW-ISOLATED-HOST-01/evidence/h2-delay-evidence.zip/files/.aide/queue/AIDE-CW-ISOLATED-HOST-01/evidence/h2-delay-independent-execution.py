import difflib, hashlib, json, os, pathlib, subprocess, sys, time
root=pathlib.Path(r"D:\Projects\AIDE\aide")
ev=root/".aide/queue/AIDE-CW-ISOLATED-HOST-01/evidence"
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest_bytes=(ev/"h2-delay-source-manifest.json").read_bytes()
assert sha(manifest_bytes)=="9855df4ece8529f45d76c0bb2802b90853484d083501992ff5c43862ae5e5af0"
manifest=json.loads(manifest_bytes)
def git(*args):
    return subprocess.run(["git",*args],cwd=root,capture_output=True,check=True,timeout=30).stdout
head=git("rev-parse","HEAD").decode().strip()
tree=git("rev-parse","HEAD^{tree}").decode().strip()
assert head==manifest["source_base"]
index_before=git("diff","--cached","--binary","--full-index")
paths={**manifest["files"],**manifest["dependent_inputs"]}
def hashes():
    result={p:sha((root/p).read_bytes()) for p in paths}
    assert result==paths
    return result
before=hashes()
assert sha(json.dumps(manifest["files"],sort_keys=True,separators=(",",":")).encode())==manifest["aggregate_sha256"]
parts=[]
tracked=set(git("ls-files","-z").decode().split("\0"))
for path in sorted(manifest["files"]):
    if path in tracked:
        parts.append(git("diff","--binary","HEAD","--",path))
    else:
        data=(root/path).read_bytes()
        assert b"\r" not in data
        content="".join(difflib.unified_diff([],data.decode().splitlines(True),fromfile="/dev/null",tofile="b/"+path))
        parts.append((f"diff --git a/{path} b/{path}\nnew file mode 100644\n"+content).encode())
patch=b"".join(parts)
assert sha(patch)==manifest["patch"]["sha256"],(len(patch),sha(patch))
assert (ev/manifest["patch"]["path"]).read_bytes()==patch
receipt_raw=(ev/manifest["test_receipt"]["path"]).read_bytes()
assert sha(receipt_raw)==manifest["test_receipt"]["sha256"]
author=json.loads(receipt_raw)
assert sha((ev/author["log"]).read_bytes())==author["log_sha256"]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1")
started=time.monotonic()
result=subprocess.run(author["command"],cwd=root,env=env,capture_output=True,timeout=120)
elapsed=time.monotonic()-started
for kind,data in (("stdout",result.stdout),("stderr",result.stderr)):
    with (ev/f"h2-delay-independent-tests.{kind}.txt").open("xb") as out:out.write(data)
after=hashes()
assert git("diff","--cached","--binary","--full-index")==index_before
assert git("rev-parse","HEAD").decode().strip()==head
receipt={"schema":"aide.h2.delay.independent-execution.v1","source_head":head,"source_tree":tree,"source_manifest_sha256":sha(manifest_bytes),"source_aggregate_sha256":manifest["aggregate_sha256"],"source_and_dependencies_before":before,"source_and_dependencies_after":after,"reconstructed_patch":{"bytes":len(patch),"sha256":sha(patch)},"index_sha256":sha(index_before),"index_unchanged":True,"command":author["command"],"exit_code":result.returncode,"elapsed_seconds":elapsed,"artifacts":[{"path":f"h2-delay-independent-tests.{k}.txt","bytes":len(d),"sha256":sha(d)} for k,d in (("stdout",result.stdout),("stderr",result.stderr))],"effects":"Synthetic PE/archive data; ordinary Windows file/read/write/journal and owned Job tests. Image root/seal/grants modeled. No actual tools/profile/AppContainer effects.","review_script":{"path":pathlib.Path(__file__).name,"sha256":sha(pathlib.Path(__file__).read_bytes())}}
with (ev/"h2-delay-independent-execution.json").open("x",encoding="utf-8",newline="\n") as out:json.dump(receipt,out,indent=2);out.write("\n")
print(json.dumps({"exit_code":result.returncode,"elapsed_seconds":elapsed,"receipt_sha256":sha((ev/"h2-delay-independent-execution.json").read_bytes()),"log_tail":result.stderr.decode(errors="replace")[-2500:]}))
assert result.returncode==0
