import hashlib,json,math,os,subprocess,sys
from pathlib import Path
R=Path(r"D:\Projects\AIDE\aide");E=R/".aide/queue/AIDE-CW-ISOLATED-HOST-01/evidence"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=E/"h2-input-actual-execution.json";assert sha(p)=="c7ad28de4426eefdf6af8a44bb38b8ff1c0a402a1a7d5653c522cbf98785388e"
r=json.loads(p.read_bytes());m=json.loads((E/"h2-input-source-manifest.json").read_bytes())
for rel,digest in dict(m["files"],**m["unchanged_dependencies"]).items():assert sha(R/rel)==digest
for name,row in r["artifacts"].items():f=Path(name);assert f.stat().st_size==row["bytes"] and sha(f)==row["sha256"]
assert sha(E/"h2-input-root-source-effect-review.json")==r["root_review_sha256"]
assert sha(E/"h2-input-effect-manifest.json")==r["effect_manifest_sha256"]
sys.path.insert(0,str(E));import h2_system_input as read;import h2_system_input_controller as control
effect=read.decode((E/"h2-input-effect-manifest.json").read_bytes());plan=control.read_effect(effect);fingerprint=hashlib.sha256(read._canonical(effect)).hexdigest()
parent=Path(effect["output_parent"]["path"]);out=parent/("system-input-"+plan.request_id)
stdin=(out/"stdin").read_bytes();raw=(out/"stdout").read_bytes();stderr=(out/"stderr").read_bytes()
assert stdin==read._canonical(plan.value()) and stderr==b""
child=read.validate_result(raw,plan)
controller=read.decode((E/"h2-input-actual-controller-stdout.txt").read_bytes())
assert controller["result"]=="PASS" and controller["effect_sha256"]==fingerprint and controller["observation"]==child and controller["stdout_sha256"]==hashlib.sha256(raw).hexdigest()
host=controller["host"];assert type(host["exit_code"]) is int and host["exit_code"]==0 and host["reason"]=="exited" and host["quiescent"] is True and host["io_errors"]==[] and host["job_id"]==plan.request_id and type(host["bytes"]) is int and host["bytes"]==len(raw)
rows=[read.decode(line) for line in (parent/("system-input-"+plan.request_id+".intent.jsonl")).read_bytes().splitlines()]
assert len(rows)==2
intent,observed=rows;assert intent["effect_sha256"]==fingerprint and intent["plan_sha256"]==plan.sha256 and intent["request_id"]==plan.request_id and intent["output"]==str(out) and intent["consumed"] is True and intent["replay_permitted"] is False
assert observed["final_controller_status"]=="pending_final_guard" and "result" not in observed and observed["observation"]==controller
expected_calls=2+1+2+8+16+8+sum(math.ceil(x.size/65536) for x in plan.files)
assert child["calls"]==expected_calls==167 and child["close_attempts"]==9 and child["release_failures"]==[]
assert type(r["controller_exit_code"]) is int and r["controller_exit_code"]==0 and r["controller_error"] is None
assert 0<r["elapsed_seconds"]<90 and r["start_time"]+r["elapsed_seconds"]<plan.expires_at
assert all(r[k]==0 for k in ("selected_mappings","profile_creations","acl_changes","network_calls")) and r["operational_activation"] is False and r["no_retry"] is True
assert sha(parent/effect["output_parent"]["owner_marker"])==effect["output_parent"]["owner_sha256"]
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0")
head=subprocess.check_output(["git","-c","safe.directory="+R.as_posix(),"rev-parse","HEAD"],cwd=R,env=env,timeout=30).decode().strip();assert head==m["base"]==r["head"]
review={"schema":"aide.host.h2-input-root-actual-review.v1","result":"PASS_ACTUAL_BOUNDED_READ_FACTS","execution_receipt_sha256":sha(p),"source_manifest_sha256":sha(E/"h2-input-source-manifest.json"),"source_aggregate":m["aggregate"],"effect_raw_sha256":sha(E/"h2-input-effect-manifest.json"),"effect_canonical_sha256":fingerprint,"all_six_original_artifacts_rehashed":True,"exact_child_stdin_and_typed_output":True,"controller_and_provisional_journal_correlate":True,"owned_job_exit_quiescence_and_output_bytes_match":True,"exact_adapter_calls":expected_calls,"exact_close_attempts":9,"observed_files":len(child["files"]),"observed_bytes":sum(x.size for x in plan.files),"actual_native_names_preserved":True,"sources_dependencies_index_unchanged":True,"actual_DLL_reread_or_effect_replay_by_reviewer":False,"scope":"Independent audit of exact recorded ordinary child read-only execution and native facts. Observed owner/DACL/identity/hash/links do not establish OS provenance, contextual API mapping, private Python bootstrap, complete180/128API closure or continuous activation."}
f=E/"h2-input-root-actual-review.json";assert not f.exists();f.write_text(json.dumps(review,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"result":review["result"],"sha256":sha(f),"adapter_calls":expected_calls,"files":review["observed_files"],"bytes":review["observed_bytes"]}))
