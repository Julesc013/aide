import hashlib,importlib,json,os,subprocess,sys,unittest
from pathlib import Path
from unittest import mock
R=Path(r"D:\Projects\AIDE\aide");E=R/".aide/queue/AIDE-CW-ISOLATED-HOST-01/evidence"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(E/"h2-input-source-manifest.json")=="68ec1a87f6e5e95193a5067c2c94907e0d38382863ce404f98984df5e0ac9cec"
m=json.loads((E/"h2-input-source-manifest.json").read_bytes())
def verify():
 for rel,digest in dict(m["files"],**m["unchanged_dependencies"]).items():assert sha(R/rel)==digest,rel
 assert sha(E/m["patch"])==m["patch_sha256"] and (E/m["patch"]).stat().st_size==m["patch_bytes"]
 assert sha(E/m["effect_manifest"])==m["effect_manifest_sha256"]
verify()
env=dict(os.environ,GIT_OPTIONAL_LOCKS="0")
head=subprocess.check_output(["git","-c","safe.directory="+R.as_posix(),"rev-parse","HEAD"],cwd=R,env=env,timeout=30).decode().strip();assert head==m["base"]
sys.path.insert(0,str(R));sys.path.insert(0,str(E));sys.path.insert(0,str(R/".aide/scripts/tests"))
tests=importlib.import_module("h2_system_input_tests");old=importlib.import_module("test_continuous_worker_system_observation")
read=tests.read;control=tests.control
class Independent(unittest.TestCase):
 def test_all_acquisition_boundaries_close_exactly_once(self):
  for selected in range(11,19):
   with self.subTest(handle=selected):
    clock=tests.Clock();api=tests.FakeRead()
    def hook(stage,h):
     if stage=="open_file" and h==selected:clock.wall=1100.0
    api.hook=hook;p=read.ReadProbe(read.ReadPlan.read(tests.value()),api,lambda:True,clock=clock.tick,wall=clock.utc)
    with self.assertRaises(read.Refused):p.run()
    self.assertEqual(api.closed,list(reversed(api.opened)));self.assertEqual(len(api.closed),len(set(api.closed)))
 def test_every_false_release_refuses_but_finishes_other_releases(self):
  for selected in range(10,19):
   with self.subTest(handle=selected):
    clock=tests.Clock();api=tests.FakeRead();original=api.close_file
    def close(h):
     original(h);return h!=selected
    api.close_file=close;p=read.ReadProbe(read.ReadPlan.read(tests.value()),api,lambda:True,clock=clock.tick,wall=clock.utc)
    with self.assertRaises(read.Refused):p.run()
    self.assertEqual(api.closed,list(reversed(api.opened)));self.assertEqual(len(p.release_failures),1)
 def test_final_serialization_expiry_refuses(self):
  clock=tests.Clock();api=tests.FakeRead();p=read.ReadProbe(read.ReadPlan.read(tests.value()),api,lambda:True,clock=clock.tick,wall=clock.utc)
  original=read._canonical
  def serialize(value):
   raw=original(value)
   if isinstance(value,dict) and value.get("schema")=="aide.host.system-input-result.v1":clock.wall=1100.0
   return raw
  with mock.patch.object(read,"_canonical",serialize):
   with self.assertRaises(read.Refused):p.run()
  self.assertEqual(len(api.closed),9)
 def test_controller_release_failure_has_no_final_success(self):
  for stage in ("parent_close",):
   clock=tests.Clock();api=tests.FakeControl()
   def hook(now):
    if now==stage:raise OSError("injected final close failure")
   api.hook=hook;c=control.Controller(tests.effect(),api,clock=clock.tick,wall=clock.utc)
   with self.assertRaises(read.Refused):c.run()
   self.assertTrue(c.failure["consumed"]);self.assertEqual(api.rows[-1]["final_controller_status"],"pending_final_guard")
 def test_fresh_result_after_expiry_cannot_return_from_controller(self):
  for attr,val in (("mono",191.0),("wall",1100.0),("mono",99.0),("mono",float("nan"))):
   with self.subTest(attribute=attr,value=str(val)):
    clock=tests.Clock();api=tests.FakeControl();api.hook=lambda stage:setattr(clock,attr,val) if stage=="parent_close" else None
    c=control.Controller(tests.effect(),api,clock=clock.tick,wall=clock.utc)
    with self.assertRaises(read.Refused):c.run()
    self.assertTrue(c.failure["consumed"])
 def test_wire_flag_integer_aliases_refused(self):
  clock=tests.Clock();api=tests.FakeRead();p=read.ReadProbe(read.ReadPlan.read(tests.value()),api,lambda:True,clock=clock.tick,wall=clock.utc)
  valid=json.loads(p.run())
  for key in ("consumed","system_ownership_qualified","api_context_qualified","loader_qualified","operational_activation"):
   obj=json.loads(json.dumps(valid));obj[key]=int(obj[key])
   with self.subTest(key=key),self.assertRaises(read.Refused):read.validate_result(read._canonical(obj),p.plan)
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(tests),unittest.defaultTestLoader.loadTestsFromModule(old),unittest.defaultTestLoader.loadTestsFromTestCase(Independent)])
path=E/"h2-input-root-tests.log";assert not path.exists()
with path.open("x",encoding="utf-8",newline="\n") as out:
 with mock.patch.object(read.ReadOnlyApi,"__init__",side_effect=AssertionError("actual native facade construction forbidden in source review")):
  result=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
assert result.wasSuccessful(),(result.testsRun,len(result.failures),len(result.errors))
verify()
effect=json.loads((E/m["effect_manifest"]).read_bytes());plan=control.read_effect(effect)
assert plan.expires_at-__import__("time").time()>120
parent=Path(effect["output_parent"]["path"]);assert sha(parent/effect["output_parent"]["owner_marker"])==effect["output_parent"]["owner_sha256"]
assert sha(Path(effect["interpreter"]["path"]))==effect["interpreter"]["sha256"]
for suffix in ("",".intent.jsonl"):assert not (parent/("system-input-"+plan.request_id+suffix)).exists()
record={"schema":"aide.host.h2-input-root-source-effect-review.v1","result":"PASS_bounded_read_only_effect_admitted","source_manifest_sha256":sha(E/"h2-input-source-manifest.json"),"source_aggregate":m["aggregate"],"effect_raw_sha256":sha(E/m["effect_manifest"]),"effect_canonical_sha256":hashlib.sha256(read._canonical(effect)).hexdigest(),"tests_run":result.testsRun,"independent_additional_methods":6,"independent_subcases":28,"test_log_sha256":sha(path),"source_dependencies_and_index_unchanged":True,"head":head,"review":"Read full child/controller/tests and borrowed native methods, exact-open and job/journal mechanisms. Independent tests add all8acquisition expiry/all9false-release edges, serialization expiry, final controller release/freshness failures and5wireboolean aliases. No actual read facade/child/eightDLL effect occurred in this review.","approved_scope":{"ordinary_children":1,"exact_files":list(read.NAMES),"bytes":sum(x.size for x in plan.files),"read_only":True,"selected_resource_mappings":0,"private_image_or_ACL_or_profile_operations":0,"network_calls":0,"public_operation":False,"retain_only":True},"limits_and_premises":"Exact expiry/pins/owned parent/one-use journal and Job rechecked by controller. Ordinary Python tooling/bootstrap and protected same-user controller namespace are admitted premises, not qualified private runtime or OS provenance. Child execution30s,internal25s,controller success90s and separate existing cleanup budgets. FullAPI180/128/context/private-loader/operational activation remain open."}
p=E/"h2-input-root-source-effect-review.json";assert not p.exists();p.write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n");print(json.dumps({"result":record["result"],"review_sha256":sha(p),"tests":result.testsRun,"test_log_sha256":sha(path),"expiry_seconds_remaining":round(plan.expires_at-__import__("time").time())}))
