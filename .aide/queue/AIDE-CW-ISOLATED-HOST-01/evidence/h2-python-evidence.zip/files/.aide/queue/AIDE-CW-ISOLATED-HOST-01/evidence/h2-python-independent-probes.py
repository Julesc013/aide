import copy,difflib,hashlib,json,pathlib,random,struct,subprocess,sys,time,types,zlib
root=pathlib.Path(r"D:\Projects\AIDE\aide")
ev=root/".aide/queue/AIDE-CW-ISOLATED-HOST-01/evidence"
sys.path[:0]=[str(root),str(root/".aide/scripts/tests")]
from core.runtime.continuous_worker import windows_image as current,windows_pe
from core.runtime.continuous_worker.state import Refused
from test_continuous_worker_windows_image import fixture as image_fixture
from test_continuous_worker_python_image import fixture as library_fixture
from test_continuous_worker_windows_pe import fixture as pe_fixture
from core.runtime.continuous_worker.windows_python_image import LibrarySpec,build_stdlib
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest_raw=(ev/"h2-python-source-manifest.json").read_bytes();manifest=json.loads(manifest_raw)
def observe():
    result={p:sha((root/p).read_bytes()) for p in {**manifest["files"],**manifest["dependent_inputs"]}}
    assert result=={**manifest["files"],**manifest["dependent_inputs"]}
    return result
before=observe()
legacy_raw=subprocess.run(["git","show","HEAD:core/runtime/continuous_worker/windows_image.py"],cwd=root,capture_output=True,check=True,timeout=30).stdout
legacy=types.ModuleType("core.runtime.continuous_worker._independent_h2_legacy")
legacy.__package__="core.runtime.continuous_worker";sys.modules[legacy.__name__]=legacy
exec(compile(legacy_raw,"<verified-HEAD-windows_image>","exec"),legacy.__dict__)
cases=[]
def compare(label,value):
    outcomes=[]
    for module in (legacy,current):
        try:
            plan=module.ImagePlan.read(copy.deepcopy(value))
            outcomes.append({"status":"accepted","value":plan.to_value(),"fingerprint":plan.fingerprint})
        except Refused:outcomes.append({"status":"refused"})
    assert outcomes[0]==outcomes[1],label
    cases.append({"name":label,"status":outcomes[0]["status"],"fingerprint":outcomes[0].get("fingerprint")})
base=image_fixture();compare("baseline",base)
for path in ("nested/probe.exe","space dir/probe.exe","unicode-\u03a9/probe.exe","a/b/c/probe.exe"):
    value=copy.deepcopy(base);value["files"][0]["path"]=path;value["entrypoint"]=path;compare("output:"+path,value)
for path in ("nested/source.exe","space dir/source.exe","unicode-\u03a9/source.exe"):
    value=copy.deepcopy(base);value["files"][0]["source"]=path;compare("source:"+path,value)
for source in (False,True):
    for bad in ("../escape.exe","a\\escape.exe","NUL.exe","bad./x.exe","trailing /x.exe","x:stream.exe"):
        value=copy.deepcopy(base);key="source" if source else "path";value["files"][0][key]=bad;compare(key+":"+bad,value)
for case in ("duplicate_output","duplicate_source","directory_alias","file_directory"):
    value=copy.deepcopy(base);row=copy.deepcopy(value["files"][0])
    if case=="duplicate_output":row["path"]=row["path"].upper();row["source"]="other.exe"
    elif case=="duplicate_source":row["path"]="other.exe";row["source"]=row["source"].upper()
    elif case=="directory_alias":
        value["files"][0]["path"]="Alpha/probe.exe";value["entrypoint"]="Alpha/probe.exe";row["path"]="alpha/other.exe";row["source"]="other.exe"
    else:row["path"]=row["path"]+"/other.exe";row["source"]="other.exe"
    value["files"].append(row);compare(case,value)
value,inputs=library_fixture();bundle=build_stdlib(LibrarySpec.read(value),inputs);raw=bundle.files[0].contents
# Independent wire-format oracle: no zipfile reader or implementation size formula.
eocd=struct.unpack_from("<4s4H2IH",raw,len(raw)-22)
assert eocd[0]==b"PK\x05\x06" and eocd[1:3]==(0,0) and eocd[3]==eocd[4]==len(inputs) and eocd[-1]==0
central_size,central_start=eocd[5:7];assert central_start+central_size==len(raw)-22
cursor=0;local={}
while cursor<central_start:
    fields=struct.unpack_from("<4s5H3I2H",raw,cursor)
    sig,version,flags,method,tm,date,crc,packed,unpacked,name_len,extra_len=fields
    assert (sig,version,flags,method,tm,date,extra_len)==(b"PK\x03\x04",20,0,0,0,33,0)
    name=raw[cursor+30:cursor+30+name_len].decode("ascii");start=cursor+30+name_len
    payload=raw[start:start+packed]
    assert name not in local and packed==unpacked==len(payload)
    assert payload==inputs[name] and zlib.crc32(payload)&0xffffffff==crc
    local[name]={"offset":cursor,"sha256":sha(payload),"bytes":len(payload)}
    cursor=start+packed
assert cursor==central_start and list(local)==sorted(inputs)
for name in sorted(inputs):
    fields=struct.unpack_from("<4s6H3I5H2I",raw,cursor)
    sig,made,needed,flags,method,tm,date,crc,packed,unpacked,nlen,xlen,clen,disk,internal,external,offset=fields
    assert (sig,made,needed,flags,method,tm,date,xlen,clen,disk,internal,external)==(b"PK\x01\x02",20,20,0,0,0,33,0,0,0,0,0o100444<<16)
    assert raw[cursor+46:cursor+46+nlen].decode("ascii")==name
    assert offset==local[name]["offset"] and packed==unpacked==local[name]["bytes"]
    assert crc==zlib.crc32(inputs[name])&0xffffffff
    cursor+=46+nlen
assert cursor==len(raw)-22
# Finite malformed metadata exploration only: no loader or real PE input.
rng=random.Random(634105);base_pe=pe_fixture(delayed=("VERSION.dll",),forwarders=("NTDLL.Target",))
statuses={"accepted_metadata":0,"typed_refusal":0};mutations=[];start=time.monotonic()
for i in range(1024):
    data=bytearray(base_pe)
    if i%8==0:data=data[:rng.randrange(0,len(data))]
    else:
        for _ in range(1+i%4):
            offset=rng.randrange(len(data));data[offset]=rng.randrange(256)
    try:
        info=windows_pe.read_pe(bytes(data));assert info.sha256==sha(data)
        statuses["accepted_metadata"]+=1
    except Refused:statuses["typed_refusal"]+=1
    mutations.append(sha(data))
after=observe();assert before==after
receipt={"schema":"aide.h2.python.independent-probes.v1","source_manifest_sha256":sha(manifest_raw),"source_aggregate_sha256":manifest["aggregate_sha256"],"legacy_source_git_blob":subprocess.run(["git","rev-parse","HEAD:core/runtime/continuous_worker/windows_image.py"],cwd=root,capture_output=True,check=True,timeout=30).stdout.decode().strip(),"legacy_source_sha256":sha(legacy_raw),"v1_differential_cases":cases,"wire_zip":{"bytes":len(raw),"sha256":sha(raw),"members":local,"oracle":"Independent struct local-header/central/EOCD reader; CRC and exact member bytes; no zipfile reader"},"pe_mutations":{"count":1024,"seed":634105,"outcomes":statuses,"mutation_digest":sha(json.dumps(mutations,separators=(",",":")).encode()),"elapsed_seconds":time.monotonic()-start,"boundary":"Malformed synthetic metadata only. Accepted metadata does not imply loadability."},"source_unchanged":True,"effects":"Pure in-memory source/schema/archive/PE checks only; no tool, image, profile, grant or isolated launch.","script_sha256":sha(pathlib.Path(__file__).read_bytes())}
with (ev/"h2-python-independent-probes.json").open("x",encoding="utf-8",newline="\n") as out:json.dump(receipt,out,indent=2);out.write("\n")
print(json.dumps({"v1_cases":len(cases),"zip_members":len(local),"pe":statuses,"receipt_sha256":sha((ev/"h2-python-independent-probes.json").read_bytes())}))
