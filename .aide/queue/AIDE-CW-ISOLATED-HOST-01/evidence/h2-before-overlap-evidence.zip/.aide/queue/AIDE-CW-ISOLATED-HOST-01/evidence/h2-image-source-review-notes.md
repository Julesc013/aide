# H2 bounded image preparation source review

The three-file source slice prepares admitted bytes. It does not qualify a
Python/Git/Codex toolchain or install a host. The frozen manifest binds the exact
source, complete patch, unchanged dependent inputs and final 57-test receipt.

Image admission is immutable and exact: native source/parent identities, literal
paths, independent per-file/aggregate/entry/time limits, exact sizes and SHA256s,
case/file-directory collision checks, and one specific package SID. The separate
64 KiB streaming API allows at most 512 MiB per file and 768 MiB per image with
2,048 entries; the existing H1 and candidate 16 MiB limits remain unchanged.
Read-only source handles refuse write/delete sharing and reparses. Copying binds
file identity, single-link ordinary-file metadata and bytes. Complete copies are
sealed before any package read grant. Error paths close handles and retain paths.

The create-only reservation is durable before generation creation. Existing
reservation names are always refused, including after abrupt process death before
creation or during a copy. There is no cleanup, adoption or automatic retry API.
Preparation expiry is checked through the final durable flush and observations.
An externally protected controller must supply the current guard and protect the
input/store namespace and journal. Synchronous kernel I/O still requires a
qualified outer owned process for a stalled-call wall limit. These premises have
not been established for a real tool image by this source-only test increment.

The 20 H2 tests use ordinary synthetic files. They exercise actual native reads
and writes, a 16 MiB-plus stream, empty streams, concurrent reservation, retained
traceback handle release and two actual abrupt subprocess deaths. Image creation,
sealing and grants in preparation protocol tests use the explicit synthetic
adapter: they do not qualify native DACL operations or executable loading. The
27 existing security source tests and 10 actual Windows Job regressions also pass.
The original RED log preserves two source-alias and final-flush deadline failures;
all three were fixed before the final run. No source bytes changed during it.

Next required implementation: exact Python library/archive and PE dependency
closure, a pinned private-image effect proposal, current owned-store descriptor
and grant denial evidence, and an actual isolated offline Python run. Git/Codex
loading and model egress remain separate host qualification work. No H2 profile,
package grant, real tool copy or AppContainer effect is authorized by this source
manifest. H1's four consumed effect packets remain immutable; its native-only
result does not qualify any of these new image paths.

Independent review reproduced a P2 namespace mismatch with distinct ordinary
parent and native parent. directories. Root admission now refuses trailing
space/dot ancestors, DOS devices including superscript aliases, Win32 special
characters and unpaired surrogates before any open. Valid internal spaces and
Unicode remain admitted, with UTF-16 unit bounds. Pure refusal tests and a real
ordinary distinct-parent fixture pass; no journal or image callback is reached.
Original source, review script/receipt and 55-test logs are retained byte-for-byte
in the 12-member h2-before-root-alias-evidence.zip. The reviewer's original
retained fixture was not changed or replayed.
