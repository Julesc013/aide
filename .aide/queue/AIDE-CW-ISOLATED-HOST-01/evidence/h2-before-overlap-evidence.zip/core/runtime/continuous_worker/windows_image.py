"""Bounded private image admission and retained preparation; no installed host factory."""
from __future__ import annotations
from contextlib import ExitStack, closing
import ctypes as C
from ctypes import wintypes as W
from dataclasses import dataclass, replace
import hashlib
import json
import math
import os
from pathlib import Path, PureWindowsPath
import re
import time

from . import windows_security_objects as native
from .state import Refused

CHUNK = 65536


def _integer(value, lower, upper, name):
    if type(value) is not int or not lower <= value <= upper:
        raise Refused(f"bounded integer {name} required")
    return value


def _digest(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise Refused("literal SHA256 required")
    return value


def _identity(value):
    if (not isinstance(value, dict) or set(value) != {"volume", "file_id"} or
            type(value["volume"]) is not int or not 0 < value["volume"] < 2**64 or
            not isinstance(value["file_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", value["file_id"]) or
            value["file_id"] == "0" * 32):
        raise Refused("exact native volume and object identity required")
    return value["volume"], value["file_id"]


def relative_path(value):
    if not isinstance(value, str) or not value or len(value) > 160 or "\\" in value:
        raise Refused("bounded slash-separated image path required")
    parts = value.split("/")
    if len(parts) > 12:
        raise Refused("image directory depth exceeds bound")
    for part in parts:
        native.literal_component(part)
    return tuple(parts)


def _utf16_units(value):
    try:
        return len(value.encode("utf-16-le")) // 2
    except UnicodeEncodeError as error:
        raise Refused("well-formed Unicode Windows path required") from error


def _root(value):
    if not isinstance(value, str) or _utf16_units(value) > 180:
        raise Refused("bounded absolute private-image root required")
    path = PureWindowsPath(value)
    if (not path.is_absolute() or not re.fullmatch(r"[A-Za-z]:", path.drive) or
            str(path) != value or any(part in (".", "..") for part in path.parts) or
            any(c in value[2:] for c in (":", "\x00"))):
        raise Refused("canonical local image root required")
    for part in path.parts[1:]:
        # NT object names and Win32 journal paths must have one spelling. Keep
        # legitimate internal spaces/Unicode, but refuse Win32-normalized names.
        device = part.split(".", 1)[0].rstrip(" ").upper().translate(str.maketrans("¹²³", "123"))
        if (part.endswith((".", " ")) or re.search(r'[<>"|?*\x00-\x1f]', part) or
                device in {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$", "CLOCK$"} or
                re.fullmatch(r"(?:COM|LPT)[1-9]", device)):
            raise Refused("ambiguous Windows root component refused")
    return path


@dataclass(frozen=True)
class ImageLimits:
    entries: int
    file_bytes: int
    total_bytes: int
    seconds: int

    def __post_init__(self):
        _integer(self.entries, 1, 2048, "entry count")
        _integer(self.file_bytes, 1, 512 * 1024 * 1024, "file bytes")
        _integer(self.total_bytes, self.file_bytes, 768 * 1024 * 1024, "total bytes")
        _integer(self.seconds, 1, 300, "preparation seconds")


@dataclass(frozen=True)
class ImageFile:
    path: str
    source: str
    size: int
    sha256: str
    source_identity: tuple[int, str]


@dataclass(frozen=True)
class ImagePlan:
    generation: str
    input_root: str
    input_identity: tuple[int, str]
    output_root: str
    parent_identity: tuple[int, str]
    user_sid: str
    package_sid: str
    entrypoint: str
    limits: ImageLimits
    files: tuple[ImageFile, ...]
    fingerprint: str

    @classmethod
    def read(cls, value):
        fields = {"schema", "generation", "input_root", "input_identity", "output_root", "parent_identity",
                  "user_sid", "package_sid", "entrypoint", "limits", "files"}
        if not isinstance(value, dict) or set(value) != fields or value["schema"] != "aide.host.private-image.v1":
            raise Refused("known exact private-image plan required")
        generation = value["generation"]
        if not isinstance(generation, str) or not re.fullmatch(r"[0-9a-f]{32}", generation):
            raise Refused("literal private-image generation required")
        source, output = _root(value["input_root"]), _root(value["output_root"])
        if output.name != "image-" + generation or source == output or source in output.parents or output in source.parents:
            raise Refused("separate input and uniquely named output image required")
        limits = value["limits"]
        if not isinstance(limits, dict) or set(limits) != {"entries", "file_bytes", "total_bytes", "seconds"}:
            raise Refused("explicit private-image limits required")
        limits = ImageLimits(**limits)
        user, package = native.sid_text(value["user_sid"]), native.sid_text(value["package_sid"])
        if not re.fullmatch(r"S-1-15-2-(?:[0-9]+-){6}[0-9]+", package):
            raise Refused("one specific package SID required")
        if not isinstance(value["files"], list) or not 1 <= len(value["files"]) <= limits.entries:
            raise Refused("bounded nonempty image files required")
        files, names, directories, sources, source_directories, total = [], {}, {}, set(), {}, 0
        for row in value["files"]:
            if not isinstance(row, dict) or set(row) != {"path", "source", "size", "sha256", "source_identity"}:
                raise Refused("known exact image file required")
            parts, origin = relative_path(row["path"]), relative_path(row["source"])
            path, source_name = "/".join(parts), "/".join(origin)
            key = path.casefold()
            if key in names or source_name.casefold() in sources:
                raise Refused("image file or source alias collision")
            if _utf16_units(str(output.joinpath(*parts))) > 240 or _utf16_units(str(source.joinpath(*origin))) > 240:
                raise Refused("materialized native path exceeds bound")
            for components, registered in ((parts, directories), (origin, source_directories)):
                for i in range(1, len(components)):
                    directory = "/".join(components[:i]); folded = directory.casefold()
                    if folded in registered and registered[folded] != directory:
                        raise Refused("case-aliased image or source directory")
                    registered[folded] = directory
            names[key] = path; sources.add(source_name.casefold())
            size = _integer(row["size"], 0, limits.file_bytes, "declared file size")
            total += size
            files.append(ImageFile(path, source_name, size, _digest(row["sha256"]), _identity(row["source_identity"])))
        if (names.keys() & directories.keys() or sources & source_directories.keys() or
                len(names) + len(directories) > limits.entries or total > limits.total_bytes):
            raise Refused("file/directory collision or aggregate image limit exceeded")
        entrypoint = "/".join(relative_path(value["entrypoint"]))
        if entrypoint not in names.values() or not entrypoint.lower().endswith(".exe"):
            raise Refused("exact declared executable entrypoint required")
        result = cls(generation, str(source), _identity(value["input_identity"]), str(output),
                   _identity(value["parent_identity"]), user, package, entrypoint, limits,
                   tuple(sorted(files, key=lambda row: row.path)), "")
        canonical = json.dumps(result.to_value(), sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        return replace(result, fingerprint=hashlib.sha256(canonical).hexdigest())

    def to_value(self):
        identity = lambda pair: {"volume": pair[0], "file_id": pair[1]}
        return {"schema": "aide.host.private-image.v1", "generation": self.generation,
                "input_root": self.input_root, "input_identity": identity(self.input_identity),
                "output_root": self.output_root, "parent_identity": identity(self.parent_identity),
                "user_sid": self.user_sid, "package_sid": self.package_sid, "entrypoint": self.entrypoint,
                "limits": {key: getattr(self.limits, key) for key in ("entries", "file_bytes", "total_bytes", "seconds")},
                "files": [{"path": row.path, "source": row.source, "size": row.size, "sha256": row.sha256,
                           "source_identity": identity(row.source_identity)} for row in self.files]}

    def validate(self):
        try:
            if ImagePlan.read(self.to_value()) != self:
                raise Refused("typed image plan differs from its validated immutable value")
        except (AttributeError, TypeError, ValueError, IndexError) as error:
            raise Refused("complete immutable image admission required") from error
        return self

    @property
    def reservation(self):
        return str(PureWindowsPath(self.output_root).parent / ("image-" + self.generation + ".intent.jsonl"))


class _STANDARD(C.Structure):
    _fields_ = [("allocation", C.c_longlong), ("size", C.c_longlong), ("links", W.DWORD),
                ("delete_pending", C.c_ubyte), ("directory", C.c_ubyte)]


def _file_size(handle):
    value = _STANDARD()
    native._check(native.get_identity(handle, 1, C.byref(value), C.sizeof(value)))
    if value.links != 1 or value.delete_pending or value.directory or value.size < 0:
        raise Refused("one ordinary stable source file required")
    return value.size


class SourceDirectory:
    """Read-only no-reparse lease; its existing objects are never granted or deleted."""
    def __init__(self, path, expected, guard):
        self.path, self.expected, self.guard = path, expected, guard
        self.handle = native._open(native.native_path(path), None, directory=True, create=False,
                                   read_only_source=True, guard=guard)
        try:
            self.check()
        except Exception:
            self.close()
            raise

    def check(self):
        self.guard()
        if self.handle is None or tuple(native._identity(self.handle)[key] for key in ("volume", "file_id")) != self.expected:
            raise Refused("protected source or parent object changed")

    def close(self):
        if self.handle is not None:
            native.close(self.handle); self.handle = None

    def chunks(self, entry):
        self.check()
        handles, parent = [], self.handle
        try:
            parts = relative_path(entry.source)
            for i, part in enumerate(parts):
                handle = native._open(part, parent, directory=i < len(parts) - 1, create=False,
                                      read_only_source=True, guard=self.guard)
                handles.append(handle); parent = handle
            expected = tuple(native._identity(parent)[key] for key in ("volume", "file_id"))
            if expected != entry.source_identity or _file_size(parent) != entry.size:
                raise Refused("source file identity or size differs from admission")
            read_file = native.bind(native.K, "ReadFile", [W.HANDLE, C.c_void_p, W.DWORD, C.POINTER(W.DWORD), C.c_void_p], W.BOOL)
            remaining = entry.size
            while remaining:
                self.check(); self.guard()
                length = min(CHUNK, remaining); block, count = C.create_string_buffer(length), W.DWORD()
                native._check(read_file(parent, block, length, C.byref(count), None))
                if count.value != length:
                    raise Refused("protected source returned an incomplete chunk")
                remaining -= length
                yield block.raw
            self.check()
            if tuple(native._identity(parent)[key] for key in ("volume", "file_id")) != expected or _file_size(parent) != entry.size:
                raise Refused("protected source changed during copy")
        finally:
            for handle in reversed(handles): native.close(handle)


@dataclass
class PreparedImage:
    plan: ImagePlan
    objects: tuple
    observations: tuple
    closed: bool = False
    leases: object = None

    def check(self):
        if self.closed or tuple(obj.observe() for obj in self.objects) != self.observations:
            raise Refused("prepared image object or descriptor changed")
        return self.observations

    def close(self):
        for obj in reversed(self.objects): obj.close()
        if self.leases is not None: self.leases.close()
        self.closed = True


def prepare_image(plan, *, guard, clock=time.monotonic):
    """Prepare admitted bytes only; tool/DLL/runtime qualification remains separate.

    Local synchronous I/O gets checks before/after operations. A qualified outer
    owned process must still enforce the wall limit if a kernel call stalls.
    """
    if not isinstance(plan, ImagePlan) or not callable(guard):
        raise Refused("trusted typed image plan and current controller guard required")
    plan.validate()
    preparing = True
    started = clock()
    if type(started) not in (int, float) or not math.isfinite(started):
        raise Refused("finite monotonic image clock required")
    deadline = started + plan.limits.seconds
    def current():
        guard()
        now = clock()
        if type(now) not in (int, float) or not math.isfinite(now) or (now < started or (preparing and now >= deadline)):
            raise Refused("private-image preparation deadline expired or regressed")
    current()
    objects, transferred = [], False
    with ExitStack() as stack:
        source = SourceDirectory(plan.input_root, plan.input_identity, current); stack.callback(source.close)
        parent = SourceDirectory(str(PureWindowsPath(plan.output_root).parent), plan.parent_identity, current); stack.callback(parent.close)
        def live():
            current(); source.check(); parent.check()
        live()
        # The retained parent lease prevents path substitution while CREATE_NEW
        # reserves a journal. No existing journal or generation is ever adopted.
        try:
            journal = open(plan.reservation, "xb", buffering=0)
        except FileExistsError as error:
            raise Refused("image reservation already exists; retain without replay") from error
        stack.callback(journal.close)
        def append(value):
            raw = (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()
            if len(raw) > 4 * 1024 * 1024 or journal.write(raw) != len(raw):
                raise Refused("bounded durable image journal write required")
            os.fsync(journal.fileno())
        append({"schema": "aide.host.image-intent.v1", "generation": plan.generation,
                "plan_sha256": plan.fingerprint, "output_root": plan.output_root, "cleanup": "retain_only"})
        try:
            live()
            root = native.OwnedObject.create_root(plan.output_root, plan.user_sid, guard=live); objects.append(root)
            directories = {(): root}
            for entry in plan.files:
                live(); parts = relative_path(entry.path)
                for i in range(1, len(parts)):
                    prefix = parts[:i]
                    if prefix not in directories:
                        obj = directories[prefix[:-1]].child(prefix[-1], directory=True)
                        directories[prefix] = obj; objects.append(obj)
                obj = directories[parts[:-1]].child(parts[-1]); objects.append(obj)
                with closing(source.chunks(entry)) as chunks:
                    obj.write_stream(chunks, size=entry.size, sha256=entry.sha256,
                                     limit=plan.limits.file_bytes, deadline=deadline, clock=clock)
            for obj in reversed(objects): obj.seal()
            # Package access begins only once every byte copy completed.
            for obj in objects: obj.grant(plan.package_sid, mode="read")
            observations = tuple(obj.observe() for obj in objects)
            live()
            append({"phase": "prepared_bytes", "plan_sha256": plan.fingerprint,
                    "objects": observations, "tool_runtime_qualified": False, "cleanup": "retain_only"})
            # The durable flush and final observations also consume the deadline.
            live()
            result = PreparedImage(plan, tuple(objects), observations)
            result.check()
            journal.close()
            live()
            preparing = False
            result.leases = stack.pop_all()
            transferred = True
            return result
        except Exception:
            # A failure record is best effort only. The durable initial intent
            # already makes unknown/interrupted preparation ineligible to replay.
            try: append({"phase": "failed_or_uncertain", "cleanup": "retain_only"})
            except Exception: pass
            raise
        finally:
            if not transferred:
                for obj in reversed(objects): obj.close()
