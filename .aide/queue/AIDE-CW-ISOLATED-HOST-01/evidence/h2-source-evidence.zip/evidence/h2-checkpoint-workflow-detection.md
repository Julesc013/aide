# AIDE Git Workflow Detection

- schema_version: aide.git-workflow-detection.v0
- generated_by: aide-lite
- non_mutating: true
- current_branch: task/aide-cw-integration-broker-01
- current_commit: 454e41aa021c2b8b8b48531f2cb67838ecaa7dab
- current_branch_role: task
- detected_workflow: trunk_with_dev_integration
- confidence: high
- canonical_branch: main
- integration_branch: dev
- recommended_next_action: classify dirty tree before branch-sensitive work

## Branch Summary

- local_branches: 4
- remote_branches: 4
- tags_count: 0

## Warnings

- dirty_tree_detected

## Q28 Boundary

This report was generated without branch creation, deletion, merge, prune, push,
fetch, GitHub API mutation, provider calls, model calls, or network calls.
