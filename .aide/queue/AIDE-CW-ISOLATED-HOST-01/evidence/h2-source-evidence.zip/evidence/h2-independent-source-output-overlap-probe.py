
from pathlib import Path
from unittest.mock import patch
import ctypes as C,tempfile,hashlib,json,sys
repo=Path(r"D:\Projects\AIDE\aide");sys.path.insert(0,str(repo))
from core.runtime.continuous_worker import windows_image as image, windows_security_objects as native
from core.runtime.continuous_worker.state import Refused
e=Path("D:\\Projects\\AIDE\\aide\\.aide\\queue\\AIDE-CW-ISOLATED-HOST-01\\evidence")
folder=Path(tempfile.mkdtemp(prefix="aide-h2-synthetic-review-"))
trusted=folder/"Trusted input with spaces";trusted.mkdir();(trusted/"probe.exe").write_bytes(b"test")
api=C.WinDLL("kernel32",use_last_error=True).GetShortPathNameW
api.argtypes=[C.c_wchar_p,C.c_wchar_p,C.c_uint];api.restype=C.c_uint
buf=C.create_unicode_buffer(32768);size=api(str(trusted),buf,len(buf));assert 0<size<len(buf)
alias=Path(buf.value);assert alias!=trusted and alias.samefile(trusted)
def ident(path,directory):
 h=native._open(native.native_path(str(path)),None,directory=directory,create=False,read_only_source=True)
 try:return native._identity(h)
 finally:native.close(h)
identity=ident(trusted,True)
value={"schema":"aide.host.private-image.v1","generation":"c"*32,"input_root":str(trusted),"input_identity":identity,"output_root":str(alias/("image-"+"c"*32)),"parent_identity":identity,"user_sid":"S-1-5-21-11-22-33-1001","package_sid":"S-1-15-2-11-22-33-44-55-66-77","entrypoint":"probe.exe","limits":{"entries":2,"file_bytes":16,"total_bytes":16,"seconds":10},"files":[{"path":"probe.exe","source":"probe.exe","size":4,"sha256":hashlib.sha256(b"test").hexdigest(),"source_identity":ident(trusted/"probe.exe",False)}]}
plan=image.ImagePlan.read(value)
with patch.object(native.OwnedObject,"create_root",side_effect=Refused("synthetic stop; no image or grants")) as create:
 try:image.prepare_image(plan,guard=lambda:None)
 except Exception as error:outcome={"type":type(error).__name__,"text":str(error)}
 called=create.call_count
intent=trusted/Path(plan.reservation).name
result={"schema":"aide.h2.independent-source-output-overlap-probe.v1","source_manifest_sha256":hashlib.sha256((e/"h2-image-source-manifest.json").read_bytes()).hexdigest(),"fixture":str(folder),"plan":value,"plan_admitted":True,"input_and_output_parent_same_object":True,"intent_created_in_readonly_input":intent.exists(),"create_callback_calls":called,"error":outcome,"actual_image_created":False,"package_grants":False,"retention":"All ordinary synthetic fixture files retained."}
if intent.exists():result["intent_sha256"]=hashlib.sha256(intent.read_bytes()).hexdigest()
p=e/"h2-independent-source-output-overlap-probe.json"
with p.open("x",encoding="utf-8") as f:f.write(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2));print("SHA256",hashlib.sha256(p.read_bytes()).hexdigest())
