# Independent H2 source review

PASS for the bounded source and ordinary synthetic-test slice. No remaining P0/P1/P2 finding in the reviewed delta.

The review binds HEAD 454e41aa021c2b8b8b48531f2cb67838ecaa7dab, aggregate 9be03cf59281c72ec8152cabd5acf41b4477bff6963643a2e4adb573feed9a3d, three authored source files, five unchanged dependencies and complete patch 4a35dbe32c879d3a6fec3a86fc331187959ae7b0a7b69cbccc825351f70aa826. The patch was reconstructed exactly and source/index stayed unchanged.

Both independent P2 probes are resolved: trailing-dot ancestors no longer redirect the intent, and actual short-name equal/nested source-output aliases refuse before reservation. The original failed source packets and concrete fixture bytes remain preserved.

I independently reran 26 image, 27 security and 10 ordinary Windows Job tests: all 63 passed. These cover actual bounded streaming, retained interruptions, the two retained attacks, relative journal creation, mapping-drift refusal, non-inheritable descriptors and both CRT transfer failures. Preparation image creation/sealing/grants remain explicitly modeled.

Creation now uses the held directory as [NtCreateFile RootDirectory](https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntcreatefile). [Normalized NT names](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfinalpathnamebyhandlew) support conservative overlap refusal alongside object IDs; they do not substitute for ownership or freeze global drive mappings. [CRT handle transfer](https://learn.microsoft.com/en-us/cpp/c-runtime-library/reference/open-osfhandle?view=msvc-170) preserves one closing owner.

The existing H1 16 MiB write ceiling remains. The separate image stream has explicit limits and no reuse after uncertain failure. Current controller/namespace protection, outer-process hard deadlines, native image grants, tool/dependency closure and isolated runtime loading remain open. This review authorizes no activation, profile use, real tool copy or package grant.

Exact evidence and remaining limits are in h2-independent-final-review.json.
