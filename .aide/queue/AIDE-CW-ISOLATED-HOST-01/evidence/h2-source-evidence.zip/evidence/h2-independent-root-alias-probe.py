
from pathlib import Path
from unittest.mock import patch
import ctypes, tempfile, json, hashlib, sys, os
repo=Path(r"D:\Projects\AIDE\aide")
sys.path.insert(0,str(repo))
from core.runtime.continuous_worker import windows_image as image
from core.runtime.continuous_worker import windows_security_objects as native
from core.runtime.continuous_worker.state import Refused
e=Path("D:\\Projects\\AIDE\\aide\\.aide\\queue\\AIDE-CW-ISOLATED-HOST-01\\evidence")
files=["core/runtime/continuous_worker/windows_image.py","core/runtime/continuous_worker/windows_security_objects.py",".aide/scripts/tests/test_continuous_worker_windows_image.py"]
hashes={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in files}
folder=Path(tempfile.mkdtemp(prefix="aide-h2-synthetic-review-")).resolve()
ordinary=folder/"parent"; ordinary.mkdir()
literal=str(folder/"parent.")
extended="\\\\?\\"+literal
os.mkdir(extended)
trusted=folder/"trusted";trusted.mkdir();data=b"synthetic";(trusted/"probe.exe").write_bytes(data)
def identity(path,directory):
 h=native._open(native.native_path(str(path)),None,directory=directory,create=False,read_only_source=True)
 try:return native._identity(h)
 finally:native.close(h)
native_parent=identity(literal,True)
ordinary_parent=identity(ordinary,True)
assert native_parent!=ordinary_parent
value={"schema":"aide.host.private-image.v1","generation":"b"*32,"input_root":str(trusted),"input_identity":identity(trusted,True),"output_root":literal+"\\image-"+"b"*32,"parent_identity":native_parent,"user_sid":"S-1-5-21-11-22-33-1001","package_sid":"S-1-15-2-11-22-33-44-55-66-77","entrypoint":"probe.exe","limits":{"entries":2,"file_bytes":16,"total_bytes":16,"seconds":10},"files":[{"path":"probe.exe","source":"probe.exe","size":len(data),"sha256":hashlib.sha256(data).hexdigest(),"source_identity":identity(trusted/"probe.exe",False)}]}
plan=image.ImagePlan.read(value)
error=None
with patch.object(native.OwnedObject,"create_root",side_effect=Refused("synthetic stop after reservation; no image/grants")) as create:
 try:image.prepare_image(plan,guard=lambda:None)
 except Exception as exc:error={"type":type(exc).__name__,"text":str(exc)}
called=create.call_count
reserved_name=Path(plan.reservation).name
observed=ordinary/reserved_name
literal_reservation=extended+"\\"+reserved_name
result={"schema":"aide.h2.independent-root-alias-probe.v1","source":hashes,"fixture":str(folder),"plan_admitted":True,"held_parent":native_parent,"ordinary_alias_parent":ordinary_parent,"reservation_spelling":plan.reservation,"reservation_in_ordinary_alias":observed.exists(),"reservation_in_native_held_parent":os.path.exists(literal_reservation),"image_create_callback_calls":called,"error":error,"actual_image_created":False,"package_grants":False,"retention":"All ordinary synthetic files retained; no delete or profile/grant effect."}
if observed.exists():
 raw=observed.read_bytes();result["retained_reservation"]={"path":str(observed),"sha256":hashlib.sha256(raw).hexdigest(),"rows":[json.loads(x) for x in raw.splitlines()]}
assert hashes=={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in files}
out=e/"h2-independent-root-alias-probe.json"
with out.open("x",encoding="utf-8") as f:f.write(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2));print("RECEIPT_SHA256",hashlib.sha256(out.read_bytes()).hexdigest())
