
from pathlib import Path
import hashlib,json,subprocess,os,time,sys,difflib,zipfile
from unittest.mock import patch
repo=Path(r"D:\Projects\AIDE\aide");e=repo/".aide/queue/AIDE-CW-ISOLATED-HOST-01/evidence"
sys.path.insert(0,str(repo))
from core.runtime.continuous_worker import windows_image as image
from core.runtime.continuous_worker.state import Refused
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest_raw=(e/"h2-image-source-manifest.json").read_bytes()
assert sha(manifest_raw)=="9e6c745cdd0014cff17b8a2acc6e8b26e32d87a29ad1be402439405778cb859f"
m=json.loads(manifest_raw);inputs=dict(m["files"],**m["dependent_inputs"])
for name,d in inputs.items():assert sha((repo/name).read_bytes())==d,name
assert sha(json.dumps(m["files"],sort_keys=True,separators=(",",":")).encode())==m["aggregate_sha256"]
def git(*args):return subprocess.check_output(["git","--no-optional-locks",*args],cwd=repo)
head=git("rev-parse","HEAD").decode().strip();assert head==m["source_base"]
index=git("ls-files","--stage","-z")
patchraw=(e/m["patch"]["path"]).read_bytes();assert len(patchraw)==m["patch"]["bytes"] and sha(patchraw)==m["patch"]["sha256"]
complete=b""
for name in sorted(m["files"]):
 tracked=subprocess.run(["git","--no-optional-locks","ls-files","--error-unmatch","--",name],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE).returncode==0
 if tracked:complete+=git("diff","--binary","HEAD","--",name)
 else:
  complete+=(f"diff --git a/{name} b/{name}\nnew file mode 100644\n"+"".join(difflib.unified_diff([], (repo/name).read_text(encoding="utf-8").splitlines(keepends=True),fromfile="/dev/null",tofile="b/"+name))).encode()
assert complete==patchraw,(len(complete),sha(complete))
prior=[]
for key in ("prior_source_custody","prior_overlap_custody"):
 r=m[key];p=e/r["zip"];raw=p.read_bytes();assert sha(raw)==r["sha256"]
 with zipfile.ZipFile(p) as z:
  assert len(z.namelist())==r["members"] and z.testzip() is None
  prior.append({"path":r["zip"],"sha256":sha(raw),"members":len(z.namelist())})
tests=json.loads((e/m["test_receipt"]["path"]).read_bytes())
assert sha((e/m["test_receipt"]["path"]).read_bytes())==m["test_receipt"]["sha256"]
for r in tests["runs"]:assert r["exit_code"]==0 and sha((e/r["log"]).read_bytes())==r["sha256"]
red1=json.loads((e/"h2-independent-root-alias-probe.json").read_bytes())
red2=json.loads((e/"h2-independent-source-output-overlap-probe.json").read_bytes())
assert sha((e/"h2-independent-root-alias-probe.json").read_bytes())=="eea6256c94c896680de5ed1a118d9d6cd33bc1c926d7af8cb9f0ca2f43086d54"
assert sha((e/"h2-independent-source-output-overlap-probe.json").read_bytes())=="3d251d26dc7a65be8facfcbc03ace1e76fae13435c9f9e3f6825e9c53008405c"
original_intent=Path(red1["retained_reservation"]["path"]);assert sha(original_intent.read_bytes())==red1["retained_reservation"]["sha256"]
other_intent=Path(red2["plan"]["input_root"])/Path(red2["plan"]["output_root"]).name
other_intent=other_intent.with_name(other_intent.name+".intent.jsonl")
assert sha(other_intent.read_bytes())==red2["intent_sha256"]
outcomes=[]
value=dict(red2["plan"]); value["output_root"]=str(Path(red1["reservation_spelling"]).parent/("image-"+value["generation"]))
with patch.object(image,"SourceDirectory") as source,patch.object(image,"_reserve_journal") as reserve:
 try:image.ImagePlan.read(value)
 except Refused as err:outcomes.append({"case":"retained-native-trailing-dot-root","status":"refused","detail":str(err)})
 else:raise AssertionError("trailing-dot plan admitted")
 source.assert_not_called();reserve.assert_not_called()
plan=image.ImagePlan.read(red2["plan"])
with patch.object(image,"_reserve_journal") as reserve,patch.object(image,"_create_image_root") as create:
 try:image.prepare_image(plan,guard=lambda:None)
 except Refused as err:outcomes.append({"case":"retained-8dot3-source-output-overlap","status":"refused","detail":str(err)})
 else:raise AssertionError("retained overlap admitted")
 reserve.assert_not_called();create.assert_not_called()
runs=[];env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1")
for pattern,label in (("test_continuous_worker_windows_image.py","image"),("test_continuous_worker_windows_security.py","security"),("test_continuous_worker_host.py","job")):
 args=[sys.executable,"-B","-m","unittest","discover","-s",".aide/scripts/tests","-p",pattern,"-v"]
 log=e/f"h2-independent-final-{label}.log";started=time.monotonic()
 with log.open("xb") as out:result=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
 runs.append({"argv":args,"exit":result.returncode,"seconds":time.monotonic()-started,"log":log.name,"sha256":sha(log.read_bytes())})
 assert result.returncode==0,label
for name,d in inputs.items():assert sha((repo/name).read_bytes())==d,name
assert git("ls-files","--stage","-z")==index
assert sha(original_intent.read_bytes())==red1["retained_reservation"]["sha256"]
assert sha(other_intent.read_bytes())==red2["intent_sha256"]
receipt={"schema":"aide.h2.independent-final-execution.v1","status":"pass","head":head,"base_tree":git("rev-parse","HEAD^{tree}").decode().strip(),"source_manifest_sha256":sha(manifest_raw),"source_aggregate":m["aggregate_sha256"],"patch_sha256":sha(patchraw),"patch_reconstructed_exactly":True,"inputs":inputs,"source_index_unchanged":True,"prior_archives":prior,"retained_failure_replays":outcomes,"runs":runs,"authority":"ordinary synthetic file and Job tests only; no real tools, package grants, profile or AppContainer launch effects"}
p=e/"h2-independent-final-execution.json"
with p.open("x",encoding="utf-8") as f:f.write(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"receipt":str(p),"sha256":sha(p.read_bytes()),"runs":runs,"replays":outcomes},indent=2))
