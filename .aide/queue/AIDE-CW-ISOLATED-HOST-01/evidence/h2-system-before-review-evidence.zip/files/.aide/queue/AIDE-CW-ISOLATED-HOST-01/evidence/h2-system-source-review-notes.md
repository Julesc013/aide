# System observation source review boundary

Source2 at base 236da6c2 adds the unconnected observation module and 32 direct
injected tests. All 133 selected tests pass in 4.742 seconds, including unchanged
101 PE/recipe/image/security/owned Job regressions. Source2, dependency15 and the
excluded provider-working index are unchanged across the run. The complete patch
contains both untracked files; plain git diff would omit them.

The plan snapshots exact native root/file facts, hashes and finite requests;
system files may have an explicitly pinned hard-link count. Existing private
ImageFile admission and all recipe/candidate/H1 caps remain unchanged. Canonical
request hashes include expiry, duration and all pins. A controller reservation
must acknowledge the exact plan hash; each mapping intent acknowledgement must
match SHA256 of the exact canonical intent. Acknowledgements are externally
protected journal contracts, not proof of an implemented durable store. A new
process/session needs that journal to refuse a consumed reservation; this source
does not by itself implement unattended recovery or cross-process exclusion.

Calls are counted before invocation. Finite expiry, monotonic elapsed time and
controller guard are checked around calls. Known acquired handles enter owned
cleanup before a post-call guard can fail; every release is consumed before
calling and never retried after uncertainty. Other held handles still close.
Synchronous backend/journal calls need the later registered outer-process wall
bound. The module is not wired into worker dispatch or operational activation.

Native mapping has one fixed resource-only flag combination. The adapter records
a complete native mapped path, and the session requires an exact held admitted
file plus matching identity/security/size/hash observations. An executable-tag
return needs the exact pre-call executable base, with unchanged before/after
executable inventory; it never triggers an executable-load fallback. Private
Python filenames and arbitrary physical loader requests are refused.

NativeSystemApi is never constructed by this test slice. Its low-level mapping
calls are injected mocks, including missing/truncated output and release cases.
There were no actual inspected DLL/API mappings, tool copies, grants, profiles or
isolated Python launches. The unchanged 180-name metadata superset still exceeds
the 128 API-row limit; real OS/native ownership, contextual API host resolution,
complete transitive inputs and actual loader observations remain unqualified.
All returned successful observation bytes explicitly retain those false flags.

The initial 29-test run is retained separately. Before final freeze, acknowledgements
were bound to exact request/intent hashes, typed facts/private names and invalid
handle/base observations were tightened, and explicit guard refusal was added.
The final 32 direct tests cover those boundaries in addition to expiry after
intent, post-acquisition guard failure, source/host drift, wrong handle origin,
byte mutation, operation/output ceilings and release uncertainty without replay.
