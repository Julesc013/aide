import hashlib,json,subprocess,sys
from pathlib import Path
A,E=map(Path,sys.argv[1:]);sys.path[:0]=[str(A),str(A/'.aide/scripts/tests')]
import test_continuous_worker_system_observation as tests
from core.runtime.continuous_worker import windows_system_observation as obs
from core.runtime.continuous_worker.state import Refused
def sha(b):return hashlib.sha256(b).hexdigest()
M=json.loads((E/'h2-system-source-manifest.json').read_bytes())
before={p:sha((A/p).read_bytes()) for p in (M['files']|M['dependent_inputs'])}
assert before==M['files']|M['dependent_inputs']
def git(*args):return subprocess.run(['git','-C',str(A),*args],capture_output=True,timeout=30,check=True).stdout
index=git('ls-files','--stage','-z')
rows=[]
for name,where,change in [
 ('deadline-final-root-close','close',lambda c:setattr(c,'now',20)),
 ('expiry-final-root-close','close',lambda c:setattr(c,'wall',2000)),
 ('guard-final-root-close','close',lambda c:setattr(c,'guard',lambda:False)),
 ('backward-final-root-close','close',lambda c:setattr(c,'now',9)),
 ('nonfinite-final-root-close','close',lambda c:setattr(c,'now',float('nan')))]:
 c=tests.ObservationTests();c.setUp()
 def hook(handle,c=c,change=change):
  if handle==16:change(c)
 c.api.hooks[where]=hook
 session=c.session()
 try:
  raw=session.run();result={'returned_success':True,'result':json.loads(raw)}
 except Refused as error:result={'returned_success':False,'error':str(error)}
 rows.append({'case':name,**result,'events':c.api.events,'resources_after':session.resources,
              'failure_after':session.failure,'consumed':session.consumed,
              'release_failures':session.release_failures})
 assert rows[-1]['returned_success'] is True,'RED expectation changed'
 assert session.consumed and not session.resources
 assert [v for v in c.api.events if v[0] in ('close','free')]==[('free',0x10002),('close',20),('close',16)]
before_equal=before=={p:sha((A/p).read_bytes()) for p in before}
assert before_equal and git('ls-files','--stage','-z')==index
receipt={'schema':'aide.host.system-observation-independent-final-guard-red.v1',
 'finding':'P2: successful final root close can expire monotonic/wall budget, move clock backward or revoke guard, but run returns success after cleanup without revalidation.',
 'source_base':M['source_base'],'source':M['files'],'source_dependencies_index_unchanged':True,
 'cases':rows,'effects':'Only pure injected NativeFake/journal callbacks. NativeSystemApi never constructed; no selected DLL loaded/mapped or filesystem fixture/ACL/image effects.',
 'script_sha256':sha(Path(__file__).read_bytes())}
b=(json.dumps(receipt,indent=2)+'\n').encode();p=E/'h2-system-independent-final-guard-red.json';p.open('xb').write(b)
print(json.dumps({'receipt':str(p),'sha256':sha(b),'cases':len(rows)}))

