import hashlib,json,sys
from pathlib import Path
A,E=map(Path,sys.argv[1:]);sys.path[:0]=[str(A),str(A/'.aide/scripts/tests')]
import test_continuous_worker_system_observation as t
from core.runtime.continuous_worker import windows_system_observation as obs
from core.runtime.continuous_worker.state import Refused
source={p:hashlib.sha256((A/p).read_bytes()).hexdigest() for p in ('core/runtime/continuous_worker/windows_system_observation.py','.aide/scripts/tests/test_continuous_worker_system_observation.py')}
rows=[]
for key in ('expires_at','max_seconds'):
 v=t.value();v[key]=10**1000
 try:obs.ObservationPlan.read(v);outcome='accepted'
 except BaseException as error:outcome=type(error).__name__
 rows.append({'case':'oversized_integer_'+key,'expected':'Refused','observed':outcome})
c=t.ObservationTests();c.setUp();c.api.mapped=t.NATIVE+r'\KERNELBASE.DLL'
s=c.session();raw=s.run();result=json.loads(raw)
rows.append({'case':'case_variant_mapped_path','held_native_path':c.api.file_facts.path,'mapped_native_path':c.api.mapped,
 'observed_mapping':result['mappings'][0],
 'scope':'Injected distinct-spelling model only. No actual case-sensitive system directory or native mapping exercised. Existing observer has no recorded case-sensitivity prerequisite and attributes the held ID/hash solely via folded spelling.'})
D={'schema':'aide.host.system-independent-admission-observations.v1','source':source,'cases':rows,
 'source_unchanged':source=={p:hashlib.sha256((A/p).read_bytes()).hexdigest() for p in source},
 'native_effects':False,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
p=E/'h2-system-independent-admission-observations.json';b=(json.dumps(D,indent=2)+'\n').encode();p.open('xb').write(b)
print(json.dumps({'sha256':hashlib.sha256(b).hexdigest(),'source':source,'cases':rows}))

