import ctypes as C, hashlib,json,sys
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
A,E=map(Path,sys.argv[1:]);sys.path[:0]=[str(A),str(A/'.aide/scripts/tests')]
import test_continuous_worker_system_observation as t
from core.runtime.continuous_worker import windows_system_observation as obs
from core.runtime.continuous_worker.state import Refused
rows=[]
def refused(session):
 try:session.run()
 except Refused:pass
 else:raise AssertionError('Expected typed refusal')
 assert session.consumed and not session.resources
 assert session.failure is not None
 events=list(session.api.events)
 try:session.run()
 except Refused:pass
 else:raise AssertionError('Replay admitted')
 assert session.api.events==events
for name,changed in (('elapsed',('now',20)),('wall',('wall',2000)),('guard',('guard',lambda:False)),('backward',('now',9)),('nan',('now',float('nan')))):
 c=t.ObservationTests();c.setUp()
 c.api.hooks['close']=lambda h,c=c,changed=changed:setattr(c,changed[0],changed[1]) if h==16 else None
 s=c.session();refused(s)
 assert [v for v in c.api.events if v[0] in ('close','free')]==[('free',0x10002),('close',20),('close',16)]
 rows.append({'case':'final_'+name,'result':'Refused','exact_release_once':True,'failure':s.failure})
# Expiry consumed by the very last guard before map must stop dispatch.
c=t.ObservationTests();c.setUp();count=[0]
def guard():
 count[0]+=1
 if count[0]==2:c.wall=2000
c.journal.on_intent=lambda:setattr(c,'guard',guard)
s=c.session();refused(s);assert not any(v[0]=='map' for v in c.api.events)
rows.append({'case':'pre_map_guard_expiry','result':'Refused','mapping_dispatches':0,'failure':s.failure})
for field in ('expires_at','max_seconds'):
 v=t.value();v[field]=10**1000
 try:obs.ObservationPlan.read(v)
 except Refused:pass
 else:raise AssertionError('Large temporal integer accepted')
 rows.append({'case':'large_'+field,'result':'Refused'})
c=t.ObservationTests();c.setUp();c.api.mapped=t.NATIVE+r'\KERNELBASE.DLL'
s=c.session();refused(s);rows.append({'case':'different_exact_native_spelling','result':'Refused'})
c=t.ObservationTests();c.setUp();c.api.file_facts=replace(c.api.file_facts,path=t.NATIVE+r'\KERNELBASE.DLL');c.api.mapped=c.api.file_facts.path
r=json.loads(c.session().run());assert r['mappings'][0]['mapped_path']==c.api.file_facts.path
rows.append({'case':'same_exact_observed_capitalized_spelling','result':'PASS'})
# Hit the real unchanged 8192 adapter-operation cap using short native reads.
c=t.ObservationTests();c.setUp();data=b'Z'*16384;c.api.data=data;c.api.file_facts=replace(c.api.file_facts,size=len(data))
v=t.value();v['files'][0].update(size=len(data),sha256=hashlib.sha256(data).hexdigest())
read=c.api.read_file;c.api.read_file=lambda h,n:read(h,min(n,1))
s=c.session(v);refused(s)
assert s.calls==8192==obs.MAX_NATIVE_CALLS and not any(x[0]=='map' for x in c.api.events)
assert [x for x in c.api.events if x[0]=='close']==[('close',20),('close',16)]
rows.append({'case':'real_adapter_operation_cap','calls':s.calls,'result':'Refused','read_calls':sum(x[0]=='read_file' for x in c.api.events)})
# Exercise the actual adapter facts implementation with all native calls mocked.
# Buffers are ordinary local Python ctypes allocations, never Windows allocations.
class Standard(C.Structure):
 _fields_=[('AllocationSize',C.c_longlong),('EndOfFile',C.c_longlong),('NumberOfLinks',obs.W.DWORD),('DeletePending',C.c_ubyte),('Directory',C.c_ubyte)]
for failure in ('none','security','sid','descriptor','oversized_descriptor','final_path'):
 api=obs.NativeSystemApi.__new__(obs.NativeSystemApi)
 sd=C.create_string_buffer(32);owner=C.create_string_buffer(16)
 owner_text=C.create_unicode_buffer('S-1-5-18')
 descriptor=C.create_unicode_buffer('x'*32769 if failure=='oversized_descriptor' else 'O:SYD:(A;;FR;;;SY)')
 addresses=[C.addressof(owner_text),C.addressof(descriptor),C.addressof(sd)]
 freed=[]
 def standard(handle,kind,out,size):
  assert kind==1 and size==C.sizeof(Standard)
  value=Standard(4096,128,3,0,0);C.memmove(out,C.byref(value),size);return True
 def final(handle,out,cap,flags):
  assert flags==2
  if failure=='final_path':return cap
  out.value=t.NATIVE+r'\kernelbase.dll';return len(out.value)
 def security(handle,kind,info,owner_out,g,d,sacl,sd_out):
  assert kind==1 and info==5
  C.cast(owner_out,C.POINTER(C.c_void_p))[0]=C.addressof(owner)
  C.cast(sd_out,C.POINTER(C.c_void_p))[0]=C.addressof(sd)
  return 5 if failure=='security' else 0
 def sid(pointer,out):
  C.cast(out,C.POINTER(obs.W.LPWSTR))[0]=C.cast(owner_text,obs.W.LPWSTR)
  return failure!='sid'
 def text(sdptr,revision,info,out,size):
  C.cast(out,C.POINTER(obs.W.LPWSTR))[0]=C.cast(descriptor,obs.W.LPWSTR)
  return failure!='descriptor'
 api._final=final;api._sid=sid
 with patch.object(obs.objects,'get_identity',standard),patch.object(obs.objects,'_identity',lambda h:{'volume':5,'file_id':'3'*32}),patch.object(obs.objects,'get_security',security),patch.object(obs.objects,'sd_to_text',text),patch.object(obs.objects,'local_free',lambda p:freed.append(p.value)):
  try:result=api.facts(20);caught=None
  except (Refused,OSError) as error:caught=type(error).__name__
 assert (caught is None)==(failure=='none')
 wanted=[] if failure=='final_path' else ([addresses[2]] if failure=='security' else ([addresses[0],addresses[2]] if failure=='sid' else addresses))
 assert freed==wanted,(failure,freed,wanted)
 rows.append({'case':'injected_native_facts_'+failure,'result':caught or 'PASS','exact_allocations_released_once':len(freed)})
D={'schema':'aide.host.system-observation-independent-reviewed-probes.v1','result':'PASS','cases':rows,
 'effects':'All new checks injected/pure. NativeSystemApi __new__ only; every native facts function mocked. No selected DLL/resource mapping, native allocation/free, image, ACL, grant, profile or loader-host execution.',
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
b=(json.dumps(D,indent=2)+'\n').encode();(E/'h2-system-independent-reviewed-probes.json').open('xb').write(b)
print('PASS',len(rows),'independent probe cases')

