import hashlib,json,os,subprocess,sys,time,zipfile
from pathlib import Path
A,E=map(Path,sys.argv[1:])
def sha(b):return hashlib.sha256(b).hexdigest()
def meta(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
M=json.loads((E/'h2-system-source-manifest.json').read_bytes())
assert sha((E/'h2-system-source-manifest.json').read_bytes())=='0259aa61259ccb8b590d1222ff2fb93ff3d2ee2f919200d5b9fad75a88c7ab68'
pins=M['files']|M['dependent_inputs']
assert {p:sha((A/p).read_bytes()) for p in pins}==pins
assert sha(json.dumps(M['files'],sort_keys=True,separators=(',',':')).encode())==M['aggregate_sha256']
def git(*args,ok=(0,)):
 p=subprocess.run(['git','-C',str(A),*args],capture_output=True,timeout=30)
 assert p.returncode in ok,p.stderr
 return p.stdout
assert git('rev-parse','HEAD').decode().strip()==M['source_base']
index=git('ls-files','--stage','-z')
complete=b''.join(git('diff','--no-index','--binary','--','/dev/null',p,ok=(1,)) for p in sorted(M['files']))
assert sha(complete)==M['patch']['sha256'] and complete==(E/M['patch']['path']).read_bytes()
assert sha((E/'h2-system-source-review-notes.md').read_bytes())==M['notes_sha256']
assert sha((E/'h2-system-observation-source-plan.md').read_bytes())==M['plan_sha256']
test=json.loads((E/M['test_receipt']['path']).read_bytes())
assert sha((E/M['test_receipt']['path']).read_bytes())==M['test_receipt']['sha256']
assert sha((E/test['log']).read_bytes())==test['log_sha256']
history=json.loads((E/'h2-system-before-review-custody.json').read_bytes())
hp=E/history['archive']['path'];assert sha(hp.read_bytes())==history['archive']['sha256']
with zipfile.ZipFile(hp) as z:
 assert len(z.namelist())==len(set(z.namelist()))==history['archive']['members']
 for name,v in history['members'].items():
  b=z.read(name);assert len(b)==v['bytes'] and sha(b)==v['sha256'],name
 # Prior reviewer original reproductions are unchanged.
 for n,h in [('h2-system-independent-final-guard-red.json','3f4db50845119bdf85e2fa8d71549f0b63b09ba76e4f97e44869bcd8d56b67ff'),('h2-system-independent-admission-observations.json','11f4f819d68e9d7c5dcd75537677bd58785eb3339eb1f8a97c758360606cd2d5')]:
  assert sha((E/n).read_bytes())==h
  assert z.read('files/.aide/queue/AIDE-CW-ISOLATED-HOST-01/evidence/'+n)==(E/n).read_bytes()
commands=[('tests',test['command'],120),('probes',[sys.executable,'-B',str(E/'h2-system-independent-reviewed-probes.py'),str(A),str(E)],45)]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');rows=[]
try:
 for name,argv,timeout in commands:
  start=time.monotonic()
  out=E/('h2-system-independent-'+name+'.stdout');err=E/('h2-system-independent-'+name+'.stderr')
  with out.open('xb') as o,err.open('xb') as x:
   p=subprocess.run(argv,cwd=A,env=env,stdout=o,stderr=x,timeout=timeout)
  rows.append({'name':name,'command':argv,'exit_code':p.returncode,'seconds':time.monotonic()-start,'stdout':meta(out),'stderr':meta(err)})
  print(name,p.returncode,round(rows[-1]['seconds'],3),flush=True)
  assert p.returncode==0,name
finally:
 unchanged={p:sha((A/p).read_bytes()) for p in pins}==pins
 unchanged_index=git('ls-files','--stage','-z')==index
 D={'schema':'aide.host.system-observation-independent-execution.v1','commands':rows,
 'source':M['files'],'dependencies':M['dependent_inputs'],'source_aggregate':M['aggregate_sha256'],
 'source_dependencies_unchanged':unchanged,'index_unchanged':unchanged_index,
 'source_manifest':meta(E/'h2-system-source-manifest.json'),'patch':meta(E/M['patch']['path']),
 'historical_archive_verified':meta(hp),'historical_members':history['archive']['members'],
 'notes':meta(E/'h2-system-source-review-notes.md'),'plan':meta(E/'h2-system-observation-source-plan.md'),
 'script':meta(Path(__file__)),
 'scope':'Source review, full selected synthetic/ordinary suite and new injected checks only. No actual selected system resource mapping, image/ACL grant or loader-host qualification.'}
 b=(json.dumps(D,indent=2)+'\n').encode();(E/'h2-system-independent-execution.json').open('xb').write(b)
 assert unchanged and unchanged_index
print(json.dumps(meta(E/'h2-system-independent-execution.json')))

