/* Disposable H1 denial probe: synthetic paths only, no cleanup or credentials. */
#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

static DWORD open_error(const wchar_t *path, DWORD access) {
    HANDLE value = CreateFileW(path, access, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                               NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (value != INVALID_HANDLE_VALUE) {
        CloseHandle(value);
        return ERROR_SUCCESS;
    }
    return GetLastError();
}

static int observe_loopback_error(unsigned short port) {
    WSADATA data;
    SOCKET connection;
    struct sockaddr_in address;
    u_long nonblocking = 1;
    int error = WSAStartup(MAKEWORD(2, 2), &data);
    ULONGLONG deadline = GetTickCount64() + 5000;
    if (error != 0) return error;
    connection = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (connection == INVALID_SOCKET) {
        error = WSAGetLastError();
    } else {
        ZeroMemory(&address, sizeof(address));
        address.sin_family = AF_INET;
        address.sin_port = htons(port);
        address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        if (ioctlsocket(connection, FIONBIO, &nonblocking) != 0) {
            error = WSAGetLastError();
        } else if (connect(connection, (const struct sockaddr *)&address, sizeof(address)) == SOCKET_ERROR) {
            error = WSAGetLastError();
            if (error == WSAEWOULDBLOCK) {
                /* A pending connect proves neither denial nor success. Wait
                   once for completion; never reconnect/retry after uncertainty. */
                fd_set writable, failed;
                struct timeval timeout;
                ULONGLONG now = GetTickCount64();
                ULONGLONG remaining = now < deadline ? deadline - now : 0;
                int ready;
                FD_ZERO(&writable); FD_SET(connection, &writable);
                FD_ZERO(&failed); FD_SET(connection, &failed);
                timeout.tv_sec = (long)(remaining / 1000);
                timeout.tv_usec = (long)((remaining % 1000) * 1000);
                ready = select(0, NULL, &writable, &failed, &timeout);
                if (GetTickCount64() >= deadline || ready == 0) {
                    error = WSAETIMEDOUT;
                } else if (ready == SOCKET_ERROR) {
                    error = WSAGetLastError();
                } else {
                    int length = sizeof(error);
                    if (getsockopt(connection, SOL_SOCKET, SO_ERROR, (char *)&error, &length) == SOCKET_ERROR) {
                        error = WSAGetLastError();
                    } else if (length != sizeof(error) ||
                               (error == 0 && (!FD_ISSET(connection, &writable) || FD_ISSET(connection, &failed)))) {
                        error = WSAEINVAL; /* Ambiguous completion never qualifies. */
                    }
                }
            }
        }
        closesocket(connection);
    }
    WSACleanup();
    return error;
}

int wmain(int argc, wchar_t **argv) {
    wchar_t scratch[1024];
    wchar_t *end = NULL;
    unsigned long parent, port;
    HANDLE file, process;
    DWORD written = 0, scratch_error, read_error, write_error, dacl_error, process_error;
    int network_error = 0;
    const char sample[] = "owned-native-probe";
    /* The two-argument entry exercises this exact oracle in an ordinary local
       process; the reviewed isolated effect always requires five arguments. */
    if (argc == 2) {
        port = wcstoul(argv[1], &end, 10);
        if (!port || port > 65535 || !end || *end) return 70;
        network_error = observe_loopback_error((unsigned short)port);
        printf("{\"network_error\":%d}\n", network_error);
        return network_error == 0 ? 0 : 74;
    }
    if (argc != 5 || wcslen(argv[1]) > 900 || wcslen(argv[2]) > 900) return 70;
    parent = wcstoul(argv[3], &end, 10);
    if (!parent || !end || *end) return 70;
    port = wcstoul(argv[4], &end, 10);
    if (!port || port > 65535 || !end || *end) return 70;
    if (swprintf_s(scratch, 1024, L"%ls\\native-created.txt", argv[1]) < 0) return 70;
    file = CreateFileW(scratch, GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
    scratch_error = file == INVALID_HANDLE_VALUE ? GetLastError() : ERROR_SUCCESS;
    if (file != INVALID_HANDLE_VALUE) {
        if (!WriteFile(file, sample, (DWORD)(sizeof(sample) - 1), &written, NULL) ||
                written != sizeof(sample) - 1 || !FlushFileBuffers(file)) {
            scratch_error = GetLastError();
            if (scratch_error == ERROR_SUCCESS) scratch_error = ERROR_WRITE_FAULT;
        }
        CloseHandle(file);
    }
    read_error = open_error(argv[2], GENERIC_READ);
    write_error = open_error(argv[2], GENERIC_WRITE);
    dacl_error = open_error(argv[2], WRITE_DAC);
    process = OpenProcess(PROCESS_VM_WRITE | PROCESS_VM_OPERATION | PROCESS_CREATE_THREAD | PROCESS_DUP_HANDLE,
                          FALSE, (DWORD)parent);
    process_error = process ? ERROR_SUCCESS : GetLastError();
    if (process) CloseHandle(process);
    network_error = observe_loopback_error((unsigned short)port);
    printf("{\"scratch_error\":%lu,\"read_error\":%lu,\"write_error\":%lu,"
           "\"dacl_error\":%lu,\"controller_error\":%lu,\"network_error\":%d}\n",
           scratch_error, read_error, write_error, dacl_error, process_error, network_error);
    return scratch_error == ERROR_SUCCESS && read_error == ERROR_ACCESS_DENIED &&
           write_error == ERROR_ACCESS_DENIED && dacl_error == ERROR_ACCESS_DENIED &&
           process_error == ERROR_ACCESS_DENIED && network_error == WSAEACCES ? 0 : 73;
}
