# H1 remaining acceptance

- Network qualification is open. Two actual effects retain FAIL; the supported
  calling-token diagnostic and same-listener control effect is unrun. Timeout
  or lack of an immediately observed connection never qualifies alone.
- Actual native AppContainer descendants, supervisor death and substituted
  junction denial cells remain open. The ten legacy Job tests prove containment
  under their original context and cannot substitute for those cells.
- The probe uses a pinned native executable. A private pinned Python/Git/Codex
  image, owned worker clone, controlled model channel and protected credentials
  still require implementation and actual qualification.
- One profile and both sets of probe objects remain deliberately retained with
  exact receipts. No automatic replay, existing-profile adoption or deletion is
  authorized by a failed result. The diagnostic continuation separately pins
  the proved created profile identity and reserves new effects.
- The local source/effect tests do not qualify a broker credential/store host,
  actual target principal/server contract or operational autonomous activation.
