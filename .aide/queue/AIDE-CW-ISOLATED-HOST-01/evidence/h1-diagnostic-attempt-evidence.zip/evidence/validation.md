# H1 current validation

Overall host qualification remains PENDING. The first actual native run and
its network continuation both retain FAIL: first a pending connect code, then
a bounded timeout. Both observed the exact zero-capability AppContainer token,
owned Job, successful scratch write and Win32 access-denied results for the
protected file and controller process. Neither network outcome alone qualifies.

- [First exact packet](h1-first-attempt-custody.json): 53 members, including original
  source, native binary, independent reviews, effect manifest and actual receipts.
- [Second exact packet](h1-network-attempt-custody.json): 40 members; original
  profile proof stayed unchanged, no additional profile was created.
- [Current source](h1-diagnostic-source-manifest.json): eight paths; aggregate
  7d7a8acf8e343504a421eaff5a3dcdd2a3c6ea9907b9fe1d3834674e518b1897.
- [Source/Job tests](h1-diagnostic-final-tests.json): 23 source/control and 10
  actual legacy containment tests pass.
- [Native fixture tests](h1-diagnostic-source-tests.json): two actual ordinary
  connection/diagnostic fixtures pass; these are not an isolated-token proof.
- [Read-only current config](h1-diagnostic-source-config-observation.json): the
  exact package has no loopback exemption.
- [Proposed exact diagnostic effect](h1-owned-diagnostic-review-request.json):
  requires independent review before execution; no profile-creation call, a
  new one-shot intent/root and same-listener ordinary controls before/after.

Current task inspect and repository validate pass. A first task-inspect
positional-argument invocation was rejected and retained; the corrected
--task-id invocation passed. Source-only/helper proofs remain distinct from
actual native effect qualification and complete operational host acceptance.
