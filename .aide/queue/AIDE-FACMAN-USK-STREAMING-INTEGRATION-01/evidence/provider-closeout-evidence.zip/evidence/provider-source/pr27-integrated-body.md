Adds local-directory source-to-target streaming with stable source identity, incremental SHA-256/CRC32, a fixed 65,536-byte payload buffer, and transactional no-replace commit. The public C ABI remains 1.0.

Streamed cancellation or failure before target visibility retains staging for recovery. The transaction persists `retain_only` before stream effects and serializes a null staging identity, so live rollback, resumed rollback, and older readers cannot regain authority to delete a substituted object. Identical content hashes do not establish ownership. Successful commit and visible-target finalization remain supported. Apply rejects excessive entry counts before creating transaction state.

Integrated normally into `dev` as [`8a16fbd0c84ccb697830d464c6531b58568816d2`](https://github.com/Julesc013/universal-setup/commit/8a16fbd0c84ccb697830d464c6531b58568816d2) after all 12 fresh [GitHub Checks](https://github.com/Julesc013/universal-setup/pull/27/checks) passed on reviewed candidate `efe1a1a33869f26d5403923300b9a6dba0c4b1f5`. Hygiene promotion PR30 and ancestry sync PR31 completed first. The synchronized candidate and integration commit preserve the independently reviewed source tree `6b608b04f3c447ccfd13b738237d7f04757e6d7a`.

Validation:

- 51 Python tests and strict repository checks passed before the corrective commit; all seven corrected file hashes match the approved receipt.
- A clean Windows x64 Release build passed five native suites: streaming, transactions, interruption recovery, lifecycle, and public lifecycle.
- The refreshed candidate passed both hosted CI runs across Linux, macOS, Windows x64, Windows Win32, sanitizer, and fuzz.
- Independent review found no remaining P0/P1/P2 issue in correction SHA-256 `05f1a30f31dac99fcc337f980b85d18c9b5de534d020aa685a2a254d9174b42d`. Regressions cover identical-byte replacement with the original outside staging, destruction/reopen, directory replacement, invalid or erased policy markers, entry-budget refusal, and successful visible-target finalization.

Retained staging cleanup, object-bound restart leases, and interrupted-entry resume remain separate work. GitHub automatically retargeted PR28 to `dev` after this merge; its original head remains unchanged and must consume the correction and update its streamed-failure expectations before fresh qualification. Canonical provider promotion, consumer adoption, and final Beta qualification remain separate gates. Exact source, check, review, promotion, synchronization, and merge receipts are retained for AIDE coordinator `AIDE-FACMAN-USK-STREAMING-INTEGRATION-01`.

Work-Item: USK-STREAMING-SOURCE-TARGET-01
