Synchronize canonical `main@2f213e202dea18dfee024c5c60b761f6afe305e7` back into `dev` after [PR32](https://github.com/Julesc013/universal-setup/pull/32) promoted the reviewed streaming source/target correction.

This preserves normal merge ancestry with zero file changes. Both sides have tree `6b608b04f3c447ccfd13b738237d7f04757e6d7a`. PR32 completed all twelve hosted checks; this synchronization requires its own fresh complete suite before a normal exact-head merge. PR28 remains separate and unmerged.

Work-Item: USK-STREAMING-SOURCE-TARGET-01
Evidence-Ref: AIDE-FACMAN-USK-STREAMING-INTEGRATION-01; external usk-s27/evidence/pr32-premerge-checked.json and pr32-merge-receipt.json
