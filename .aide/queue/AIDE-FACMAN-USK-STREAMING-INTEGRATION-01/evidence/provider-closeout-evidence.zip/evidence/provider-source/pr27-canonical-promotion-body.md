Promote the reviewed PR27 streaming source/target implementation to canonical `main`. Streamed staging persists a retain-only recovery policy before filesystem effects; live and reopened rollback preserve uncertain objects, and entry-count budgets fail before transaction effects.

The exact source is `dev@8a16fbd0c84ccb697830d464c6531b58568816d2`, tree `6b608b04f3c447ccfd13b738237d7f04757e6d7a`. The independently reviewed retention correction and PR27's twelve successful hosted checks are recorded in [PR27](https://github.com/Julesc013/universal-setup/pull/27/checks). This promotion requires its own fresh complete checks before a normal exact-head merge. Canonical promotion does not change any consumer pin.

Interrupted-entry resume, generation/lease ownership and automatic retained-staging cleanup remain separate work. Stored/Deflate/ZIP64 source changes stay in PR28.

Work-Item: USK-STREAMING-SOURCE-TARGET-01
Evidence-Ref: AIDE-FACMAN-USK-STREAMING-INTEGRATION-01; external usk-s27/evidence/pr27-canonical-promotion-plan.md and usk-streaming-integration-chain.json
