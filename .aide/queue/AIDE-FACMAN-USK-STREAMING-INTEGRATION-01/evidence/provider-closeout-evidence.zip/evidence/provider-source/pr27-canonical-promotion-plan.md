# PR27 exact canonical promotion plan

Current explicit user authorization covers implementation, validation, synchronization, commits and normal checked merges. Root dispatch authorizes this exact PR27 promotion and ancestry synchronization; no additional permission is needed. This session authorization governs the normal checked merge despite the older repository default self-merge restriction. No self-approval, force push, direct protected write, settings change or protection bypass is authorized.

Verified remote source dev: 8a16fbd0c84ccb697830d464c6531b58568816d2, tree 6b608b04f3c447ccfd13b738237d7f04757e6d7a. Verified current main: 22f5f210ceebd398892391513d77062364e25817. Main is an ancestor of dev, with the reviewed PR27 bounded streaming source/target and retain-only correction in the twelve-file promotion delta. PR28 is the only existing open pull request and is explicitly excluded.

1. Open dev to main promotion using the exact observed source/base and a body file. Preserve the reviewed source tree.
2. Require all twelve current hosted checks, including the fresh pull-request suite and exact-head push suite, to succeed. Recheck head, base, tree, mergeability and checks immediately before a normal merge commit with exact-head protection. Any source drift or failing check requires investigation; do not bypass.
3. Record merge and post-merge source tree. Open main to dev ancestry synchronization from the exact resulting main SHA, requiring zero file changes and the same reviewed source tree.
4. Require all twelve fresh/current checks and normal exact-head merge. Record the final canonical and integration heads, their trees and ancestry.

The AIDE helper was invoked through its pure report functions, with results stored externally. Its local apply plan correctly blocks the intentionally staged PR28 merge (dirty_tree_requires_classification / dirty_tree_blocks_promote); its imported-pack policy is absent from USK (required_policy_files_missing). Those findings apply to local branch mutation: none will be executed. USK's native release/index/branch_policy.v1.toml is authoritative here and branch-policy-check passes. Remote exact-head pull requests implement the authorized promotion while the primary remains frozen on PR28. Hygiene records the existing two owned evidence worktrees; no worktree creation or cleanup is planned.

Do not fetch, switch, commit, stage, update the PR28 branch, or otherwise mutate local source/refs during independent PR28 review. Do not write AIDE. Store all intermediate and final receipts under the existing owned usk-s27/evidence root. After this remote chain completes, root decides PR28 approval and subsequent normal source reconciliation.
