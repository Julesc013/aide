# Latest Golden Tasks

- result: PASS
- task_count: 171
- pass_count: 171
- warn_count: 0
- fail_count: 0
- provider_or_model_calls: none
- network_calls: none
- raw_prompt_storage: false
- raw_response_storage: false
- token_quality_statement: Token reduction remains valid only if golden tasks pass.

## Tasks

### adapter-managed-section-determinism

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: AGENTS.md
- notes: Checks managed section replacement on an isolated fixture repo.

### aide_branch_plan_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/aide-dev-main-plan.json, .aide/git/aide-dev-main-plan.md
- notes: Checks generated AIDE dev/main branch plan shape and no-mutation boundary.

### aide_dev_main_policy_golden

- result: PASS
- checks_run: 30
- passed_checks: 30
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/aide-branch-policy.yaml, .aide/git/aide-dev-main-plan.json
- notes: Checks AIDE main/dev branch policy and promotion gates.

### branch_role_detection_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/branch-roles.md, .aide/git/workflow-detection.json, .aide/policies/branch-roles.yaml
- notes: Checks deterministic branch-role classification and conservative unknown handling.

### capability_command_surface_golden

- result: PASS
- checks_run: 10
- passed_checks: 10
- approx_tokens_if_applicable: n/a
- related_paths: .aide/scripts/aide_lite.py
- notes: Checks X-OS-02 report-only capability command registration.

### capability_export_pack_inclusion_golden

- result: PASS
- checks_run: 18
- passed_checks: 18
- approx_tokens_if_applicable: n/a
- related_paths: .aide/capabilities/capability-observation.schema.json, .aide/capabilities/capability-overclaim.schema.json, .aide/capabilities/capability-seeds.yaml, .aide/examples/task-os/capability-ledger.example.json, .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/ledgers/capability-ledger.schema.json, docs/reference/capability-reality-ledger.md
- notes: Checks capability contracts are included in portable source export scope.

### capability_ledger_generation_golden

- result: PASS
- checks_run: 23
- passed_checks: 23
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/capability-ledger.json, .aide/reports/capability-ledger.md, .aide/reports/capability-observations.json, .aide/reports/capability-observations.md
- notes: Checks capability scan and ledger reports generate with conservative state coverage.

### capability_no_apply_boundary_golden

- result: PASS
- checks_run: 21
- passed_checks: 21
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/capability-command-status.md, .aide/reports/capability-ledger.json, .aide/reports/capability-ledger.md, .aide/reports/capability-observations.json, .aide/reports/capability-observations.md, .aide/reports/capability-overclaims.json, .aide/reports/capability-overclaims.md, .aide/reports/capability-validation.md
- notes: Checks all X-OS-02 capability outputs remain no-apply and no-call.

### capability_overclaim_report_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/capability-overclaims.json, .aide/reports/capability-overclaims.md
- notes: Checks capability overclaim reporting is typed and report-only.

### capability_seed_presence_golden

- result: PASS
- checks_run: 90
- passed_checks: 90
- approx_tokens_if_applicable: n/a
- related_paths: .aide/capabilities/capability-observation.schema.json, .aide/capabilities/capability-overclaim.schema.json, .aide/capabilities/capability-seeds.yaml, .aide/examples/task-os/capability-ledger.example.json, .aide/ledgers/capability-ledger.schema.json, docs/reference/capability-reality-ledger.md
- notes: Checks X-OS-02 capability seeds, schemas, and state vocabulary.

### changelog_json_shape_golden

- result: PASS
- checks_run: 20
- passed_checks: 20
- approx_tokens_if_applicable: n/a
- related_paths: .aide/changelog/changelog.preview.json, .aide/changelog/release-notes.preview.json
- notes: Checks changelog and release-note preview JSON shape.

### changelog_preview_golden

- result: PASS
- checks_run: 9
- passed_checks: 9
- approx_tokens_if_applicable: n/a
- related_paths: .aide/changelog/CHANGELOG.preview.md, .aide/changelog/RELEASE_NOTES.preview.md, .aide/changelog/config.yaml, .aide/changelog/templates/changelog.md.template, .aide/changelog/templates/release-notes.md.template, .aide/policies/changelog.yaml, .aide/policies/commit-messages.yaml
- notes: Checks deterministic changelog preview grouping and malformed commit reporting.

### commit_message_standard_golden

- result: PASS
- checks_run: 14
- passed_checks: 14
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/commit-template.md, .aide/hooks/commit-msg, .aide/policies/commit-messages.yaml, .aide/reports/aide-commit-message-standard.md
- notes: Checks changelog-ready commit message validation anchors.

### compact-task-packet-required-sections

- result: PASS
- checks_run: 17
- passed_checks: 17
- approx_tokens_if_applicable: 1075
- related_paths: .aide/context/latest-task-packet.md, .aide/policies/token-budget.yaml, .aide/prompts/compact-task.md
- notes: Checks the compact task packet shape and forbidden prompt discipline.

### context-packet-no-full-repo-dump

- result: PASS
- checks_run: 17
- passed_checks: 17
- approx_tokens_if_applicable: 486
- related_paths: .aide/context/context-index.json, .aide/context/latest-context-packet.md, .aide/context/repo-map.json, .aide/context/test-map.json
- notes: Checks context refs instead of whole-repo dumps.

### docs_consistency_report_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/docs-consistency.yaml, .aide/reports/docs-consistency-report.md
- notes: Checks docs consistency warning surfaces.

### drop_candidate_not_delete_approval_golden

- result: PASS
- checks_run: 7
- passed_checks: 7
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/salvage-map.yaml, .aide/refactors/current-move-map.json, .aide/refactors/current-salvage-map.json
- notes: Checks Q42 fates never become deletion approval.

### export_pack_commit_policy_inclusion_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/git/commit-template.md, .aide/hooks/commit-msg, .aide/policies/commit-messages.yaml
- notes: Checks portable commit discipline and changelog support are exported or locally available after import.

### export_pack_excludes_source_branch_state_golden

- result: PASS
- checks_run: 310
- passed_checks: 310
- approx_tokens_if_applicable: n/a
- related_paths: .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/policies/export-import.yaml
- notes: Checks source-specific Git detection, helper plans, branch policy, and generated previews are not exported as target truth.

### export_pack_git_policy_inclusion_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/git/helper-policy.yaml, .aide/policies/branch-roles.yaml, .aide/policies/git-workflow.yaml
- notes: Checks portable Git workflow and helper governance are exported or locally available after import.

### export_pack_task_recovery_inclusion_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/policies/recovery.yaml, .aide/policies/task-resumption.yaml, .aide/policies/work-units.yaml
- notes: Checks portable task resumption, WorkUnit, and recovery governance are exported or locally available after import.

### file_classification_policy_golden

- result: PASS
- checks_run: 10
- passed_checks: 10
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/file-classification.yaml, .aide/scripts/aide_lite.py, README.md
- notes: Checks deterministic classification anchors and known AIDE file classes.

### file_quality_ledger_schema_golden

- result: PASS
- checks_run: 33
- passed_checks: 33
- approx_tokens_if_applicable: n/a
- related_paths: .aide/quality/file-quality-ledger.schema.json, .aide/quality/file-quality-record.schema.json, .aide/reports/file-quality-ledger.schema.json
- notes: Checks file quality ledger schema and latest/generated ledger shape.

### file_quality_policy_golden

- result: PASS
- checks_run: 48
- passed_checks: 48
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/docs-consistency.yaml, .aide/policies/file-quality.yaml, .aide/policies/module-quality.yaml, .aide/policies/reuse-modularity.yaml
- notes: Checks Q38 file-quality policy anchors and no-call advisory posture.

### fixture_import_governance_commands_golden

- result: PASS
- checks_run: 9
- passed_checks: 9
- approx_tokens_if_applicable: n/a
- related_paths: .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/hooks/commit-msg, .aide/scripts/aide_lite.py
- notes: Checks safe fixture import receives governance files and can run portable commit/task/Git commands.

### full_discovery_handoff_no_run_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/full-discovery-handoff.yaml, .aide/tests/full-discovery-handoff.schema.json
- notes: Checks full-discovery handoff is report-only/no-run.

### git_helper_policy_golden

- result: PASS
- checks_run: 26
- passed_checks: 26
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/helper-commands.md, .aide/git/helper-policy.yaml, .aide/git/latest-helper-plan.json, .aide/git/latest-helper-plan.md
- notes: Checks Q29 helper policy anchors and generated helper-plan artifacts.

### git_land_plan_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/helper-commands.md, .aide/git/latest-helper-plan.json
- notes: Checks land dry-run planning and no remote mutation anchors.

### git_live_repo_no_mutation_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/helper-commands.md, .aide/git/helper-policy.yaml, .aide/git/latest-helper-plan.json
- notes: Checks live-repo helper plans remain no-mutation by default.

### git_promote_plan_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/helper-commands.md, .aide/git/helper-policy.yaml, .aide/policies/promotion-rules.yaml
- notes: Checks promotion helper review gates and dry-run command documentation.

### git_prune_guard_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/helper-commands.md, .aide/git/helper-policy.yaml, .aide/policies/prune-policy.yaml
- notes: Checks prune containment and protected-role guards.

### git_workflow_policy_golden

- result: PASS
- checks_run: 16
- passed_checks: 16
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/project-profiles.yaml, .aide/policies/branch-roles.yaml, .aide/policies/git-workflow.yaml, .aide/policies/promotion-rules.yaml, .aide/policies/prune-policy.yaml, .aide/policies/sync-policy.yaml
- notes: Checks Q28 Git workflow policy anchors and project profiles.

### github_ci_advisory_golden

- result: PASS
- checks_run: 12
- passed_checks: 12
- approx_tokens_if_applicable: n/a
- related_paths: .aide/github/ci-advisory.json, .aide/github/ci-advisory.md, .aide/policies/ci-gates.yaml
- notes: Checks Q35 CI gate advisory without workflow installation.

### github_export_inclusion_golden

- result: PASS
- checks_run: 21
- passed_checks: 21
- approx_tokens_if_applicable: n/a
- related_paths: .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/policies/branch-protection.yaml, .aide/policies/ci-gates.yaml, .aide/policies/export-import.yaml, .aide/policies/github-protection.yaml
- notes: Checks Q35 portable policy export and generated advisory exclusion.

### github_protection_policy_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/github/branch-protection-plan.json, .aide/policies/branch-protection.yaml, .aide/policies/github-protection.yaml
- notes: Checks Q35 GitHub branch-protection advisory remains report-only.

### github_release_asset_schema_golden

- result: PASS
- checks_run: 13
- passed_checks: 13
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/github-release-asset.schema.json
- notes: Checks GitHub release asset schema shape.

### github_release_assets_have_checksums_golden

- result: PASS
- checks_run: 26
- passed_checks: 26
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/dist/SHA256SUMS.txt, .aide/release/dist/aide-lite-pack-v0.checksums.json, .aide/release/github-release-assets.json
- notes: Checks release draft asset list includes checksums and validates hashes.

### github_release_checklist_golden

- result: PASS
- checks_run: 6
- passed_checks: 6
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/release-checklist.yaml, .aide/release/github-release-checklist.json, .aide/release/github-release-checklist.schema.json
- notes: Checks GitHub release checklist policy and manual review coverage.

### github_release_draft_policy_golden

- result: PASS
- checks_run: 10
- passed_checks: 10
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/github-release-draft.yaml, .aide/policies/release-publication-boundary.yaml
- notes: Checks Q48 release draft policy anchors and publication boundary.

### github_release_draft_schema_golden

- result: PASS
- checks_run: 11
- passed_checks: 11
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/github-release-draft.schema.json
- notes: Checks GitHub release draft schema shape.

### github_release_no_publish_golden

- result: PASS
- checks_run: 10
- passed_checks: 10
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/github-release-draft.json, .aide/release/github-release-publication-boundary.md, .aide/release/github-release-upload-plan.json
- notes: Checks Q48 generated outputs stay local-only and unpublished.

### github_release_upload_plan_golden

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/github-release-upload-plan.json, .aide/release/github-release-upload-plan.schema.json
- notes: Checks GitHub release upload plan schema and no-upload posture.

### github_report_only_golden

- result: PASS
- checks_run: 11
- passed_checks: 11
- approx_tokens_if_applicable: n/a
- related_paths: .aide/github/github-advisory.json, .aide/github/github-advisory.md, .aide/github/latest-github-status.md
- notes: Checks Q35 report-only behavior and no live GitHub/CI mutation.

### impacted_test_plan_report_only_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/impacted-tests.yaml, .aide/tests/test-impact-map.schema.json, .aide/tests/test-plan.schema.json
- notes: Checks impacted-test planning remains report-only.

### install_conflict_report_schema_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/conflict-record.schema.json, .aide/install/conflict-report.schema.json, .aide/install/latest-conflict-report.json
- notes: Checks install conflict report schema and no-apply conflict output.

### install_no_apply_golden

- result: PASS
- checks_run: 6684
- passed_checks: 6684
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/latest-install-dry-run.json, .aide/install/latest-install-plan.json
- notes: Checks Q43 install data never enables apply, overwrite, or automatic migration.

### install_no_source_state_leak_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/latest-install-plan.json, .aide/policies/install-preservation.yaml
- notes: Checks source-generated, local, and secret-like state is never planned as target install truth.

### install_ownership_ledger_schema_golden

- result: PASS
- checks_run: 14
- passed_checks: 14
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/latest-ownership-ledger.example.json, .aide/install/ownership-ledger.schema.json, .aide/install/ownership-record.schema.json
- notes: Checks ownership ledger schema and example no-apply ledger shape.

### install_plan_schema_golden

- result: PASS
- checks_run: 11592
- passed_checks: 11592
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/install-operation.schema.json, .aide/install/install-plan.schema.json, .aide/install/latest-install-plan.json
- notes: Checks install plan schema and generated no-apply plan shape.

### install_policy_golden

- result: PASS
- checks_run: 66
- passed_checks: 66
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/install-plan.schema.json, .aide/policies/install.yaml
- notes: Checks Q43 install policy anchors and no-apply install posture.

### install_preservation_policy_golden

- result: PASS
- checks_run: 67
- passed_checks: 67
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/preservation-report.schema.json, .aide/policies/install-preservation.yaml
- notes: Checks preservation rules for target memory, queue, evidence, local state, and manual content.

### install_preserves_target_state_golden

- result: PASS
- checks_run: 7
- passed_checks: 7
- approx_tokens_if_applicable: n/a
- related_paths: .aide/install/latest-install-plan.json, .aide/install/latest-preservation-report.md, .aide/policies/install-preservation.yaml
- notes: Checks Q43 preserves target-specific state instead of treating it as install truth.

### intent_compile_destructive_prompt_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/prompt-normalization.yaml, .aide/policies/risk-classes.yaml
- notes: Checks destructive raw prompts cannot execute directly.

### intent_compile_git_prompt_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/git-workflow.yaml, .aide/policies/intent.yaml, .aide/policies/promotion-rules.yaml
- notes: Checks Git promotion prompts require branch policy and review evidence.

### intent_compile_install_prompt_golden

- result: PASS
- checks_run: 6
- passed_checks: 6
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/export-import.yaml, .aide/policies/intent.yaml, .aide/policies/prompt-normalization.yaml
- notes: Checks target install prompts become preflight/preservation WorkUnits.

### intent_compile_overbroad_prompt_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/prompt-normalization.yaml, .aide/policies/workunit-sizing.yaml
- notes: Checks overbroad prompts become split recommendations.

### intent_compile_vague_prompt_golden

- result: PASS
- checks_run: 6
- passed_checks: 6
- approx_tokens_if_applicable: n/a
- related_paths: .aide/intake/intent-examples.yaml, .aide/policies/intent.yaml
- notes: Checks that vague prompts do not trigger product work.

### intent_packet_schema_golden

- result: PASS
- checks_run: 85
- passed_checks: 85
- approx_tokens_if_applicable: n/a
- related_paths: .aide/intake/intent-packet.schema.json, .aide/intake/workunit-draft.schema.json
- notes: Checks intent packet and WorkUnit draft shape plus raw prompt storage boundaries.

### malformed_commit_reporting_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/changelog/malformed-commits.md
- notes: Checks malformed and legacy commit reporting without history rewrite.

### managed_section_conflict_detection_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/examples/apply/managed-section-fixtures/duplicate_marker.md, .aide/examples/apply/managed-section-fixtures/expected_output.md, .aide/examples/apply/managed-section-fixtures/missing_marker.md, .aide/examples/apply/managed-section-fixtures/replacement.md, .aide/examples/apply/managed-section-fixtures/valid_input.md
- notes: Checks managed-section conflict detection blocks missing, duplicate, nested, and malformed markers.

### managed_section_export_pack_inclusion_golden

- result: PASS
- checks_run: 63
- passed_checks: 63
- approx_tokens_if_applicable: n/a
- related_paths: .aide/apply/managed-section-conflict.schema.json, .aide/apply/managed-section-operation.schema.json, .aide/apply/managed-section-patch.schema.json, .aide/apply/managed-section-report.schema.json, .aide/examples/apply/managed-section-fixtures/duplicate_marker.md, .aide/examples/apply/managed-section-fixtures/expected_output.md, .aide/examples/apply/managed-section-fixtures/missing_marker.md, .aide/examples/apply/managed-section-fixtures/replacement.md, .aide/examples/apply/managed-section-fixtures/valid_input.md, .aide/examples/apply/managed-section-patch.example.json, .aide/examples/apply/managed-section-report.example.json, .aide/examples/apply/managed-section.duplicate-marker-conflict.example.json, .aide/examples/apply/managed-section.missing-marker-conflict.example.json, .aide/examples/apply/managed-section.valid.example.json, .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/policies/managed-section-markers.yaml, .aide/policies/managed-sections.yaml, core/apply/README.md, core/apply/__init__.py, core/apply/managed_sections.py, docs/reference/managed-section-operations.md, docs/reference/managed-section-patcher.md
- notes: Checks managed-section contracts are included in portable export-pack source scope.

### managed_section_fixture_patch_golden

- result: PASS
- checks_run: 7
- passed_checks: 7
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/managed-section-conflict-report.md, .aide/reports/managed-section-fixture-plan.json, .aide/reports/managed-section-fixture-plan.md
- notes: Checks fixture-only managed-section planning emits deterministic no-apply reports.

### managed_section_manual_content_preservation_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/examples/apply/managed-section-fixtures/duplicate_marker.md, .aide/examples/apply/managed-section-fixtures/expected_output.md, .aide/examples/apply/managed-section-fixtures/missing_marker.md, .aide/examples/apply/managed-section-fixtures/replacement.md, .aide/examples/apply/managed-section-fixtures/valid_input.md
- notes: Checks managed-section patching preserves manual text outside markers.

### managed_section_marker_policy_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/managed-section-markers.yaml, .aide/policies/managed-sections.yaml
- notes: Checks marker policy blocks ambiguous markers and preserves manual content.

### managed_section_no_real_apply_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/managed-section-conflict-report.md, .aide/reports/managed-section-fixture-plan.json, .aide/reports/managed-section-fixture-plan.md, .aide/reports/managed-section-fixture-validation.md, .aide/reports/managed-section-next-plan.md, .aide/reports/managed-section-status.md
- notes: Checks managed-section commands and reports do not enable real apply behavior.

### managed_section_schema_presence_golden

- result: PASS
- checks_run: 17
- passed_checks: 17
- approx_tokens_if_applicable: n/a
- related_paths: .aide/apply/managed-section-conflict.schema.json, .aide/apply/managed-section-operation.schema.json, .aide/apply/managed-section-patch.schema.json, .aide/apply/managed-section-report.schema.json, .aide/examples/apply/managed-section-patch.example.json, .aide/examples/apply/managed-section-report.example.json, .aide/examples/apply/managed-section.duplicate-marker-conflict.example.json, .aide/examples/apply/managed-section.missing-marker-conflict.example.json, .aide/examples/apply/managed-section.valid.example.json
- notes: Checks managed-section schemas and examples exist and parse.

### migration_ledger_policy_golden

- result: PASS
- checks_run: 106
- passed_checks: 106
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/migration-ledger.yaml, .aide/refactors/migration-ledger-entry.schema.json, .aide/refactors/migration-ledger.schema.json
- notes: Checks Q42 migration ledger policy and draft event shape.

### migration_ledger_schema_golden

- result: PASS
- checks_run: 13
- passed_checks: 13
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/migration-ledger.schema.json
- notes: Checks migration-ledger schema and example dry-run event support.

### migration_policy_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/migration.yaml
- notes: Checks Q39 migration stages and no mandatory migration boundary.

### move_map_policy_golden

- result: PASS
- checks_run: 79
- passed_checks: 79
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/move-map.yaml, .aide/refactors/move-map-entry.schema.json, .aide/refactors/move-map.schema.json
- notes: Checks Q42 move-map policy anchors and candidate-only map shape.

### move_map_schema_golden

- result: PASS
- checks_run: 11
- passed_checks: 11
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/move-map.schema.json
- notes: Checks move-map schema exists and remains no-apply.

### no_skip_to_pass_golden

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/test-summary-reduction.yaml, .aide/policies/test-tiers.yaml
- notes: Checks policies forbid deleting or skipping tests to fake speed.

### path_alias_policy_golden

- result: PASS
- checks_run: 79
- passed_checks: 79
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/path-aliases.yaml, .aide/refactors/path-alias-entry.schema.json, .aide/refactors/path-aliases.schema.json, .aide/refactors/path-aliases.template.yaml
- notes: Checks Q42 path-alias policy anchors and no-apply alias shape.

### path_alias_schema_golden

- result: PASS
- checks_run: 12
- passed_checks: 12
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/path-aliases.schema.json
- notes: Checks path-alias schema exists and remains no-apply.

### promotion_gate_t3_golden

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/validation-promotion-gates.yaml
- notes: Checks promotion gates keep T3 distinct from normal post-task validation.

### promotion_rules_golden

- result: PASS
- checks_run: 6
- passed_checks: 6
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/promotion-rules.md, .aide/policies/promotion-rules.yaml
- notes: Checks task-to-dev and dev-to-main gate anchors.

### prune_policy_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/prune-policy.md, .aide/policies/prune-policy.yaml
- notes: Checks prune guards require containment and remain dry-run/report-only.

### quality_ledger_generation_golden

- result: PASS
- checks_run: 28
- passed_checks: 28
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repo/file-inventory.json, .aide/reports/file-quality-ledger.json
- notes: Checks deterministic quality ledger generation from Q37 outputs.

### quality_no_delete_recommendation_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/file-quality.yaml, .aide/reports/file-quality-ledger.json
- notes: Checks Q38 warning outputs never become deletion advice.

### refactor_map_no_apply_golden

- result: PASS
- checks_run: 991
- passed_checks: 991
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/current-move-map.json, .aide/refactors/current-salvage-map.json, .aide/refactors/map-validation-report.json, .aide/refactors/path-aliases.yaml, .aide/refactors/reference-rewrite-plan.json
- notes: Checks Q42 map outputs and generated bundle remain no-apply/no-mutation.

### refactor_no_apply_golden

- result: PASS
- checks_run: 52
- passed_checks: 52
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/refactor-application.yaml, .aide/refactors/latest-refactor-plan.example.json, .aide/refactors/latest-refactor-readiness.json
- notes: Checks Q39 has no apply, move, delete, rewrite, or deletion-approval behavior.

### refactor_plan_schema_golden

- result: PASS
- checks_run: 54
- passed_checks: 54
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/latest-refactor-plan.example.json, .aide/refactors/refactor-operation.schema.json, .aide/refactors/refactor-plan.schema.json
- notes: Checks refactor plan schema and no-apply example plan shape.

### refactor_policy_golden

- result: PASS
- checks_run: 54
- passed_checks: 54
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/refactor-application.yaml, .aide/policies/refactor-safety.yaml, .aide/policies/refactor.yaml
- notes: Checks Q39 refactor policy anchors and dry-run only posture.

### reference_rewrite_plan_golden

- result: PASS
- checks_run: 513
- passed_checks: 513
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/reference-rewrite.yaml, .aide/refactors/reference-rewrite-entry.schema.json, .aide/refactors/reference-rewrite-plan.schema.json
- notes: Checks Q42 reference rewrite planning remains candidate-only.

### release_archive_generation_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/dist/aide-lite-pack-v0.tar.gz, .aide/release/dist/aide-lite-pack-v0.zip, .aide/release/dist/install.md, .aide/release/dist/manifest.yaml
- notes: Checks local archive generation outputs exist and validate.

### release_asset_schema_golden

- result: PASS
- checks_run: 13
- passed_checks: 13
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/release-asset.schema.json
- notes: Checks release asset schema shape.

### release_bundle_policy_golden

- result: PASS
- checks_run: 54
- passed_checks: 54
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/release-artifacts.yaml, .aide/policies/release-bundle.yaml, .aide/policies/release-validation.yaml
- notes: Checks Q47 release policy anchors and local-only no-publish posture.

### release_checksum_validation_golden

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/dist/SHA256SUMS.txt, .aide/release/dist/aide-lite-pack-v0.checksums.json
- notes: Checks release checksum JSON and SHA256SUMS validation.

### release_fixture_extraction_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/dist/aide-lite-pack-v0.tar.gz, .aide/release/dist/aide-lite-pack-v0.zip
- notes: Checks archive extraction fixture validation.

### release_forbidden_paths_excluded_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/export-import.yaml, .aide/policies/release-artifacts.yaml, .aide/release/dist/aide-lite-pack-v0.tar.gz, .aide/release/dist/aide-lite-pack-v0.zip
- notes: Checks release archives exclude forbidden paths and generated release outputs are not target truth.

### release_manifest_schema_golden

- result: PASS
- checks_run: 11
- passed_checks: 11
- approx_tokens_if_applicable: n/a
- related_paths: .aide/release/release-manifest.schema.json
- notes: Checks release manifest schema shape.

### release_no_publish_golden

- result: PASS
- checks_run: 9
- passed_checks: 9
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/release-bundle.yaml, .aide/release/latest-release-bundle.json, .aide/scripts/aide_lite.py
- notes: Checks Q47 remains local-only and non-publishing.

### release_notes_preview_golden

- result: PASS
- checks_run: 7
- passed_checks: 7
- approx_tokens_if_applicable: n/a
- related_paths: .aide/changelog/RELEASE_NOTES.preview.md, .aide/changelog/release-notes.preview.json
- notes: Checks release-note preview extraction and preview-only caveat.

### repair_blocks_local_state_and_secrets_golden

- result: PASS
- checks_run: 6
- passed_checks: 6
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/repair-classes.yaml, .aide/policies/repair-safety.yaml, .aide/repair/latest-repair-plan.json
- notes: Checks local state and secret-like repair findings are block/manual-review only.

### repair_classes_golden

- result: PASS
- checks_run: 62
- passed_checks: 62
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/repair-classes.yaml
- notes: Checks repair class vocabulary and safety gate metadata.

### repair_doctor_schema_golden

- result: PASS
- checks_run: 18
- passed_checks: 18
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repair/doctor-report.schema.json, .aide/repair/latest-doctor-repair-report.json
- notes: Checks doctor repair report schema and advisory-only report shape.

### repair_dry_run_schema_golden

- result: PASS
- checks_run: 19
- passed_checks: 19
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repair/latest-repair-dry-run.json, .aide/repair/repair-dry-run.schema.json
- notes: Checks repair dry-run schema and no-apply dry-run shape.

### repair_no_apply_golden

- result: PASS
- checks_run: 513
- passed_checks: 513
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repair/latest-repair-dry-run.json, .aide/repair/latest-repair-plan.json
- notes: Checks Q44 repair data never enables apply, overwrite, delete, or automatic migration.

### repair_plan_schema_golden

- result: PASS
- checks_run: 1546
- passed_checks: 1546
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repair/latest-repair-plan.json, .aide/repair/repair-operation.schema.json, .aide/repair/repair-plan.schema.json
- notes: Checks repair plan schema and generated no-apply plan shape.

### repair_policy_golden

- result: PASS
- checks_run: 62
- passed_checks: 62
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/repair.yaml, .aide/repair/repair-plan.schema.json
- notes: Checks Q44 repair policy anchors and preservation-first no-apply posture.

### repair_preserves_target_state_golden

- result: PASS
- checks_run: 89
- passed_checks: 89
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/repair-safety.yaml, .aide/repair/latest-repair-plan.json
- notes: Checks repair plans preserve target-specific state by default.

### repo_dependency_map_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/dependency-map.yaml, .aide/repo/dependency-map.json
- notes: Checks deterministic dependency map shape and Python import detection.

### repo_doc_link_map_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/doc-link-map.yaml, .aide/repo/doc-link-map.json
- notes: Checks doc link map shape and conservative stale-candidate language.

### repo_explain_file_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repo/file-inventory.json, .aide/scripts/aide_lite.py
- notes: Checks explain-file data for a stable AIDE Lite file.

### repo_intelligence_no_local_state_golden

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repo/file-inventory.json, .gitignore
- notes: Checks local state exclusion and local-path flagging.

### repo_inventory_schema_golden

- result: PASS
- checks_run: 21
- passed_checks: 21
- approx_tokens_if_applicable: n/a
- related_paths: .aide/repo/file-inventory.json, .aide/repo/file-inventory.schema.json
- notes: Checks Q37 inventory schema and required file inventory fields.

### repo_ownership_map_golden

- result: PASS
- checks_run: 5
- passed_checks: 5
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/ownership-map.yaml, .aide/repo/ownership-map.json
- notes: Checks deterministic owner map includes key AIDE surfaces.

### reuse_modularity_report_golden

- result: PASS
- checks_run: 6
- passed_checks: 6
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/reuse-modularity.yaml, .aide/reports/reuse-modularity-report.md
- notes: Checks reuse/modularity candidate-only reporting.

### review-packet-evidence-only

- result: PASS
- checks_run: 20
- passed_checks: 20
- approx_tokens_if_applicable: 2132
- related_paths: .aide/context/latest-review-packet.md, .aide/prompts/evidence-review.md, .aide/verification/review-packet.template.md
- notes: Checks review packet evidence-only shape.

### rollback_no_apply_golden

- result: PASS
- checks_run: 4428
- passed_checks: 4428
- approx_tokens_if_applicable: n/a
- related_paths: .aide/rollback/latest-rollback-dry-run.json, .aide/rollback/latest-rollback-plan.json
- notes: Checks rollback plans and dry-runs never enable apply, overwrite, delete, or managed-section removal.

### rollback_plan_schema_golden

- result: PASS
- checks_run: 4370
- passed_checks: 4370
- approx_tokens_if_applicable: n/a
- related_paths: .aide/rollback/latest-rollback-plan.json, .aide/rollback/rollback-operation.schema.json, .aide/rollback/rollback-plan.schema.json
- notes: Checks rollback plan schema and generated no-apply plan shape.

### rollback_policy_golden

- result: PASS
- checks_run: 40
- passed_checks: 40
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/rollback-safety.yaml, .aide/policies/rollback.yaml
- notes: Checks rollback policy anchors and no-apply preservation posture.

### root_exception_schema_golden

- result: PASS
- checks_run: 11
- passed_checks: 11
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/root-exception.schema.json, .aide/roots/root-exceptions.json
- notes: Checks root exception records include retirement conditions.

### root_fate_no_delete_approval_golden

- result: PASS
- checks_run: 7
- passed_checks: 7
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/root-fates.yaml, .aide/roots/latest-root-classification.json, .aide/roots/latest-root-recycling-plan.json
- notes: Checks root fate vocabulary never becomes deletion approval.

### root_file_classification_schema_golden

- result: PASS
- checks_run: 20
- passed_checks: 20
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/root-file-classification.schema.json, .aide/roots/latest-root-classification.json
- notes: Checks root file classification output shape and no-apply fates.

### root_inventory_schema_golden

- result: PASS
- checks_run: 18
- passed_checks: 18
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/root-inventory.schema.json, .aide/roots/latest-root-inventory.json
- notes: Checks root inventory schema and generated inventory shape.

### root_record_schema_golden

- result: PASS
- checks_run: 13
- passed_checks: 13
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/root-record.schema.json
- notes: Checks root record schema shape.

### root_recycling_plan_schema_golden

- result: PASS
- checks_run: 40
- passed_checks: 40
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/root-recycling-plan.schema.json, .aide/roots/latest-root-recycling-plan.json
- notes: Checks root recycling plan output shape and no-apply posture.

### root_recycling_policy_golden

- result: PASS
- checks_run: 48
- passed_checks: 48
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/root-fates.yaml, .aide/policies/root-inventory.yaml, .aide/policies/root-recycling.yaml, .aide/policies/root-risk.yaml
- notes: Checks Q40 root recycling policy anchors and no-apply posture.

### roots_no_apply_golden

- result: PASS
- checks_run: 40
- passed_checks: 40
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/root-recycling.yaml, .aide/roots/latest-root-classification.json, .aide/roots/latest-root-recycling-plan.json
- notes: Checks root inventory, classification, and plan outputs remain no-apply.

### salvage_map_policy_golden

- result: PASS
- checks_run: 317
- passed_checks: 317
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/salvage-map.yaml, .aide/refactors/salvage-map-entry.schema.json, .aide/refactors/salvage-map.schema.json
- notes: Checks Q42 salvage-map policy anchors and preservation candidate shape.

### salvage_map_schema_golden

- result: PASS
- checks_run: 11
- passed_checks: 11
- approx_tokens_if_applicable: n/a
- related_paths: .aide/refactors/salvage-map.schema.json
- notes: Checks salvage-map schema exists and remains no-apply.

### sync_policy_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/git/sync-policy.md, .aide/policies/sync-policy.yaml
- notes: Checks multi-machine sync policy anchors remain report-only.

### target_validator_preservation_golden

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/impacted-tests.yaml, .aide/policies/test-tiers.yaml
- notes: Checks target-specific validators are preserved by policy.

### task_os_blocker_classification_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/task-os-blocker-classification.json, .aide/reports/task-os-blocker-classification.md, .aide/reports/task-os-blocker-status.md
- notes: Checks blocker status/classification reports are typed and no-apply.

### task_os_blocker_policy_golden

- result: PASS
- checks_run: 24
- passed_checks: 24
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/blockers.yaml, .aide/policies/repair-loop.yaml
- notes: Checks blocker classes, repair mapping, retry limits, and unsafe rules.

### task_os_capability_reality_policy_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/capability-reality.yaml
- notes: Checks capability reality states and no-overclaim proof rules.

### task_os_command_surface_golden

- result: PASS
- checks_run: 18
- passed_checks: 18
- approx_tokens_if_applicable: n/a
- related_paths: .aide/scripts/aide_lite.py
- notes: Checks X-OS-01 report-only Task OS command registration.

### task_os_example_records_golden

- result: PASS
- checks_run: 32
- passed_checks: 32
- approx_tokens_if_applicable: n/a
- related_paths: .aide/examples/task-os/blocker.example.json, .aide/examples/task-os/branch-provenance.example.json, .aide/examples/task-os/capability-ledger.example.json, .aide/examples/task-os/checkpoint.example.json, .aide/examples/task-os/repair-task.example.json, .aide/examples/task-os/task-attempt.example.json, .aide/examples/task-os/wave.example.json, .aide/examples/task-os/workunit.example.json
- notes: Checks Task OS examples parse and stay clearly example-only.

### task_os_lifecycle_policy_golden

- result: PASS
- checks_run: 23
- passed_checks: 23
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/task-lifecycle.yaml
- notes: Checks Task OS lifecycle states and report-only transition boundaries.

### task_os_no_apply_boundary_golden

- result: PASS
- checks_run: 11
- passed_checks: 11
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/blockers.yaml, .aide/policies/capability-reality.yaml, .aide/policies/checkpoints.yaml, .aide/policies/dev-main-promotion.yaml, .aide/policies/repair-loop.yaml, .aide/policies/task-lifecycle.yaml, .aide/policies/waves.yaml, .aide/scripts/aide_lite.py, docs/reference/blocker-and-repair-model.md, docs/reference/checkpoint-and-promotion-model.md, docs/reference/task-os-v0.md, docs/reference/workunit-lifecycle.md
- notes: Checks X-OS-00 stays policy/schema validation only.

### task_os_repair_requeue_resume_plan_golden

- result: PASS
- checks_run: 21
- passed_checks: 21
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/task-os-repair-plan.md, .aide/reports/task-os-requeue-plan.md, .aide/reports/task-os-resume-plan.md
- notes: Checks repair, requeue, and resume plans do not execute or mutate state.

### task_os_report_only_no_apply_golden

- result: PASS
- checks_run: 28
- passed_checks: 28
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/task-os-blocker-classification.json, .aide/reports/task-os-blocker-classification.md, .aide/reports/task-os-blocker-status.md, .aide/reports/task-os-checkpoint-plan.md, .aide/reports/task-os-checkpoint-status.md, .aide/reports/task-os-command-status.md, .aide/reports/task-os-next-plan.md, .aide/reports/task-os-repair-plan.md, .aide/reports/task-os-requeue-plan.md, .aide/reports/task-os-resume-plan.md, .aide/reports/task-os-task-classification.json, .aide/reports/task-os-task-classification.md, .aide/reports/task-os-task-status.md, .aide/reports/task-os-wave-plan.md, .aide/reports/task-os-wave-status.md
- notes: Checks every X-OS-01 Task OS command report stays report-only.

### task_os_schema_presence_golden

- result: PASS
- checks_run: 41
- passed_checks: 41
- approx_tokens_if_applicable: n/a
- related_paths: .aide/examples/task-os/blocker.example.json, .aide/examples/task-os/branch-provenance.example.json, .aide/examples/task-os/capability-ledger.example.json, .aide/examples/task-os/checkpoint.example.json, .aide/examples/task-os/repair-task.example.json, .aide/examples/task-os/task-attempt.example.json, .aide/examples/task-os/wave.example.json, .aide/examples/task-os/workunit.example.json, .aide/ledgers/blocker-ledger.schema.json, .aide/ledgers/branch-provenance.schema.json, .aide/ledgers/capability-ledger.schema.json, .aide/ledgers/checkpoint-ledger.schema.json, .aide/ledgers/task-ledger.schema.json, .aide/tasks/blocker.schema.json, .aide/tasks/checkpoint.schema.json, .aide/tasks/repair-task.schema.json, .aide/tasks/task-attempt.schema.json, .aide/tasks/wave.schema.json, .aide/tasks/workunit.schema.json
- notes: Checks X-OS-00 Task OS schemas, ledgers, and examples exist and parse.

### task_os_task_status_report_golden

- result: PASS
- checks_run: 22
- passed_checks: 22
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/task-os-command-status.md, .aide/reports/task-os-task-classification.json, .aide/reports/task-os-task-classification.md, .aide/reports/task-os-task-status.md
- notes: Checks task status/classification reports are deterministic and no-apply.

### task_os_wave_checkpoint_plan_golden

- result: PASS
- checks_run: 28
- passed_checks: 28
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/task-os-checkpoint-plan.md, .aide/reports/task-os-checkpoint-status.md, .aide/reports/task-os-wave-plan.md, .aide/reports/task-os-wave-status.md
- notes: Checks wave and checkpoint reports plan without branch or apply behavior.

### task_resumption_standard_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/context/latest-task-packet.md, .aide/policies/task-resumption.yaml, .aide/queue/index.yaml, .aide/reports/aide-task-resumption-standard.md
- notes: Checks repeated and out-of-order task recovery policy anchors.

### test_coverage_map_golden

- result: PASS
- checks_run: 4
- passed_checks: 4
- approx_tokens_if_applicable: n/a
- related_paths: .aide/quality/test-coverage-map.schema.json, .aide/reports/test-coverage-map.md
- notes: Checks heuristic test coverage map shape.

### test_summary_schema_golden

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/tests/examples/test-summary.example.json, .aide/tests/examples/test-summary.invalid-raw-log.json, .aide/tests/test-summary.schema.json
- notes: Checks compact test summary validation accepts compact data and rejects raw logs.

### test_telemetry_export_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/export/aide-lite-pack-v0, .aide/policies/test-telemetry.yaml, .aide/tests/test-summary.schema.json
- notes: Checks validation tier and telemetry contracts are portable/exported.

### test_tier_policy_golden

- result: PASS
- checks_run: 63
- passed_checks: 63
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/test-tiers.yaml, .aide/policies/validation-promotion-gates.yaml, .aide/tests/test-tier.schema.json
- notes: Checks T0/T1/T2/T3 validation tier policy and schemas.

### token-ledger-budget-check

- result: PASS
- checks_run: 14
- passed_checks: 14
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/token-ledger.yaml, .aide/reports/token-ledger.jsonl, .aide/reports/token-savings-summary.md
- notes: Checks estimated token metadata without raw prompt or response storage.

### tool_absorption_policy_golden

- result: PASS
- checks_run: 55
- passed_checks: 55
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/tool-absorption.yaml, .aide/policies/tool-capabilities.yaml, .aide/policies/tool-fates.yaml, .aide/policies/tool-inventory.yaml, .aide/policies/tool-risk.yaml, .aide/policies/tool-wrapping.yaml
- notes: Checks Q41 tool absorption policy anchors and preservation posture.

### tool_adapter_map_schema_golden

- result: PASS
- checks_run: 17329
- passed_checks: 17329
- approx_tokens_if_applicable: n/a
- related_paths: .aide/tools/latest-tool-adapter-map.json, .aide/tools/tool-adapter-map.schema.json
- notes: Checks tool adapter-map schema and advisory mapping output.

### tool_fate_no_delete_approval_golden

- result: PASS
- checks_run: 8
- passed_checks: 8
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/tool-fates.yaml, .aide/tools/latest-tool-classification.json, .aide/tools/latest-tool-wrap-plan.json
- notes: Checks tool fate vocabulary never becomes deletion or execution approval.

### tool_inventory_schema_golden

- result: PASS
- checks_run: 23
- passed_checks: 23
- approx_tokens_if_applicable: n/a
- related_paths: .aide/tools/latest-tool-inventory.json, .aide/tools/tool-inventory.schema.json
- notes: Checks tool inventory schema and generated inventory shape.

### tool_record_schema_golden

- result: PASS
- checks_run: 13
- passed_checks: 13
- approx_tokens_if_applicable: n/a
- related_paths: .aide/tools/tool-record.schema.json
- notes: Checks tool record schema shape.

### tool_wrap_plan_schema_golden

- result: PASS
- checks_run: 17333
- passed_checks: 17333
- approx_tokens_if_applicable: n/a
- related_paths: .aide/tools/latest-tool-wrap-plan.json, .aide/tools/tool-wrap-plan.schema.json
- notes: Checks tool wrap-plan schema and no-execution output shape.

### tools_no_execution_golden

- result: PASS
- checks_run: 17354
- passed_checks: 17354
- approx_tokens_if_applicable: n/a
- related_paths: .aide/tools/latest-tool-adapter-map.json, .aide/tools/latest-tool-classification.json, .aide/tools/latest-tool-inventory.json, .aide/tools/latest-tool-wrap-plan.json
- notes: Checks Q41 tool outputs never enable unknown execution, apply, rename, deletion, or migration.

### transaction_export_pack_inclusion_golden

- result: PASS
- checks_run: 102
- passed_checks: 102
- approx_tokens_if_applicable: n/a
- related_paths: .aide/apply/README.md, .aide/apply/apply-safety-gate.schema.json, .aide/apply/conflict-record.schema.json, .aide/apply/file-operation.schema.json, .aide/apply/managed-section-operation.schema.json, .aide/apply/ownership-boundary.schema.json, .aide/apply/postimage.schema.json, .aide/apply/preimage.schema.json, .aide/apply/rollback-record.schema.json, .aide/apply/staged-change.schema.json, .aide/apply/transaction-evidence.schema.json, .aide/apply/transaction-verification.schema.json, .aide/apply/transaction.schema.json, .aide/examples/apply/apply-safety-gate.example.json, .aide/examples/apply/conflict-record.example.json, .aide/examples/apply/file-operation.create-file.example.json, .aide/examples/apply/file-operation.managed-section.example.json, .aide/examples/apply/managed-section-operation.example.json, .aide/examples/apply/ownership-boundary.example.json, .aide/examples/apply/postimage.example.json, .aide/examples/apply/preimage.example.json, .aide/examples/apply/rollback-record.example.json, .aide/examples/apply/staged-change.example.json, .aide/examples/apply/transaction-evidence.example.json, .aide/examples/apply/transaction-verification.example.json, .aide/examples/apply/transaction.fixture-only.example.json, .aide/examples/apply/transaction.report-only.example.json, .aide/export/aide-lite-pack-v0/manifest.yaml, .aide/policies/file-operations.yaml, .aide/policies/transaction-safety-gates.yaml, .aide/policies/transactional-apply.yaml, docs/reference/managed-section-operations.md, docs/reference/rollback-records.md, docs/reference/transaction-model.md, docs/reference/transactional-apply-roadmap.md
- notes: Checks transaction contracts are included in portable export-pack source scope.

### transaction_fixture_plan_golden

- result: PASS
- checks_run: 7
- passed_checks: 7
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/transaction-fixture-plan.json, .aide/reports/transaction-fixture-plan.md
- notes: Checks fixture-only transaction planning emits deterministic no-apply reports.

### transaction_fixture_verify_golden

- result: PASS
- checks_run: 227
- passed_checks: 227
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/transaction-fixture-plan.json, .aide/reports/transaction-fixture-validation.md
- notes: Checks fixture-only transaction verification validates records without active repo apply.

### transaction_no_real_apply_golden

- result: PASS
- checks_run: 15
- passed_checks: 15
- approx_tokens_if_applicable: n/a
- related_paths: .aide/reports/current-aide-roadmap.md, .aide/reports/transaction-fixture-plan.json, .aide/reports/transaction-fixture-plan.md, .aide/reports/transaction-fixture-validation.md, .aide/reports/transaction-model-status.md, .aide/reports/transaction-next-plan.md, .aide/reports/transaction-safety-gates.md
- notes: Checks transaction command outputs and script surface do not enable real apply behavior.

### transaction_policy_boundary_golden

- result: PASS
- checks_run: 44
- passed_checks: 44
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/file-operations.yaml, .aide/policies/transaction-safety-gates.yaml, .aide/policies/transactional-apply.yaml
- notes: Checks transaction policies define phases, operation classes, gates, and no-real-apply boundaries.

### transaction_schema_presence_golden

- result: PASS
- checks_run: 50
- passed_checks: 50
- approx_tokens_if_applicable: n/a
- related_paths: .aide/apply/apply-safety-gate.schema.json, .aide/apply/conflict-record.schema.json, .aide/apply/file-operation.schema.json, .aide/apply/managed-section-operation.schema.json, .aide/apply/ownership-boundary.schema.json, .aide/apply/postimage.schema.json, .aide/apply/preimage.schema.json, .aide/apply/rollback-record.schema.json, .aide/apply/staged-change.schema.json, .aide/apply/transaction-evidence.schema.json, .aide/apply/transaction-verification.schema.json, .aide/apply/transaction.schema.json, .aide/examples/apply/apply-safety-gate.example.json, .aide/examples/apply/conflict-record.example.json, .aide/examples/apply/file-operation.create-file.example.json, .aide/examples/apply/file-operation.managed-section.example.json, .aide/examples/apply/managed-section-operation.example.json, .aide/examples/apply/ownership-boundary.example.json, .aide/examples/apply/postimage.example.json, .aide/examples/apply/preimage.example.json, .aide/examples/apply/rollback-record.example.json, .aide/examples/apply/staged-change.example.json, .aide/examples/apply/transaction-evidence.example.json, .aide/examples/apply/transaction-verification.example.json, .aide/examples/apply/transaction.fixture-only.example.json, .aide/examples/apply/transaction.report-only.example.json
- notes: Checks transaction schemas and examples exist and parse.

### uninstall_no_apply_golden

- result: PASS
- checks_run: 29610
- passed_checks: 29610
- approx_tokens_if_applicable: n/a
- related_paths: .aide/uninstall/latest-uninstall-dry-run.json, .aide/uninstall/latest-uninstall-plan.json
- notes: Checks uninstall plans and dry-runs never enable apply, delete, or managed-section removal.

### uninstall_no_blanket_aide_delete_golden

- result: PASS
- checks_run: 168110
- passed_checks: 168110
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/uninstall-safety.yaml, .aide/uninstall/latest-uninstall-plan.json
- notes: Checks uninstall never plans blanket .aide deletion.

### uninstall_plan_schema_golden

- result: PASS
- checks_run: 168114
- passed_checks: 168114
- approx_tokens_if_applicable: n/a
- related_paths: .aide/uninstall/latest-uninstall-plan.json, .aide/uninstall/uninstall-operation.schema.json, .aide/uninstall/uninstall-plan.schema.json
- notes: Checks uninstall plan schema and generated no-apply plan shape.

### uninstall_policy_golden

- result: PASS
- checks_run: 40
- passed_checks: 40
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/uninstall-safety.yaml, .aide/policies/uninstall.yaml
- notes: Checks uninstall policy anchors and no-blanket-delete posture.

### uninstall_preserves_target_state_golden

- result: PASS
- checks_run: 8018
- passed_checks: 8018
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/uninstall-safety.yaml, .aide/uninstall/latest-uninstall-plan.json
- notes: Checks uninstall preserves target-specific memory, queue, evidence, manual content, tools, local state, and unknowns.

### upgrade_compatibility_policy_golden

- result: PASS
- checks_run: 65
- passed_checks: 65
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/upgrade-compatibility.yaml, .aide/upgrade/upgrade-compatibility-report.schema.json
- notes: Checks compatibility dimensions and future-gated migration levels.

### upgrade_dry_run_schema_golden

- result: PASS
- checks_run: 21
- passed_checks: 21
- approx_tokens_if_applicable: n/a
- related_paths: .aide/upgrade/latest-upgrade-dry-run.json, .aide/upgrade/upgrade-dry-run.schema.json
- notes: Checks upgrade dry-run schema and no-apply dry-run shape.

### upgrade_mandatory_migration_gate_golden

- result: PASS
- checks_run: 27
- passed_checks: 27
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/upgrade-migrations.yaml, .aide/upgrade/latest-upgrade-migration-report.md, .aide/upgrade/upgrade-migration-report.schema.json
- notes: Checks mandatory migrations are future-gated, non-automatic, and no-apply.

### upgrade_no_apply_golden

- result: PASS
- checks_run: 11715
- passed_checks: 11715
- approx_tokens_if_applicable: n/a
- related_paths: .aide/upgrade/latest-upgrade-dry-run.json, .aide/upgrade/latest-upgrade-plan.json
- notes: Checks Q45 upgrade data never enables apply, overwrite, delete, or automatic migration.

### upgrade_no_source_state_leak_golden

- result: PASS
- checks_run: 13
- passed_checks: 13
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/upgrade-preservation.yaml, .aide/upgrade/latest-upgrade-plan.json
- notes: Checks source-generated, local, and secret-like state is never planned as upgrade truth.

### upgrade_plan_schema_golden

- result: PASS
- checks_run: 18423
- passed_checks: 18423
- approx_tokens_if_applicable: n/a
- related_paths: .aide/upgrade/latest-upgrade-plan.json, .aide/upgrade/upgrade-operation.schema.json, .aide/upgrade/upgrade-plan.schema.json
- notes: Checks upgrade plan schema and generated no-apply plan shape.

### upgrade_policy_golden

- result: PASS
- checks_run: 63
- passed_checks: 63
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/upgrade.yaml, .aide/upgrade/upgrade-plan.schema.json
- notes: Checks Q45 upgrade policy anchors and preservation-first no-apply posture.

### upgrade_preserves_target_state_golden

- result: PASS
- checks_run: 9
- passed_checks: 9
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/upgrade-preservation.yaml, .aide/upgrade/latest-upgrade-plan.json
- notes: Checks upgrade plans preserve target-specific state by default.

### verifier-detects-bad-evidence

- result: PASS
- checks_run: 3
- passed_checks: 3
- approx_tokens_if_applicable: n/a
- related_paths: .aide/evals/golden-tasks/verifier-detects-bad-evidence/fixtures/missing-sections.md, .aide/verification/evidence-packet.template.md
- notes: Passes when the verifier refuses to accept malformed evidence silently.

### workunit_idempotency_golden

- result: PASS
- checks_run: 17
- passed_checks: 17
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/recovery.yaml, .aide/policies/work-units.yaml, .aide/reports/aide-workunit-recovery-standard.md
- notes: Checks WorkUnit idempotency and no-op behavior.

### workunit_sizing_policy_golden

- result: PASS
- checks_run: 12
- passed_checks: 12
- approx_tokens_if_applicable: n/a
- related_paths: .aide/policies/workunit-sizing.yaml
- notes: Checks WorkUnit sizing policy anchors and split gates.

## Limitations

- Deterministic local checks only.
- No model/provider/network calls.
- No external benchmark or arbitrary code semantic proof.
